package com.te.dao.Redirect;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/print_url")
public class PrintOutput extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {

		Cookie cookie[] = req.getCookies();
		String result = " ";
		for (Cookie ck : cookie) {
			if (ck.getName().equals("key"));
			result = (ck.getValue());
		}

		  PrintWriter writer = resp.getWriter();
		  writer.println("result: " + result);
		  
		 

	}
}
