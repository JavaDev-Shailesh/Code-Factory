

/*BY USING ANOTAION MAP SERVLET WITH URL
 * INSTED OF USING WEB .XML FILE 
 */
package com.te.dao.Redirect;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/input_Url")
public class Input extends HttpServlet {
  
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		int num1=Integer.parseInt(req.getParameter("num1"));
		int num2=Integer.parseInt(req.getParameter("num2"));
		req.setAttribute("num1", num1);
		req.setAttribute("num2", num2);
	    RequestDispatcher dispatcher=req.getRequestDispatcher("value_url");
	    dispatcher.forward(req, resp);
	}
}
