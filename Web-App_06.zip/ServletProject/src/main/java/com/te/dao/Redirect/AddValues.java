package com.te.dao.Redirect;

import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/addvalue_url")
public class AddValues extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {

		HttpSession session=req.getSession();
		int value1=(int)session.getAttribute("value1");
		int value2=(int)session.getAttribute("value2");
		
		String data=String.valueOf(value1+value2);
		Cookie cookie=new Cookie("key", data);
		resp.addCookie(cookie);
		
		resp.sendRedirect("print_url");
		
	}

}
