package com.te.dao.RequestDispatcher;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ResultServlet extends HttpServlet{

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
	int i=(int)	request.getAttribute("data");
	PrintWriter out=response.getWriter();
	out.println("RESULT: "+i);
	}
	
}
