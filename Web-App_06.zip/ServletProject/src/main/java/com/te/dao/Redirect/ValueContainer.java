package com.te.dao.Redirect;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/value_url")
public class ValueContainer extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {

	    int num1=(int) req.getAttribute("num1");
	    int num2=(int) req.getAttribute("num2");
	    
	    HttpSession session=req.getSession();
	    session.setAttribute("value1", num1);
	    session.setAttribute("value2", num2);
	    
	    resp.sendRedirect("addvalue_url");
		
	}
}
