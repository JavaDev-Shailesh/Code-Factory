package com.te.dao.RequestDispatcher;

import java.util.Scanner;

public class Demo {
   public static void main(String[] args) {
	System.out.println("enter total inputs: ");
    Scanner scanner=new Scanner(System.in);
    int input=scanner.nextInt();
    int []arr=new int[input];
    int []arr2=new int[arr.length];
    
    for (int i = 0; i < arr.length; i++) 
    {
		System.out.println("enter "+(i+1)+" value");
		arr[i]=scanner.nextInt();
	}
    
    for (int i = 0; i < arr.length; i++) 
    {
			int count=0;
	    	for (int j = (i+1); j < arr2.length; j++) 
	    	{
				if(arr[i]==arr[j])
					count++;
			}
	        
	    	int count2=0;
	    	for (int j = 0; j < arr2.length; j++)
	    	{
			    if(arr[i]==arr2[j])
			    	count2++;
	    	}
	    	
	
		    	arr2[i]=arr[i];
		    	if(count2==0) 
		    	{
		    		if(count==0)
		    		{
		    			System.out.println(arr[i]);
		    		}
		    	}
	 
	    	
	}
    
    

}
}