package com.te.bank;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Bank {
    
	public String method(String userName, String pass)
	{
		System.out.println(userName+":::"+pass);
		Connection connection=null;
		Statement statement=null;
		ResultSet resultSet=null;
		String uname="";
		int password=0;
		int count=0;
		try 
		{
			System.out.println("enter in try block..");
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/techno_elevate","root","root");
			System.out.println("connection done..");
		    statement=connection.createStatement();
		    resultSet=statement.executeQuery("select * from bank_table");
		    System.out.println("result set done...");
		    
		    int pasw=Integer.parseInt(pass);
		    System.out.println(pasw);
		    
		    while(resultSet.next())
		    {
		    	System.out.println("row:: "+resultSet.getString(1)+"::"+resultSet.getInt(2));
		    	if(userName.equals(resultSet.getString(1))) 
		    	{
		    		if(pasw==resultSet.getInt(2))
		    		{
		    		count++;
		    		uname=resultSet.getString(1);
		    		password=resultSet.getInt(2);
		    		}
		    	}
		    }
		
		
		
		}catch(Exception e) 
		{
			
		}finally
		{
			try {
				connection.close();
				statement.close();
				resultSet.close();
				
			}catch(Exception e) 
			{
				
			}
		}
		if(count>0)
			return "userName:: "+uname+"<br>"+"password:: "+password;
		else
			return "UserNot Found..";
		
	}
	
	
	
}
