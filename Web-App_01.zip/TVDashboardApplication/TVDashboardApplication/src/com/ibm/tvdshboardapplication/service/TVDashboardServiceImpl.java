package com.ibm.tvdshboardapplication.service;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.tvdshboardapplication.bean.InputFormBean;
import com.ibm.tvdshboardapplication.dao.TVDashboardDaoImpl;
import com.ibm.tvdshboardapplication.util.CommonLogic;
import com.ibm.tvdshboardapplication.util.DropdownValuesUtil;
import com.ibm.tvdshboardapplication.util.GenerateExcelUtil;

@Service
public class TVDashboardServiceImpl implements TVDashboardService {

	private static final Logger LOGGER = LogManager.getLogger(TVDashboardServiceImpl.class);
	@Override
	public Map<String, Object> getDropdownData() {

		return DropdownValuesUtil.getDropdownData();
	}

	@SuppressWarnings("unchecked")
	@Override
	public ModelAndView getTableRowData(ModelAndView model, InputFormBean inputFormBean, HttpSession session) throws Exception {
		// get sql data
		session.setAttribute("noOfDates", inputFormBean.getDateDropdown().size());
		Map<String, Object> formatedData = this.generateTableData(
				new TVDashboardDaoImpl().selectData(inputFormBean), inputFormBean, session);
		session.setAttribute("tableData", formatedData);

		int totalSummHours = 0;
		LOGGER.info("formatedData: "+formatedData);
		// set rows
		for (Map.Entry<String, List<List<Object>>> groupOfSummhourData : ((Map<String, List<List<Object>>>) formatedData
				.get("SUMMHOURS_DATA")).entrySet()) {
			model.addObject(groupOfSummhourData.getKey(), groupOfSummhourData.getValue());
			totalSummHours++;
		}
		// set rows calculations
		for (Map.Entry<String, List<Object>> calculationRows : ((Map<String, List<Object>>) formatedData
				.get("SUMMHOURS_CALCULATION_DATA")).entrySet()) {
			model.addObject(calculationRows.getKey(), calculationRows.getValue());
		}

		// set date headers
		model.addObject("DATE_HEADER", formatedData.get("DATE_HEADER"));
		model.addObject("totalSummHours", totalSummHours);

		return model;
	}

	public Map<String, Object> generateTableData(List<Map<String, Object>> sqlData, InputFormBean inputFormBean,
			HttpSession session) {
		
		CommonLogic commonLogic = new CommonLogic();
		Map<String, List<Map<String, Object>>> sortedDataOnDate = commonLogic.sortDataOnDate(sqlData, "RESERVE3",
				"dd-MMM-yyyy", "SortedOnDateGrops");
		
		Map<String, List<Map<String, Object>>> groupOfData = new LinkedHashMap<String, List<Map<String, Object>>>();
		Map<String, List<Map<String, Object>>> sortedDataOnSummHour = null;
		Map<String, List<Map<String, Object>>> sortedDataOnHourPartSummHour = null;
		Map<String, Map<String, List<Map<String, Object>>>> similarSumhourData = null;
		Map<String, List<List<Map<String, Object>>>> outputData = null;

		int keyCount = 0;
		for (Map.Entry<String, List<Map<String, Object>>> entry1 : sortedDataOnDate.entrySet()) {

			sortedDataOnSummHour = commonLogic.sortedDataOn(entry1.getValue(), true, "SortedOnSummhourGroup",
					"SUMMHOUR");			
			
			sortedDataOnHourPartSummHour = commonLogic.sortDataOnHourpart(sortedDataOnSummHour, "HOURPART",
					"SortedOnHourpartGroup");

			sortedDataOnHourPartSummHour = commonLogic.mergedSimilarHourPartData(sortedDataOnHourPartSummHour);

			for (Map.Entry<String, List<Map<String, Object>>> storeDataInFinalDataMap : sortedDataOnHourPartSummHour
					.entrySet()) {
				groupOfData.put("key_" + (++keyCount), storeDataInFinalDataMap.getValue());
			}
		}

		similarSumhourData = commonLogic.groupOfSimilarSumhourData(groupOfData, "SUMMHOUR");
		outputData = commonLogic.mergeDataInSingleRow(similarSumhourData, inputFormBean, session);
		LOGGER.info("---OUTPUT-DATA--- : "+outputData);
		Map<String, Object> finalDataForDisplay = commonLogic.setFinalDataForDisplay(outputData, session);
		LOGGER.info("--FINAL-DATA-- : "+finalDataForDisplay);
		return finalDataForDisplay;
	}

	@Override
	public Map<String, List<String>> zonesNamesOnSelectedCircles(List<String> selectedCircles) {
		List<String> UPSS_ZONE1_CIRCLES = Arrays.asList("CHN", "KN", "TN", "OR", "MP");
		List<String> UPSS_ZONE2_CIRCLES = Arrays.asList("KR", "ASM", "NESA", "BR", "JK", "RJ", "WB");
		List<String> UPSS_ZONE3_CIRCLES = Arrays.asList("DL", "UPE", "HR", "KOL", "PB", "UPW", "HP");
		List<String> UPSS_ZONE4_CIRCLES = Arrays.asList("AP", "GJ");
		List<String> UPSS_ZONE5_CIRCLES = Arrays.asList("MUM", "MH");
		List<String> CPOS_ZONE1_CIRCLES = Arrays.asList("CHN", "KN", "PB", "TN", "KR", "ASM", "NESA", "MP", "HP", "JK");
		List<String> CPOS_ZONE2_CIRCLES = Arrays.asList("AP", "KOL", "MUM", "WB", "UPW");
		List<String> CPOS_ZONE3_CIRCLES = Arrays.asList("GJ", "MH", "BR");
		List<String> CPOS_ZONE4_CIRCLES = Arrays.asList("DL", "UPE", "HR", "RJ", "OR");

		List<String> upssZoneNames = new ArrayList<String>();
		List<String> cposZoneNames = new ArrayList<String>();

		List<String> zoneOrder = Arrays.asList("ZONE1", "ZONE2", "ZONE3", "ZONE4", "ZONE5");

		for (String circle : selectedCircles) {
			String upssZone = UPSS_ZONE1_CIRCLES.contains(circle) ? "ZONE1"
					: UPSS_ZONE2_CIRCLES.contains(circle) ? "ZONE2"
							: UPSS_ZONE3_CIRCLES.contains(circle) ? "ZONE3"
									: UPSS_ZONE4_CIRCLES.contains(circle) ? "ZONE4"
											: UPSS_ZONE5_CIRCLES.contains(circle) ? "ZONE5" : "NA";
			upssZoneNames.add(upssZone);

			String cposZone = CPOS_ZONE1_CIRCLES.contains(circle) ? "ZONE1"
					: CPOS_ZONE2_CIRCLES.contains(circle) ? "ZONE2"
							: CPOS_ZONE3_CIRCLES.contains(circle) ? "ZONE3"
									: CPOS_ZONE4_CIRCLES.contains(circle) ? "ZONE4" : "NA";
			cposZoneNames.add(cposZone);
		}

		upssZoneNames = orderListBasedOnReference(upssZoneNames, zoneOrder);
		cposZoneNames = orderListBasedOnReference(cposZoneNames, zoneOrder);

		Map<String, List<String>> zones = new LinkedHashMap<String, List<String>>();
		zones.put("upss", upssZoneNames);
		zones.put("cpos", cposZoneNames);
		return zones;
	}

	private List<String> orderListBasedOnReference(List<String> list, List<String> order) {
		List<String> orderedList = new ArrayList<>();
		for (String zone : order) {
			if (list.contains(zone)) {
				orderedList.add(zone);
			}
		}
		return orderedList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void genarateExcel(OutputStream outputStream, String title, Map<String, Object> tableData)
			throws Exception {

		Map<String, Object> formatedData = tableData;
		List<Map<String, Object>> tableRows = new ArrayList<Map<String, Object>>();
		List<String> dates = (List<String>) formatedData.get("DATE_HEADER");
		int noOfDates = dates != null ? dates.size() : 0;

		String date1 = noOfDates > 0 ? dates.get(0).replace("'", "") : "-";
		String date2 = noOfDates > 1 ? dates.get(1).replace("'", "") : "-";
		String date3 = noOfDates > 2 ? dates.get(2).replace("'", "") : "-";

		List<String> listColNames2 = new ArrayList<String>();
		List<String> listcolAlignments2 = new ArrayList<String>();
		List<String> listColBgColors2 = new ArrayList<String>();
		List<Integer> listColColspan2 = new ArrayList<Integer>();
		
		List<String> listColNames3 = new ArrayList<String>();
		List<String> listcolAlignments3 = new ArrayList<String>();
		List<String> listColBgColors3 = new ArrayList<String>();
		List<Integer> listColSizes3 = new ArrayList<Integer>();
		
		if (noOfDates >= 1) {

			listColNames2.addAll(Collections.nCopies(2, " "));
			listColNames2.add(date1);
			listColNames2.addAll(Collections.nCopies(4, ""));
			listcolAlignments2.addAll(Collections.nCopies(7, "center"));
			listColBgColors2.addAll(Collections.nCopies(7, "LIGHT_CORNFLOWER_BLUE"));
			listColColspan2.addAll(Collections.nCopies(2, 0));
			listColColspan2.add(5);
			listColColspan2.addAll(Collections.nCopies(4, 0));
			
			listColNames3.addAll(Arrays.asList("SUMMHOUR", "HOURPART", "Offer", "TVSU", "TVXFR", "TVSU%", "XFR%"));
			listcolAlignments3.addAll(Collections.nCopies(7, "center"));
			listColBgColors3.addAll(Collections.nCopies(7, "LIGHT_CORNFLOWER_BLUE"));		
			listColSizes3.add(4000);

		}

		if (noOfDates >= 2) {
			listColNames2.add(date2);
			listColNames2.addAll(Collections.nCopies(4, ""));
			listcolAlignments2.addAll(Collections.nCopies(5, "center"));
			listColBgColors2.addAll(Collections.nCopies(5, "LIGHT_CORNFLOWER_BLUE"));
			listColColspan2.add(5);
			listColColspan2.addAll(Collections.nCopies(4, 0));
			
			listColNames3.addAll(Arrays.asList( "Offer", "TVSU", "TVXFR", "TVSU%", "XFR%"));
			listcolAlignments3.addAll(Collections.nCopies(5, "center"));
			listColBgColors3.addAll(Collections.nCopies(5, "LIGHT_CORNFLOWER_BLUE"));		
		}

		if (noOfDates >= 3) {
			listColNames2.add(date3);
			listColNames2.addAll(Collections.nCopies(4, ""));
			listcolAlignments2.addAll(Collections.nCopies(5, "center"));
			listColBgColors2.addAll(Collections.nCopies(5, "LIGHT_CORNFLOWER_BLUE"));
			listColColspan2.add(5);
			listColColspan2.addAll(Collections.nCopies(4, 0));
			
			listColNames3.addAll(Arrays.asList( "Offer", "TVSU", "TVXFR", "TVSU%", "XFR%"));
			listcolAlignments3.addAll(Collections.nCopies(5, "center"));
			listColBgColors3.addAll(Collections.nCopies(5, "LIGHT_CORNFLOWER_BLUE"));
		}
		
		List<Map<String, Object>> tableHeaders = new ArrayList<Map<String, Object>>();

		String[] colNames = { title };
		String[] colAlignments = { "center" };
		String[] colBgColors = { "yellow" };
		int[] colSizes = { 4000 };
		int[] colColspan = { noOfDates == 1 ? 7 : noOfDates == 2 ? 12 : noOfDates == 3 ? 17 : 17 };

		String[] colNames2 = listColNames2.toArray(new String[0]);
		String[] colAlignments2 = listcolAlignments2.toArray(new String[0]);
		String[] colBgColors2 = listColBgColors2.toArray(new String[0]);
		int[] colColspan2 = listColColspan2.stream()
	            .mapToInt(Integer::intValue)
	            .toArray();
		
		String[] colNames3 = listColNames3.toArray(new String[0]);
		String[] colAlignments3 = listcolAlignments3.toArray(new String[0]);
		String[] colBgColors3 = listColBgColors3.toArray(new String[0]);
		int[] colSizes3 = listColSizes3.stream()
	            .mapToInt(Integer::intValue)
	            .toArray();
		
		Map<String, Object> header1 = new HashedMap<String, Object>();
		header1.put("colNames", colNames);
		header1.put("colAlignments", colAlignments);
		header1.put("colBgColors", colBgColors);
		header1.put("colSizes", colSizes);
		header1.put("colColspan", colColspan);
		tableHeaders.add(header1);
		
		Map<String, Object> header2 = new HashedMap<String, Object>();
		header2.put("colNames", colNames2);
		header2.put("colAlignments", colAlignments2);
		header2.put("colBgColors", colBgColors2);
		header2.put("colSizes", null);
		header2.put("colColspan", colColspan2);
		tableHeaders.add(header2);

		Map<String, Object> header3 = new HashedMap<String, Object>();
		header3.put("colNames", colNames3);
		header3.put("colAlignments", colAlignments3);
		header3.put("colBgColors", colBgColors3);
		header3.put("colSizes", colSizes3);
		header3.put("colColspan", null);
		tableHeaders.add(header3);

		Map<String, Object> row = null;
		int count;

		int noOfGroups = 0;
		for (Map.Entry<String, List<List<Object>>> groupOfSummhourData : ((Map<String, List<List<Object>>>) formatedData
				.get("SUMMHOURS_DATA")).entrySet()) {

			noOfGroups++;
			for (List<Object> innerList : groupOfSummhourData.getValue()) {
				row = new LinkedHashMap<String, Object>();
				count = 0;
				for (Object item : innerList) {
					item = item.toString().replace("'", "");
					row.put("key" + count, item);
					count++;
				}
				tableRows.add(row);
			}

			int noOfCalcRows = 0;
			for (Map.Entry<String, List<Object>> calculationRows : ((Map<String, List<Object>>) formatedData
					.get("SUMMHOURS_CALCULATION_DATA")).entrySet()) {
				noOfCalcRows++;
				if (noOfCalcRows == noOfGroups) {
					row = new LinkedHashMap<String, Object>();
					count = 0;
					for (Object item : calculationRows.getValue()) {
						item = item.toString().replace("'", "");
						row.put("key" + count, item);
						if (count == 0) {
							row.put("key", "");
						}
						count++;
					}
					tableRows.add(row);
				}

			}
		}

		new GenerateExcelUtil().generateExcel(outputStream, tableHeaders, tableRows);

	}

}
