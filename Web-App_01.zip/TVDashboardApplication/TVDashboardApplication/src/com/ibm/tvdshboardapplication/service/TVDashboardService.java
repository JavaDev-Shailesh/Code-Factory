package com.ibm.tvdshboardapplication.service;

import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;

import com.ibm.tvdshboardapplication.bean.InputFormBean;

public interface TVDashboardService {

	public Map<String, Object> getDropdownData();

	public ModelAndView getTableRowData(ModelAndView model, InputFormBean inputFormBean, HttpSession session) throws Exception;

	public Map<String,List<String>> zonesNamesOnSelectedCircles(List<String> selectedCircles);
	
	public void genarateExcel(OutputStream outputStream, String title, Map<String, Object> tableData) throws Exception;
}
