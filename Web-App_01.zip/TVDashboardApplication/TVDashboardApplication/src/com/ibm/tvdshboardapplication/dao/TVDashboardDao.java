package com.ibm.tvdshboardapplication.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.ibm.tvdshboardapplication.bean.InputFormBean;

public interface TVDashboardDao {

	public List<Map<String, Object>> selectData(InputFormBean formBean) throws SQLException ;
}
