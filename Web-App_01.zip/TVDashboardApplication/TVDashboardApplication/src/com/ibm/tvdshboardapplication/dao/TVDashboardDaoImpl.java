package com.ibm.tvdshboardapplication.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ibm.tvdshboardapplication.bean.InputFormBean;
import com.ibm.tvdshboardapplication.controller.TVDashboardController;
import com.ibm.tvdshboardapplication.util.DBConnectionUtil;

@Repository
public class TVDashboardDaoImpl extends DBConnectionUtil implements TVDashboardDao {

	private static final Logger LOGGER = LogManager.getLogger(TVDashboardController.class);
	
	public List<Map<String, Object>> selectData( InputFormBean formBean) throws SQLException {
      
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		ResultSetMetaData metaData = null;
		Map<String, Object> row = null;
		List<Map<String, Object>> resultList = null;
		StringBuilder builder = null;
		String columnName;
		Object columnValue;
		int columnCount = 0;
		String dates = null;
		String summHours = null;
		String cricles = null;
		String brand = null;
		String lob = null;
		
		dates = formBean.getDateDropdown().stream().map(item -> "'" + item.trim() + "'").collect(Collectors.joining(", "));
		cricles = formBean.getCircleDropdown().stream().map(item -> "'" + item.trim() + "'").collect(Collectors.joining(", "));
		summHours = formBean.getSummhourDopdown().stream().map(item -> item.trim()).collect(Collectors.joining(", "));
		cricles = formBean.getCircleDropdown().stream().map(item -> "'" + item.trim() + "'").collect(Collectors.joining(", "));
		brand = formBean.getBrandname().trim().equals("BOTH") ? "VODA','IDEA" : formBean.getBrandname().trim();
		lob = formBean.getPostorpre().trim().equals("BOTH") ? "PREPAID','POSTPAID" : formBean.getPostorpre().trim();

		builder = new StringBuilder();
	
		builder.append(" SELECT ");// TO_CHAR(to_date(DATED, 'DD-Mon-YY'),'DD-MON-YYYY')
		builder.append(" TO_CHAR(to_date(DATED, 'DD-Mon-YY'),'DD-MON-YYYY') AS RESERVE3, SUMMHOUR, HOURPART, CALLS AS TVOFFERED, TV_SUCCESS AS TVSUCCESS, XFER AS TRANSFER,");
		/*
		 * builder.append(" TV_SU_PERC AS TVSU_PER,");
		 * builder.append(" XFER_PERC  AS XFR_PER, ");
		 */
		builder.append(" CALLERS  AS UNNICALLER ");
		builder.append(" FROM TBL_TVCALLVOLUME ");
		builder.append(" WHERE ");
		builder.append(" BRAND IN ('").append(brand).append("')");
		builder.append(" AND LOB IN ('").append(lob).append("')");
		builder.append(" AND SUMMHOUR IN (").append(summHours).append(") ");
		builder.append(" AND CIRCLE IN ( ").append(cricles).append(") ");
        builder.append(" AND TO_CHAR(to_date(DATED, 'DD-Mon-YY'),'DD-MON-YYYY') IN (").append(dates).append(")");
		builder.append(" ORDER BY SUMMHOUR");
		
		String selectQuery = builder.toString();
		
		connection = getJDBCConnection();
		LOGGER.info(" is connection created  : "+(connection !=null));
		LOGGER.info("selectQuery : "+selectQuery);
		
		statement = connection.createStatement();
		resultSet = statement.executeQuery(selectQuery);
		metaData = resultSet.getMetaData();
		resultList = new ArrayList<>();
		columnCount = metaData.getColumnCount();

		while (resultSet.next()) {

			row = new LinkedHashMap<>();
			for (int i = 1; i <= columnCount; i++) {
				columnName = metaData.getColumnName(i);
				columnValue = resultSet.getObject(i);
				columnValue = columnValue!=null ? columnValue.toString().replace("%", "") : columnValue; 
				row.put(columnName, columnValue);
			}

			resultList.add(row);
		}

		resultSet.close();
		statement.close();
		connection.close();
		LOGGER.info("is Data Fetched :"+(resultList.size()>0));
		
		return resultList;
	}
}
