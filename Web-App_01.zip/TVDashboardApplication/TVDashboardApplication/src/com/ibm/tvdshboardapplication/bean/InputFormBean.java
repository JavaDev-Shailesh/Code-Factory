package com.ibm.tvdshboardapplication.bean;

import java.util.List;

public class InputFormBean {

	private List<String> dateDropdown;
	private List<String> circleDropdown;
	private List<String> summhourDopdown;
	private List<String> upsszones;
	private List<String> cposzones;
	private String brandname;
	private String postorpre;

	public List<String> getDateDropdown() {
		return dateDropdown;
	}

	public void setDateDropdown(List<String> dateDropdown) {
		this.dateDropdown = dateDropdown;
	}

	public List<String> getCircleDropdown() {
		return circleDropdown;
	}

	public void setCircleDropdown(List<String> circleDropdown) {
		this.circleDropdown = circleDropdown;
	}

	public List<String> getSummhourDopdown() {
		return summhourDopdown;
	}

	public void setSummhourDopdown(List<String> summhourDopdown) {
		this.summhourDopdown = summhourDopdown;
	}

	public List<String> getUpsszones() {
		return upsszones;
	}

	public void setUpsszones(List<String> upsszones) {
		this.upsszones = upsszones;
	}

	public List<String> getCposzones() {
		return cposzones;
	}

	public void setCposzones(List<String> cposzones) {
		this.cposzones = cposzones;
	}

	public String getBrandname() {
		return brandname;
	}

	public void setBrandname(String brandname) {
		this.brandname = brandname;
	}

	public String getPostorpre() {
		return postorpre;
	}

	public void setPostorpre(String postorpre) {
		this.postorpre = postorpre;
	}

	@Override
	public String toString() {
		return "InputFormBean [dateDropdown=" + dateDropdown + ", circleDropdown=" + circleDropdown
				+ ", summhourDopdown=" + summhourDopdown + ", upsszones=" + upsszones + ", cposzones=" + cposzones
				+ ", brandname=" + brandname + ", postorpre=" + postorpre + "]";
	}

}
