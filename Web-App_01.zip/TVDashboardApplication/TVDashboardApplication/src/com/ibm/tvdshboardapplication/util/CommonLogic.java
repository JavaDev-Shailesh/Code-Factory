package com.ibm.tvdshboardapplication.util;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import com.ibm.tvdshboardapplication.bean.InputFormBean;

public class CommonLogic {

	public Map<String, List<Map<String, Object>>> sortDataOnDate(List<Map<String, Object>> sqlData, String keyName,
			String dateFormat, String setKeyName) {
		Map<String, List<Map<String, Object>>> sortedDataMap = new LinkedHashMap<>();

		for (Map<String, Object> dataMap : sqlData) {
			if (dataMap.containsKey(keyName)) {
				List<Map<String, Object>> dataList = sortedDataMap.computeIfAbsent((String) dataMap.get(keyName),
						k -> new ArrayList<>());
				dataList.add(dataMap);
			}
		}

		for (List<Map<String, Object>> dataList : sortedDataMap.values()) {
			dataList.sort((map1, map2) -> {
				String dateStr1 = (String) map1.get(keyName);
				String dateStr2 = (String) map2.get(keyName);

				SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

				try {
					Date date1 = sdf.parse(dateStr1);
					Date date2 = sdf.parse(dateStr2);

					return date1.compareTo(date2);
				} catch (ParseException e) {
					e.printStackTrace();
				}

				return 0;
			});
		}

		Map<String, List<Map<String, Object>>> newData = new LinkedHashMap<>();
		int keyCounter = 1;

		for (Map.Entry<String, List<Map<String, Object>>> entry : sortedDataMap.entrySet()) {
			String newKey = setKeyName + keyCounter;
			newData.put(newKey, entry.getValue());
			keyCounter++;
		}
		return newData;
	}

	public List<Map<String, Object>> getsortedDataListOnMapValues(List<Map<String, Object>> dataList, String keyName) {

		Collections.sort(dataList, new Comparator<Map<String, Object>>() {
			@SuppressWarnings("unchecked")
			@Override
			public int compare(Map<String, Object> map1, Map<String, Object> map2) {
				Comparable<Object> value1 = (Comparable<Object>) map1.get(keyName);
				Comparable<Object> value2 = (Comparable<Object>) map2.get(keyName);

				return value1.compareTo(value2);
			}
		});

		return dataList;
	}

	public Map<String, List<Map<String, Object>>> sortedDataOn(List<Map<String, Object>> data, boolean requiredToSort,
			String rowType, String keyName) {

		List<Map<String, Object>> dataList = null;

		if (requiredToSort) {
			dataList = this.getsortedDataListOnMapValues(data, keyName);
		} else {
			dataList = data;
		}

		String key, value, tempSummhourVal = "xVal";
		Map<String, List<Map<String, Object>>> rowSets = new LinkedHashMap<String, List<Map<String, Object>>>();
		List<Map<String, Object>> rowset = new LinkedList<Map<String, Object>>();
		Map<String, Object> row = null;

		int tempCount1 = 0;
		int tempCount2 = 0;
		int rowNo = 1;
		for (Map<String, Object> dataMap : dataList) {

			row = new LinkedHashMap<String, Object>();

			for (Map.Entry<String, Object> entry : dataMap.entrySet()) {
				key = entry.getKey();
				value = entry.getValue() != null ? entry.getValue().toString() : null;
				row.put(key, value);

				if (key.equals(keyName) && !tempSummhourVal.equals(value)) {
					tempSummhourVal = value;
					tempCount1++;
				}
			}

			if (tempCount1 != tempCount2) {
				if (tempCount1 != 1) {
					rowSets.put(rowType + rowNo, rowset);
					rowset = new LinkedList<Map<String, Object>>();
					tempCount2 = tempCount1;
					rowNo++;
				}
			}
			rowset.add(row);
		}
		rowSets.put(rowType + rowNo, rowset);

		return rowSets;
	}

	public Map<String, List<Map<String, Object>>> sortDataOnHourpart(Map<String, List<Map<String, Object>>> data,
			String keyName, String newKeyName) {

		Map<String, List<Map<String, Object>>> sortDataOnHourpart = new LinkedHashMap<String, List<Map<String, Object>>>();
		int count = 0;
		for (Map.Entry<String, List<Map<String, Object>>> entry : data.entrySet()) {

			List<Map<String, Object>> dataList = entry.getValue();

			// Sort the dataList based on the "HOURPART" field in ascending order
			Collections.sort(dataList, new Comparator<Map<String, Object>>() {
				@Override
				public int compare(Map<String, Object> o1, Map<String, Object> o2) {
					// Assuming "HOURPART" is an Integer, if it's a String, you may need to convert
					// it to Integer first.
					Integer hourPart1 = Integer.parseInt(o1.get(keyName).toString());
					Integer hourPart2 = Integer.parseInt(o2.get(keyName).toString());

					return hourPart1.compareTo(hourPart2);
				}
			});

			sortDataOnHourpart.put(newKeyName + (++count), dataList);
		}

		return sortDataOnHourpart;
	}

	public Map<String, List<Map<String, Object>>> mergedSimilarHourPartData(
			Map<String, List<Map<String, Object>>> data) {

		DecimalFormat df = new DecimalFormat("#.##");
		Map<String, List<Map<String, Object>>> mergedData = new LinkedHashMap<String, List<Map<String, Object>>>();
		Map<String, Object> setInnerMap = null;

		double offer = 0.0;
		double tvSuccess = 0.0;
		double transfer = 0.0;
		//double tvsu_Perc = 0.0;
		//double xfr_Perc = 0.0;
		//NEW ++
		double unicaller = 0.0;
		String date = "";
		String summhour = "";
		String hourPart = "";

		String priviousHourPart;

		// Iterate over the outer map's keys
		for (String outerKey : data.keySet()) {

			// Get the list associated with the current outer key
			List<Map<String, Object>> innerList = data.get(outerKey);
			List<Map<String, Object>> setNewInnerList = new LinkedList<Map<String, Object>>();
			priviousHourPart = "";

			// Iterate over the list of maps

			for (int i = 0; i < innerList.size(); i++) {
				Map<String, Object> innerMap = innerList.get(i);

				// Iterate over the keys and values in each inner map
				for (Map.Entry<String, Object> entry : innerMap.entrySet()) {

					if (!innerMap.get("HOURPART").toString().equals(priviousHourPart)) {

						if (!priviousHourPart.equals("")) {

							setInnerMap.put("RESERVE3", date);
							setInnerMap.put("SUMMHOUR", summhour);
							setInnerMap.put("HOURPART", hourPart);
							setInnerMap.put("TVOFFERED", df.format(offer));
							setInnerMap.put("TVSUCCESS", df.format(tvSuccess));
							setInnerMap.put("TRANSFER", df.format(transfer));
							//setInnerMap.put("TVSU_PER", df.format(tvsu_Perc));
							//setInnerMap.put("XFR_PER", df.format(xfr_Perc));
							//NEW ++
							//setInnerMap.put("UNNICALLER", df.format(unicaller));
							setInnerMap.put("TVSU_PER", df.format((tvSuccess/unicaller)*100));
							setInnerMap.put("XFR_PER", df.format((transfer/offer)*100));
							setNewInnerList.add(setInnerMap);
							offer = 0.0;
							tvSuccess = 0.0;
							transfer = 0.0;
							//tvsu_Perc = 0.0;
							//xfr_Perc = 0.0;
							unicaller = 0.0;
							date = "";
							summhour = "";
							hourPart = "";
						}

						priviousHourPart = innerMap.get("HOURPART").toString();
						setInnerMap = new LinkedHashMap<String, Object>();

					}
					if (entry.getKey().equals("TVOFFERED")) {
						offer += getTypeCatedValue(entry.getValue());
					}
					if (entry.getKey().equals("TVSUCCESS")) {
						tvSuccess += getTypeCatedValue(entry.getValue());
					}
					if (entry.getKey().equals("TRANSFER")) {
						transfer += getTypeCatedValue(entry.getValue());
					}
					/*
					 * if (entry.getKey().equals("TVSU_PER")) { tvsu_Perc +=
					 * getTypeCatedValue(entry.getValue().toString().replace("%", "")); } if
					 * (entry.getKey().equals("XFR_PER")) { xfr_Perc +=
					 * getTypeCatedValue(entry.getValue().toString().replace("%", "")); }
					 */
					if (entry.getKey().equals("RESERVE3")) {
						date = entry.getValue().toString();
					}
					if (entry.getKey().equals("SUMMHOUR")) {
						summhour = entry.getValue().toString();
					}
					if (entry.getKey().equals("HOURPART")) {
						hourPart = entry.getValue().toString();

					}
					//NEW ++
					if (entry.getKey().equals("UNNICALLER")) {
						unicaller += getTypeCatedValue(entry.getValue());

					}
				}

				if (i == innerList.size() - 1) {

					setInnerMap.put("RESERVE3", date);
					setInnerMap.put("SUMMHOUR", summhour);
					setInnerMap.put("HOURPART", hourPart);
					setInnerMap.put("TVOFFERED", df.format(offer));
					setInnerMap.put("TVSUCCESS", df.format(tvSuccess));
					setInnerMap.put("TRANSFER", df.format(transfer));
					//setInnerMap.put("TVSU_PER", df.format(tvsu_Perc));
					//setInnerMap.put("XFR_PER", df.format(xfr_Perc));
					//NEW ++
					//setInnerMap.put("UNNICALLER", df.format(unicaller));
					setInnerMap.put("TVSU_PER", df.format((tvSuccess/unicaller)*100));
					setInnerMap.put("XFR_PER", df.format((transfer/offer)*100));
					setNewInnerList.add(setInnerMap);
					offer = 0.0;
					tvSuccess = 0.0;
					transfer = 0.0;
					//tvsu_Perc = 0.0;
					//xfr_Perc = 0.0;
					unicaller = 0.0;
					date = "";
					summhour = "";
					hourPart = "";
					priviousHourPart = "";
					setInnerMap = new LinkedHashMap<String, Object>();
				}

			}

			mergedData.put(outerKey, setNewInnerList);

		}

		return mergedData;
	}

	public Map<String, Map<String, List<Map<String, Object>>>> groupOfSimilarSumhourData(
			Map<String, List<Map<String, Object>>> groupOfData, String keyName) {
		Map<String, Map<String, List<Map<String, Object>>>> similarSumhourData = new LinkedHashMap<>();

		// Iterate through the input data
		for (Map.Entry<String, List<Map<String, Object>>> entry : groupOfData.entrySet()) {
			String key = entry.getKey();
			List<Map<String, Object>> value = entry.getValue();

			// Get the SUMMHOUR value from the first entry of the list (assuming all have
			// the same SUMMHOUR)
			Object sumHourValue = value.get(0).get(keyName);

			if (sumHourValue instanceof Integer) {
				String sumHour = sumHourValue.toString();
				// If the SUMMHOUR group doesn't exist in the groupedData map, create it
				similarSumhourData.putIfAbsent(sumHour, new LinkedHashMap<>());
				// Add the key and data to the corresponding SUMMHOUR group
				similarSumhourData.get(sumHour).put(key, value);
			} else if (sumHourValue instanceof String) {
				String sumHour = sumHourValue.toString();
				// If the SUMMHOUR group doesn't exist in the groupedData map, create it
				similarSumhourData.putIfAbsent(sumHour, new LinkedHashMap<>());
				// Add the key and data to the corresponding SUMMHOUR group
				similarSumhourData.get(sumHour).put(key, value);
			}
		}
		return similarSumhourData;
	}

	public Map<String, List<List<Map<String, Object>>>> mergeDataInSingleRow(
			Map<String, Map<String, List<Map<String, Object>>>> groupedData, InputFormBean inputFormBean,
			HttpSession session) {

		List<Map<String, Object>> innerList = null;
		List<Map<String, Object>> eachSumhourGroup = null;
		List<List<Map<String, Object>>> singleRowSumhourGroup = null;
		Map<String, List<Map<String, Object>>> innerMap = null;
		Map<String, List<Map<String, Object>>> sotedDataOnDate = null;
		Map<String, List<List<Map<String, Object>>>> outputData = new LinkedHashMap<String, List<List<Map<String, Object>>>>();
		int keyCount = 0;
		int sessionCount = 1;
		for (Map.Entry<String, Map<String, List<Map<String, Object>>>> entry1 : groupedData.entrySet()) {

			keyCount++;
			innerMap = entry1.getValue();
			eachSumhourGroup = new ArrayList<Map<String, Object>>();
			singleRowSumhourGroup = new ArrayList<List<Map<String, Object>>>();

			for (Map.Entry<String, List<Map<String, Object>>> entry2 : innerMap.entrySet()) {

				innerList = entry2.getValue();

				for (Map<String, Object> item : innerList) {
					eachSumhourGroup.add(item);
				}
			}
			// System.out.println("eachSumhourGroup: "+eachSumhourGroup);
			sotedDataOnDate = this.sortedDataOn(eachSumhourGroup, true, "hourPartGroup", "HOURPART");
			sotedDataOnDate = this.insertDummyData(sotedDataOnDate, inputFormBean, session, sessionCount);
			sessionCount++;
			// System.out.println("sotedDataOnDate: "+sotedDataOnDate);

			for (Map.Entry<String, List<Map<String, Object>>> entry : sotedDataOnDate.entrySet()) {

				singleRowSumhourGroup
						.add(this.sortAndMergesameSumhourAndHourPartData(entry.getValue(), "RESERVE3", "dd-MMM-yyyy"));
			}
			outputData.put("key" + keyCount, singleRowSumhourGroup);
		}
		return outputData;
	}

	private Map<String, List<Map<String, Object>>> insertDummyData(
			Map<String, List<Map<String, Object>>> sotedDataOnDate, InputFormBean inputFormBean, HttpSession session,
			int sessionCount) {

		String keyName = "hourPartGroup";
		int keyCount = 1;
		String summhour = "";
		boolean flag = true;
		List<String> availableHourParts = new ArrayList<String>();
		List<String> inputDates = inputFormBean.getDateDropdown();

		Map<String, List<Map<String, Object>>> outputWithDummyData = new LinkedHashMap<String, List<Map<String, Object>>>();

		for (Map.Entry<String, List<Map<String, Object>>> entry : sotedDataOnDate.entrySet()) {

			// Step 1: get all avaible hourparts and perticular sumhour
			for (Map<String, Object> hourPartGroup : entry.getValue()) {

				for (Map.Entry<String, Object> nestedEntry : hourPartGroup.entrySet()) {
					if (nestedEntry.getKey().equals("HOURPART")
							&& !availableHourParts.contains(nestedEntry.getValue())) {
						availableHourParts.add(nestedEntry.getValue().toString());
					}
					if (nestedEntry.getKey().equals("SUMMHOUR") && flag) {
						summhour = nestedEntry.getValue().toString();
						flag = false;
					}
				}
			}
		}
		session.setAttribute("NoOfAvailableHourParts" + sessionCount,
				availableHourParts.size() > 0 ? availableHourParts.size() : 1);
		// System.out.println("availableHourParts: "+availableHourParts);
		Map<String, Object> dummyMap = null;
		/* System.out.println("sotedDataOnDate: "+sotedDataOnDate); */
		for (Map.Entry<String, List<Map<String, Object>>> entry : sotedDataOnDate.entrySet()) {
			// Step 2 : if size of hourPartGroup < 3 add remaining values
			List<Map<String, Object>> eachHourPartGroup = new ArrayList<Map<String, Object>>();
			int hourPartGroupSize = entry.getValue().size();
			if (hourPartGroupSize != 3) {
				String hourPart = "";
				List<String> availableDatesInThisGroup = new ArrayList<String>();
				// step 2.1 find all available dates
				for (Map<String, Object> hourPartGroup : entry.getValue()) {
					/* availableDatesInThisGroup.clear(); */
					/* System.out.println("hourPartGroup: " + hourPartGroup); */
					for (Map.Entry<String, Object> nestedEntry : hourPartGroup.entrySet()) {
						if (nestedEntry.getKey().equals("RESERVE3")
								&& !availableDatesInThisGroup.contains(nestedEntry.getValue().toString())) {
							availableDatesInThisGroup.add(hourPartGroup.get("RESERVE3").toString());
						}
					}
					if (hourPart.isEmpty()) {
						hourPart = hourPartGroup.get("HOURPART").toString();
					}
					eachHourPartGroup.add(hourPartGroup);
				}
				// step 2.2 add unavaible dates in this group 3 - hourPartGroupSize
				for (String date : inputDates) {
					if (!availableDatesInThisGroup.contains(date)) {
						dummyMap = new LinkedHashMap<String, Object>();
						dummyMap.put("RESERVE3", date);
						dummyMap.put("SUMMHOUR", summhour);
						dummyMap.put("HOURPART", hourPart);
						dummyMap.put("TVOFFERED", "x");
						dummyMap.put("TVSUCCESS", "x");
						dummyMap.put("TRANSFER", "x");
						dummyMap.put("TVSU_PER", "x");
						dummyMap.put("XFR_PER", "x");
						//NEW ++
						//dummyMap.put("UNNICALLER","x");
						availableDatesInThisGroup.add(date);
						eachHourPartGroup.add(dummyMap);
					}
				}
				// }
			} else {
				eachHourPartGroup = entry.getValue();
			}
			outputWithDummyData.put(keyName + (keyCount++), eachHourPartGroup);
		}
		// add hourpart groups if required
		if (outputWithDummyData.size() != 4) {

			List<String> hourParts = Arrays.asList("1", "2", "3", "4");
			List<Map<String, Object>> dummyHourPartGroup = null;
			Map<String, Object> map = null;

			for (String hourPart : hourParts) {
				if (!availableHourParts.contains(hourPart)) {
					dummyHourPartGroup = new ArrayList<Map<String, Object>>();
					for (String date : inputDates) {

						map = new LinkedHashMap<String, Object>();
						map.put("RESERVE3", date);
						map.put("SUMMHOUR", summhour);
						map.put("HOURPART", hourPart);
						map.put("TVOFFERED", "x");
						map.put("TVSUCCESS", "x");
						map.put("TRANSFER", "x");
						map.put("TVSU_PER", "x");
						map.put("XFR_PER", "x");
						//NEW ++
					//	map.put("UNNICALLER","x");
						dummyHourPartGroup.add(map);
					}
					outputWithDummyData.put(keyName + (keyCount++), dummyHourPartGroup);
				}
			}
		}

		outputWithDummyData = this.sortedDummyData(outputWithDummyData);
		/* System.out.println("outputWithDummyData: "+outputWithDummyData); */
		return outputWithDummyData;
	}

	public Map<String, List<Map<String, Object>>> sortedDummyData(
			Map<String, List<Map<String, Object>>> outputWithDummyData) {

		// Sort the data based on HOURPART in descending order
		List<Map.Entry<String, List<Map<String, Object>>>> sortedEntries = new ArrayList<>(
				outputWithDummyData.entrySet());

		Collections.sort(sortedEntries, new Comparator<Map.Entry<String, List<Map<String, Object>>>>() {
			@Override
			public int compare(Map.Entry<String, List<Map<String, Object>>> o1,
					Map.Entry<String, List<Map<String, Object>>> o2) {
				int hourPart1 = Integer.parseInt(o1.getValue().get(0).get("HOURPART").toString());
				int hourPart2 = Integer.parseInt(o2.getValue().get(0).get("HOURPART").toString());

				// Compare based on HOURPART in ascending order
				return Integer.compare(hourPart1, hourPart2);
			}
		});
		String keyName = "hourPartGroup";
		int keyCount = 1;
		// Create a new map with the sorted entries
		Map<String, List<Map<String, Object>>> sortedOutputWithDummyData = new LinkedHashMap<>();
		for (Map.Entry<String, List<Map<String, Object>>> entry : sortedEntries) {
			sortedOutputWithDummyData.put(keyName + (keyCount++), entry.getValue());
		}
		return sortedOutputWithDummyData;
	}

	public List<Map<String, Object>> sortAndMergesameSumhourAndHourPartData(List<Map<String, Object>> data,
			String dateKey, String dateFormat) {

		List<String> columName = new ArrayList<>(Arrays.asList("RESERVE3", "SUMMHOUR", "HOURPART", "TVOFFERED",
				"TVSUCCESS", "TRANSFER", "TVSU_PER", "XFR_PER"));
		Collections.sort(data, new Comparator<Map<String, Object>>() {
			@Override
			public int compare(Map<String, Object> o1, Map<String, Object> o2) {
				try {
					SimpleDateFormat simpDateFormat = new SimpleDateFormat(dateFormat);
					Date date1 = simpDateFormat.parse((String) o1.get(dateKey));
					Date date2 = simpDateFormat.parse((String) o2.get(dateKey));
					return date1.compareTo(date2);
				} catch (ParseException e) {
					throw new IllegalArgumentException(
							"Commonlogic > sortAndMergesameSumhourAndHourPartData >> Invalid date format .");
				}
			}
		});
		DecimalFormat df = new DecimalFormat("#.##");
		// create single row
		List<Map<String, Object>> singleRowList = new ArrayList<Map<String, Object>>();
		Map<String, Object> rowMap = new LinkedHashMap<String, Object>();
		int count = 0;
		boolean addSumhour = true;
		boolean addHourpart = true;
		double val = 0;
		String strVal = "";
		for (Map<String, Object> map : data) {
			count++;
			for (Map.Entry<String, Object> entry : map.entrySet()) {
				if (columName.contains(entry.getKey())) {

					if (entry.getKey().equals("SUMMHOUR") && addSumhour) {
						rowMap.put(entry.getKey() + count, entry.getValue());
						addSumhour = false;
					} else if (entry.getKey().equals("HOURPART") && addHourpart) {
						rowMap.put(entry.getKey() + count, entry.getValue());
						addHourpart = false;
					} else if (!entry.getKey().equals("SUMMHOUR") && !entry.getKey().equals("HOURPART")) {
						if (entry.getKey().equals("TVSU_PER") || entry.getKey().equals("XFR_PER")) {
							strVal = entry.getValue().toString();
							if (!("'x%'".equals(strVal) || "x".equals(strVal) || "'x'".equals(strVal))) {
								val = Double.parseDouble(strVal);
								//rowMap.put(entry.getKey() + count, //PERCENTAGE CONVERSION
										//"'" + df.format((val > 100 ? val / 100 : val)) + "%'");
								rowMap.put(entry.getKey() + count,
										"'" + df.format(val) + "%'");
							}else {
								rowMap.put(entry.getKey() + count,"'" + strVal + "%'");
							}
						} else {
							rowMap.put(entry.getKey() + count, entry.getValue());
						}

					}
				}
			}

		}
		singleRowList.add(rowMap);
		
		return singleRowList;
	}

	public Map<String, Object> setFinalDataForDisplay(Map<String, List<List<Map<String, Object>>>> listOfListOfMapData,
			HttpSession session) {

		Map<String, Object> returnData = new LinkedHashMap<String, Object>();
		List<String> dates = new ArrayList<String>();
		Map<String, List<List<Object>>> convertedData = new LinkedHashMap<>();
		Map<String, List<Map<String, Object>>> convertedCalculationData = new LinkedHashMap<String, List<Map<String, Object>>>();
		List<List<Map<String, Object>>> innerListData = null;
		List<List<Object>> convertedInnerList = null;
		List<Object> convertedMapList = null;
		Map<String, Object> convertedCalculationMap = null;
		List<Map<String, Object>> convertedCalculationMapList = null;
		String checKey;
		boolean addSummhour;
		int count = 0;
		for (Map.Entry<String, List<List<Map<String, Object>>>> entry : listOfListOfMapData.entrySet()) {
			innerListData = entry.getValue();
			convertedInnerList = new ArrayList<>();
			convertedCalculationMapList = new ArrayList<Map<String, Object>>();
			addSummhour = true;
			count++;

			for (List<Map<String, Object>> innerList : innerListData) {
				convertedMapList = new ArrayList<>();
				convertedCalculationMap = new LinkedHashMap<String, Object>();

				for (Map<String, Object> map : innerList) {

					for (Map.Entry<String, Object> entryMap : map.entrySet()) {
						checKey = entryMap.getKey().substring(0, entryMap.getKey().length() - 1);

						if (checKey.equals("RESERVE3")) {
							if (!dates.contains("'" + entryMap.getValue() + "'")) {
								dates.add("'" + entryMap.getValue() + "'");
							}
						}

						if (checKey.equals("SUMMHOUR") && addSummhour) {
							convertedMapList.add("'" + entryMap.getValue() + "*'");
							convertedCalculationMap.put(entryMap.getKey(),
									entryMap.getValue().toString().replace("'", "").replace("%", "") + "*");
							addSummhour = false;
						} else if (!checKey.equals("SUMMHOUR") && !checKey.equals("RESERVE3")) {
							convertedMapList
									.add(checKey.equals("HOURPART") ? entryMap.getValue() : entryMap.getValue());
							if (!checKey.equals("HOURPART")) {
								convertedCalculationMap.put(entryMap.getKey(), entryMap.getValue().toString()
										.replace("'", "").replace("%", "").replace("x", "0"));
							}
						}
					}
				}

				convertedMapList = convertedMapList.stream()
						.map(element -> (element instanceof Integer && (Integer) element == 0)
								|| (element instanceof String && ("'x%'".equals(element) || "x".equals(element)))
										? "'-'"
										: element)
						.collect(Collectors.toList());

				convertedInnerList.add(convertedMapList);
				convertedCalculationMapList.add(convertedCalculationMap);
			}

			convertedData.put("SUMM_HOUR" + count, convertedInnerList);
			/* System.out.println("convertedInnerList: "+convertedInnerList); */
			convertedCalculationData.put("SUMM_HOUR_CAL" + count, convertedCalculationMapList);
		}

		/* System.out.println("convertedCalculationData: "+convertedCalculationData); */
		returnData.put("SUMMHOURS_DATA", CommonLogic.sortFinalData(convertedData));// data type : Map<String,
																					// List<List<Object>>>
		returnData.put("SUMMHOURS_CALCULATION_DATA", CommonLogic
				.sotedFinalCalculationData(this.calculationRowForEachSummhour(convertedCalculationData, session)));// data
																													// type
																													// :
																													// Map<String,
																													// List<Object>>

		returnData.put("DATE_HEADER", dates);

		return returnData;
	}

	public static Map<String, List<List<Object>>> sortFinalData(Map<String, List<List<Object>>> data) {
		data = data.entrySet().stream().sorted(Comparator.comparing(entry -> {
			List<Object> valueList = entry.getValue().get(0);
			/* System.out.println("valueList: "+valueList); */
			if (valueList.get(0) instanceof String) {

				try {
					return Integer.parseInt(valueList.get(0).toString().replace("'", "").replace("*", ""));
				} catch (NumberFormatException e) {

					return 0;
				}
			} else if (valueList.get(0) instanceof Integer) {
				return (Integer) valueList.get(0);
			} else {
				return 0;
			}
		})).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));

		// Step 2: Update the keys
		int i = 1;
		Map<String, List<List<Object>>> updatedData = new LinkedHashMap<>();
		for (Map.Entry<String, List<List<Object>>> entry : data.entrySet()) {
			updatedData.put("SUMM_HOUR" + i, entry.getValue());
			i++;
		}

		return updatedData;
	}

	public Map<String, List<Object>> calculationRowForEachSummhour(Map<String, List<Map<String, Object>>> data,
			HttpSession session) {
		/* System.out.println("calculation data: "+data); */
		DecimalFormat df = new DecimalFormat("#.##");
		Map<String, List<Object>> calculatedDataRow = new LinkedHashMap<String, List<Object>>();
		List<Object> eachSumhourCalculation = null;
		int keyCount = 1;
		int sessionCount = 1;
		/* System.out.println( session.getAttribute("noOfDates")); */
		int noOfdates = (int) session.getAttribute("noOfDates");
		for (Map.Entry<String, List<Map<String, Object>>> allSummhoursGroups : data.entrySet()) {

			double tvOffered1 = 0.0, tvSuccess1 = 0.0, tvXfr1 = 0.0, tvSucessPerc1 = 0.0, tvXfrPerc1 = 0.0;
			double tvOffered2 = 0.0, tvSuccess2 = 0.0, tvXfr2 = 0.0, tvSucessPerc2 = 0.0, tvXfrPerc2 = 0.0;
			double tvOffered3 = 0.0, tvSuccess3 = 0.0, tvXfr3 = 0.0, tvSucessPerc3 = 0.0, tvXfrPerc3 = 0.0;

			String totalTitle = "";
			int totalRowsIngroup = 0;// allSummhoursGroups.getValue().size();

			for (Map<String, Object> eachSummhourGroup : allSummhoursGroups.getValue()) {

				for (Map.Entry<String, Object> eachRowOfPerticularSummhour : eachSummhourGroup.entrySet()) {
					String blockNo = "";
					String key = "";
					double val = 0.0;

					if (!eachRowOfPerticularSummhour.getKey()
							.substring(0, eachRowOfPerticularSummhour.getKey().length() - 1).equals("SUMMHOUR")) {
						blockNo = eachRowOfPerticularSummhour.getKey()
								.substring(eachRowOfPerticularSummhour.getKey().length() - 1);
						key = eachRowOfPerticularSummhour.getKey().substring(0,
								eachRowOfPerticularSummhour.getKey().length() - 1);
						val = getTypeCatedValue(eachRowOfPerticularSummhour.getValue());
					}

					if (eachRowOfPerticularSummhour.getKey()
							.substring(0, eachRowOfPerticularSummhour.getKey().length() - 1).equals("SUMMHOUR")) {
						totalTitle = "'" + eachRowOfPerticularSummhour.getValue() + " Total'";
					} else {
						if (blockNo.equals("1")) {
							if (key.equals("TVOFFERED")) {
								tvOffered1 += val;
							} else if (key.equals("TVSUCCESS")) {
								tvSuccess1 += val;
							} else if (key.equals("TRANSFER")) {
								tvXfr1 += val;
							} else if (key.equals("TVSU_PER")) {
								tvSucessPerc1 += val;
							} else if (key.equals("XFR_PER")) {
								tvXfrPerc1 += val;
							}
						} else if (blockNo.equals("2")) {
							if (key.equals("TVOFFERED")) {
								tvOffered2 += val;
							} else if (key.equals("TVSUCCESS")) {
								tvSuccess2 += val;
							} else if (key.equals("TRANSFER")) {
								tvXfr2 += val;
							} else if (key.equals("TVSU_PER")) {
								tvSucessPerc2 += val;
							} else if (key.equals("XFR_PER")) {
								tvXfrPerc2 += val;
							}
						} else if (blockNo.equals("3")) {
							if (key.equals("TVOFFERED")) {
								tvOffered3 += val;
							} else if (key.equals("TVSUCCESS")) {
								tvSuccess3 += val;
							} else if (key.equals("TRANSFER")) {
								tvXfr3 += val;
							} else if (key.equals("TVSU_PER")) {
								tvSucessPerc3 += val;
							} else if (key.equals("XFR_PER")) {
								tvXfrPerc3 += val;
							}
						}
					}
				}
			}
			totalRowsIngroup = (int) session.getAttribute("NoOfAvailableHourParts" + sessionCount);
			// System.out.println("totalRowsIngroup: "+totalRowsIngroup);
			sessionCount++;
			tvSucessPerc1 = tvSucessPerc1 > 0 ? tvSucessPerc1 / totalRowsIngroup : 0.0;
			tvXfrPerc1 = tvXfrPerc1 > 0 ? tvXfrPerc1 / totalRowsIngroup : 0.0;

			tvSucessPerc2 = tvSucessPerc2 > 0 ? tvSucessPerc2 / totalRowsIngroup : 0.0;
			tvXfrPerc2 = tvXfrPerc2 > 0 ? tvXfrPerc2 / totalRowsIngroup : 0.0;

			tvSucessPerc3 = tvSucessPerc3 > 0 ? tvSucessPerc3 / totalRowsIngroup : 0.0;
			tvXfrPerc3 = tvXfrPerc3 > 0 ? tvXfrPerc3 / totalRowsIngroup : 0.0;

			eachSumhourCalculation = new ArrayList<Object>();
			if (noOfdates >= 1) {
				eachSumhourCalculation.add(totalTitle);
				eachSumhourCalculation.add(df.format(tvOffered1));
				eachSumhourCalculation.add(df.format(tvSuccess1));
				eachSumhourCalculation.add(df.format(tvXfr1));
				eachSumhourCalculation
						.add("'" + df.format(tvSucessPerc1 > 100 ? tvSucessPerc1 / 100 : tvSucessPerc1) + "%'");
				eachSumhourCalculation.add("'" + df.format(tvXfrPerc1 > 100 ? tvXfrPerc1 / 100 : tvXfrPerc1) + "%'");
			}
			if (noOfdates >= 2) {
				eachSumhourCalculation.add(df.format(tvOffered2));
				eachSumhourCalculation.add(df.format(tvSuccess2));
				eachSumhourCalculation.add(df.format(tvXfr2));
				eachSumhourCalculation
						.add("'" + df.format(tvSucessPerc2 > 100 ? tvSucessPerc2 / 100 : tvSucessPerc2) + "%'");
				eachSumhourCalculation.add("'" + df.format(tvXfrPerc2 > 100 ? tvXfrPerc2 / 100 : tvXfrPerc2) + "%'");
			}
			if (noOfdates == 3) {
				eachSumhourCalculation.add(df.format(tvOffered3));
				eachSumhourCalculation.add(df.format(tvSuccess3));
				eachSumhourCalculation.add(df.format(tvXfr3));
				eachSumhourCalculation
						.add("'" + df.format(tvSucessPerc3 > 100 ? tvSucessPerc3 / 100 : tvSucessPerc3) + "%'");
				eachSumhourCalculation.add("'" + df.format(tvXfrPerc3 > 100 ? tvXfrPerc3 / 100 : tvXfrPerc3) + "%'");
			}

			calculatedDataRow.put("SUMM_HOUR_CALROW" + keyCount, eachSumhourCalculation);
			keyCount++;

		}
		/* System.out.println("calculatedDataRow: "+calculatedDataRow); */
		return calculatedDataRow;
	}

	private double getTypeCatedValue(Object value) {
		double val = 0.0;
		if (value != null) {
			if (value instanceof Double) {
				// If the value is already a Double, simply cast it
				val = (Double) value;
			} else if (value instanceof Integer) {
				// If it's another numeric type, you can convert it
				val = ((Integer) value).doubleValue();
			} else if (value instanceof String) {

				val = Double.parseDouble((String) value);

			}
		}
		return val;
	}

	public static Map<String, List<Object>> sotedFinalCalculationData(Map<String, List<Object>> data) {
		List<Map.Entry<String, List<Object>>> entries = new ArrayList<>(data.entrySet());

		// Sort the entries based on the first element in each list
		Collections.sort(entries, (entry1, entry2) -> {
			String key1 = (String) entry1.getValue().get(0);
			String key2 = (String) entry2.getValue().get(0);
			int intKey1 = Integer.parseInt(key1.split(" ")[0].replace("'", "").replace("*", ""));
			int intKey2 = Integer.parseInt(key2.split(" ")[0].replace("'", "").replace("*", ""));
			return Integer.compare(intKey1, intKey2);
		});

		// Create a new sorted map with the renamed keys
		Map<String, List<Object>> sortedData = new LinkedHashMap<>();
		for (int i = 0; i < entries.size(); i++) {
			String newKey = "SUMM_HOUR_CALROW" + (i + 1);
			sortedData.put(newKey, entries.get(i).getValue());

		}
		return sortedData;
	}
}
