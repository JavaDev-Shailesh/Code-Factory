package com.ibm.tvdshboardapplication.util;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class GenerateExcelUtil {

	private Workbook workbook = null;
	private Sheet sheet = null;
	private int startRowNo;
	private String[] colNames = null;
	private String[] colAlignments = null;
	private String[] colBgColors = null;
	private int[] colSizes = null;
	private int[] colColspan = null;

	public void generateExcel(OutputStream outputStream, List<Map<String, Object>> tableHeaders,
			List<Map<String, Object>> tableRows) throws IOException {

		this.startRowNo = 0;
		this.workbook = new XSSFWorkbook();
		this.sheet = workbook.createSheet("TV-Volume Sheet");

		for (Map<String, Object> headers : tableHeaders) {
			setTableHeader(this.startRowNo, this.workbook, this.sheet, headers);
		}

		for (Map<String, Object> rows : tableRows) {
			setTableRows(this.startRowNo, this.workbook, this.sheet, rows);
		}

		workbook.write(outputStream);
		workbook.close();
	}

	private void setTableHeader(int rowNo, Workbook workbook, Sheet sheet, Map<String, Object> headerData) {

		int colmWidth = 0;
		if (headerData != null && headerData.size() > 0) {
			this.colNames = headerData.get("colNames") != null ? (String[]) headerData.get("colNames") : null;
			this.colAlignments = headerData.get("colAlignments") != null ? (String[]) headerData.get("colAlignments")
					: null;
			this.colBgColors = headerData.get("colBgColors") != null ? (String[]) headerData.get("colBgColors") : null;
			this.colSizes = headerData.get("colSizes") != null ? (int[]) headerData.get("colSizes") : null;
			this.colColspan = headerData.get("colColspan") != null ? (int[]) headerData.get("colColspan") : null;
		}

		Row headerRow = sheet.createRow(rowNo);
		if (this.colNames != null && this.colNames.length > 0) {
			for (int i = 0; i < this.colNames.length; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(this.colNames[i]);

				// Apply cell alignment based on the provided strings
				if (this.colAlignments != null && i < this.colAlignments.length) {
					HorizontalAlignment alignment = getHorizontalAlignment(this.colAlignments[i]);
					CellStyle headerCellStyle = workbook.createCellStyle();
					headerCellStyle.setAlignment(alignment);
					cell.setCellStyle(headerCellStyle);
				}

				// Set background color for the header cell
				if (this.colBgColors != null && i < this.colBgColors.length) {
					String bgColor = this.colBgColors[i];
					if (bgColor != null && !bgColor.isEmpty()) {
						CellStyle headerCellStyle = cell.getCellStyle();
						short colorIndex = IndexedColors.valueOf(bgColor.toUpperCase()).getIndex();
						headerCellStyle.setFillForegroundColor(colorIndex);
						headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
					}
				}

				if (this.colSizes != null && this.colSizes.length > 0 && i < this.colSizes.length) {
					colmWidth = colSizes[i] > 0 ? colSizes[i] : 20000;
				}
				sheet.setColumnWidth(i, colmWidth);

				// Apply cell borders
				CellStyle borderCellStyle = cell.getCellStyle();
				borderCellStyle.setBorderTop(BorderStyle.MEDIUM);
				borderCellStyle.setBorderBottom(BorderStyle.MEDIUM);
				borderCellStyle.setBorderLeft(BorderStyle.MEDIUM);
				borderCellStyle.setBorderRight(BorderStyle.MEDIUM);

				// Set a dark color for the border
				borderCellStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
				borderCellStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
				borderCellStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
				borderCellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			}

			if (this.colColspan != null && this.colColspan.length > 0) {
				Map<String, Object> table = mergeColumn(rowNo, workbook, sheet, this.colColspan);
				sheet = (Sheet) table.get("Sheet");
				workbook = (Workbook) table.get("Workbook");
			}
		}

		this.sheet = sheet;
		this.workbook = workbook;
		this.startRowNo = ++rowNo;
	}

	private void setTableRows(int rowNo, Workbook workbook, Sheet sheet, Map<String, Object> rowData) {
		/* System.out.println("rowData: "+rowData); */
		// Create a cell style with center alignment and borders
		CellStyle style = workbook.createCellStyle();
		style.setAlignment(HorizontalAlignment.CENTER);
		style.setVerticalAlignment(VerticalAlignment.CENTER);
		style.setBorderTop(BorderStyle.THIN);
		style.setBorderBottom(BorderStyle.THIN);
		style.setBorderLeft(BorderStyle.THIN);
		style.setBorderRight(BorderStyle.THIN);

		int cellIndex = 1;
		int charIndex = rowData.get("key0").toString().length() == 2 ? 1 : rowData.get("key0").toString().length() == 3  ? 2 : 0;
		if(rowData.containsKey("key")) {
			String arr[] = rowData.get("key0").toString().split(" ");
			charIndex = arr[0].length() == 2 ? 1 : arr[0].length() == 3 ? 2 : 0;
		}
		if (rowData.get("key0").toString().length() > 1 && rowData.get("key0").toString().charAt(charIndex) == '*') {
			cellIndex = 0;
		}
        
		Row row = sheet.createRow(rowNo);
		for (String key : rowData.keySet()) {
			Cell cell = row.createCell(cellIndex);
			cell.setCellValue(rowData.get(key).toString().replace("*", ""));
			cell.setCellStyle(style);
			cellIndex++;
		}
		

		if (rowData.get("key0").toString().length() > 1 && rowData.get("key0").toString().charAt(charIndex) == '*' && !rowData.containsKey("key") ) {
			CellRangeAddress mergedRegion = new CellRangeAddress(rowNo, rowNo + 3, 0, 0);
			sheet.addMergedRegion(mergedRegion);
			// Get the merged cell and apply vertical alignment and color
			Row mergedRow = sheet.getRow(rowNo); // Get the first row of the merged region
			Cell mergedCell = mergedRow.getCell(0); // Get the cell in column 0 of the merged region
			CellStyle mergedCellStyle = workbook.createCellStyle();
			mergedCellStyle.cloneStyleFrom(style); // Copy the existing style
			mergedCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			mergedCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			mergedCell.setCellStyle(mergedCellStyle);

		}
		/* System.out.println("charIndex: "+charIndex); */
		  // add calculation row condition here 
		if ( rowData.get("key0").toString().length() > 1 && rowData.get("key0").toString().charAt(charIndex) == '*'  && rowData.containsKey("key")) {
		  
		  CellRangeAddress mergedRegion = new CellRangeAddress(rowNo, rowNo, 0, 1);
		  sheet.addMergedRegion(mergedRegion);
		  
		  CellStyle calculationCellStyle = workbook.createCellStyle();
		  calculationCellStyle.cloneStyleFrom(style); // Copy the existing style
		  calculationCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		  calculationCellStyle.setFillForegroundColor(IndexedColors.BROWN.getIndex());
		  
		  Font boldWhiteFont = workbook.createFont();
		    boldWhiteFont.setBold(true);
		    boldWhiteFont.setColor(IndexedColors.WHITE.getIndex());
		    calculationCellStyle.setFont(boldWhiteFont);
		    
		  for (int i = 0; i < cellIndex; i++) { 
			  Cell cell = row.getCell(i);
			  if (cell !=null) {
				  cell.setCellStyle(calculationCellStyle);
				  }
			  }		  
		  }
		 
		this.sheet = sheet;
		this.workbook = workbook;
		this.startRowNo = ++rowNo;
	}

	private static Map<String, Object> mergeColumn(int rowNo, Workbook workbook, Sheet sheet, int[] arrColspan) {

		Map<String, Object> map = new HashedMap<>();
		for (int i = 0; i < arrColspan.length; i++) {
			int colspan = arrColspan[i];
			if (colspan > 1) {
				CellRangeAddress cellRange = new CellRangeAddress(rowNo, rowNo, i, i + colspan - 1);
				sheet.addMergedRegion(cellRange);
			}
		}
		map.put("Sheet", sheet);
		map.put("Workbook", workbook);

		return map;
	}

	private static HorizontalAlignment getHorizontalAlignment(String alignment) {
		switch (alignment.toLowerCase()) {
		case "center":
			return HorizontalAlignment.CENTER;
		case "left":
			return HorizontalAlignment.LEFT;
		case "right":
			return HorizontalAlignment.RIGHT;
		default:
			return HorizontalAlignment.LEFT;
		}
	}
}
