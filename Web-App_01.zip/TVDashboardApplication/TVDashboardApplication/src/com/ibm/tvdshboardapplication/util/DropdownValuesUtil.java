package com.ibm.tvdshboardapplication.util;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;

public class DropdownValuesUtil {

	private static final List<String> CIRCLE = Arrays.asList("AP", "ASM", "BR", "CHN", "DL", "GJ", "HP", "HR", "JK",
			"KN", "KOL", "KR", "MH", "MP", "MUM", "NESA", "OR", "PB", "RJ", "TN", "UPE", "UPW", "WB");
	private static final List<String> SUMMHOUR = Arrays.asList("0","1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11",
			"12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23");
	private static final List<String> UPSS_ZONE = Arrays.asList("ZONE1", "ZONE2", "ZONE3", "ZONE4", "ZONE5");
	private static final List<String> CPOS_ZONE = Arrays.asList("ZONE1", "ZONE2", "ZONE3", "ZONE4");

	private static final List<String> UPSS_ZONE1_CIRCLES = Arrays.asList("CHN", "KN", "TN", "OR", "MP");
	private static final List<String> UPSS_ZONE2_CIRCLES = Arrays.asList("KR", "ASM", "NESA", "BR", "JK", "RJ", "WB");
	private static final List<String> UPSS_ZONE3_CIRCLES = Arrays.asList("DL", "UPE", "HR", "KOL", "PB", "UPW", "HP");
	private static final List<String> UPSS_ZONE4_CIRCLES = Arrays.asList("AP", "GJ");
	private static final List<String> UPSS_ZONE5_CIRCLES = Arrays.asList("MUM", "MH");

	private static final List<String> CPOS_ZONE1_CIRCLES = Arrays.asList("CHN", "KN", "PB", "TN", "KR", "ASM", "NESA",
			"MP", "HP", "JK");
	private static final List<String> CPOS_ZONE2_CIRCLES = Arrays.asList("AP", "KOL", "MUM", "WB", "UPW");
	private static final List<String> CPOS_ZONE3_CIRCLES = Arrays.asList("GJ", "MH", "BR");
	private static final List<String> CPOS_ZONE4_CIRCLES = Arrays.asList("DL", "UPE", "HR", "RJ", "OR");

	private static final Map<String, Object> getDropdownData = new HashedMap<String, Object>();

	public static Map<String, Object> getDropdownData() {

		getDropdownData.put("circleList", CIRCLE);
		getDropdownData.put("summhour", SUMMHOUR);
		getDropdownData.put("upsszone", UPSS_ZONE);
		getDropdownData.put("cposzone", CPOS_ZONE);

		getDropdownData.put("upss_zone1_circles", UPSS_ZONE1_CIRCLES);
		getDropdownData.put("upss_zone2_circles", UPSS_ZONE2_CIRCLES);
		getDropdownData.put("upss_zone3_circles", UPSS_ZONE3_CIRCLES);
		getDropdownData.put("upss_zone4_circles", UPSS_ZONE4_CIRCLES);
		getDropdownData.put("upss_zone5_circles", UPSS_ZONE5_CIRCLES);

		getDropdownData.put("cpos_zone1_circles", CPOS_ZONE1_CIRCLES);
		getDropdownData.put("cpos_zone2_circles", CPOS_ZONE2_CIRCLES);
		getDropdownData.put("cpos_zone3_circles", CPOS_ZONE3_CIRCLES);
		getDropdownData.put("cpos_zone4_circles", CPOS_ZONE4_CIRCLES);

		return getDropdownData;
	}

}
