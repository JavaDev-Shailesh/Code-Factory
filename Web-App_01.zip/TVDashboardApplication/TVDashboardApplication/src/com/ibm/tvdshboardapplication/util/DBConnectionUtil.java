package com.ibm.tvdshboardapplication.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DBConnectionUtil {

	private static final Logger LOGGER = LogManager.getLogger(DBConnectionUtil.class);

	public static Connection getJDBCConnection() {
		Map<String,String> details = PropertiesUtil.getUrl();
		
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(details.get("URL").toString(), details.get("SCHEMA").toString(),
					details.get("PASSWORD").toString());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Error in database connection: ", e);
		}
		return conn;
	}

}
