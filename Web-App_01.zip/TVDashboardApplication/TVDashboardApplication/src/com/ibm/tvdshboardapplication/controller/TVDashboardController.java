package com.ibm.tvdshboardapplication.controller;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.tvdshboardapplication.bean.InputFormBean;
import com.ibm.tvdshboardapplication.service.TVDashboardService;
import com.ibm.tvdshboardapplication.service.TVDashboardServiceImpl;

//http://localhost:8082/TVDashboardApplication/
@Controller
public class TVDashboardController {
	
	private static final Logger LOGGER = LogManager.getLogger(TVDashboardController.class);
	
	@RequestMapping(value = "/", method = RequestMethod.GET )
	public String loadTvDashboardService(Model model) {
		TVDashboardService dashboardService = null;
		Map<String, Object> dropdownData = null;
		try {
			dashboardService = new TVDashboardServiceImpl();
			dropdownData = dashboardService.getDropdownData();

			model.addAttribute("circleList", dropdownData.get("circleList"));
			model.addAttribute("summhour", dropdownData.get("summhour"));
			model.addAttribute("upsszone", dropdownData.get("upsszone"));
			model.addAttribute("cposzone", dropdownData.get("cposzone"));

			model.addAttribute("upss_zone1_circles", dropdownData.get("upss_zone1_circles"));
			model.addAttribute("upss_zone2_circles", dropdownData.get("upss_zone2_circles"));
			model.addAttribute("upss_zone3_circles", dropdownData.get("upss_zone3_circles"));
			model.addAttribute("upss_zone4_circles", dropdownData.get("upss_zone4_circles"));
			model.addAttribute("upss_zone5_circles", dropdownData.get("upss_zone5_circles"));

			model.addAttribute("cpos_zone1_circles", dropdownData.get("cpos_zone1_circles"));
			model.addAttribute("cpos_zone2_circles", dropdownData.get("cpos_zone2_circles"));
			model.addAttribute("cpos_zone3_circles", dropdownData.get("cpos_zone3_circles"));
			model.addAttribute("cpos_zone4_circles", dropdownData.get("cpos_zone4_circles"));

		} catch (Exception e) {
			LOGGER.error("Exception Occoured In TVDashboardController > loadTvDashboardService : ", e);
		}

		return "tvdashboard";
	}

	@RequestMapping(value = "/dashboardReport", method = RequestMethod.POST)
	public ModelAndView submitForm(@ModelAttribute InputFormBean inputFormBean, HttpSession session) {
		
		TVDashboardService dashboardService = null;
		ModelAndView modelAndView = null;
		try {
			modelAndView = new ModelAndView();
			dashboardService = new TVDashboardServiceImpl();
			modelAndView.setViewName("tvdashboardresponse");
			modelAndView.addObject("cricls",inputFormBean.getCircleDropdown());
			modelAndView.addObject("brand", inputFormBean.getBrandname());
			modelAndView.addObject("priOrPostPaid", inputFormBean.getPostorpre());
			 Map<String,List<String>>  zones = dashboardService.zonesNamesOnSelectedCircles(inputFormBean.getCircleDropdown());
			modelAndView.addObject("upssZones", zones.get("upss"));
			modelAndView.addObject("cposZones",  zones.get("cpos"));
			modelAndView.addObject("summhours", inputFormBean.getSummhourDopdown()); 
			modelAndView = dashboardService.getTableRowData(modelAndView, inputFormBean, session);
		} catch (Exception e) {
			e.printStackTrace();
			modelAndView.addObject("error","Internal Server Error..!");
			LOGGER.error("Exception Occoured In TVDashboardController > loadTvDashboardService : ", e);
		}
		return modelAndView;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/genarateExcel", method = RequestMethod.GET)
	public ResponseEntity<byte[]> genarateExcel(HttpServletRequest httpServletRequest,HttpSession session) {

		TVDashboardService dashboardService = null;
		ByteArrayOutputStream outputStream = null;
		HttpHeaders headers = null;
		Map<String, Object> tableData = null;
		byte[] excelBytes = null;
		try {
			tableData =  (Map<String, Object>) session.getAttribute("tableData"); 
			dashboardService = new TVDashboardServiceImpl();
			outputStream = new ByteArrayOutputStream();
			dashboardService.genarateExcel(outputStream,httpServletRequest.getParameter("reportTitle"), tableData);

			headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH_mm_ss");
			
			String timestamp = dateFormat.format(new Date());
			String fileName = "TV-Volume_" + timestamp + ".xlsx";
       
			headers.setContentDispositionFormData("attachment", fileName);
			excelBytes = outputStream.toByteArray();
			
			
			return ResponseEntity.ok().headers(headers).body(excelBytes);
		} catch (Exception e) {

			LOGGER.error("Exception Occoured In TVDashboardController > genarateExcel : ", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new byte[0]);
		}
	}
}

