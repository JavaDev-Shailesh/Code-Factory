package com.alpha.programmingSession2;

public class CountWords {
    public static void main(String[] args) {
		String str="This is a class";
		String []arry=str.split(" ");
		System.out.println(str +": total words in given string: "+arry.length);
	}
}
