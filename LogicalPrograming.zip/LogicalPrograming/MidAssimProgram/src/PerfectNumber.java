import java.util.Scanner;
class PerfectNumber
{
	public static void inputSort(int num1,int num2)
	{
		int a,b;
		if(num1<=num2)
		{
			a=num1; b=num2;
		}
     	else
		{
			a=num2; b=num1;
		}
		
		perfectNumber(a,b);
	}
	public static void perfectNumber(int num1, int num2)
	{
		for(int i=num1; i<=num2; i++)
		{
			int sum=0;
			for(int j=1; j<i; j++)
			{
				if(i%j==0)
				{
					sum+=j;
				}
			}
			if(sum==i)
				System.out.print(i+" ");	
		}
	}
	public static void main(String[]args)
	{
		Scanner sc1= new Scanner(System.in);
		System.out.println("enter range1: ");
		int num1=sc1.nextInt();
		System.out.println("enter range2: ");
		int num2=sc1.nextInt();
		inputSort(num1,num2);
	}
	
	
}