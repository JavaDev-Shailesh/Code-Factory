import java.util.Scanner;
class ArmStrongNumberInrange
{
	public static void sortInputs(int num1, int num2)
	{
		int a,b;
		if(num1<num2)
		{
			a=num1; b=num2;
		}
		else 
		{
			a=num2; b=num1;
		}
		System.out.println("a: "+a+" b: "+b);
	    armStrongNumberInrange(a,b);
	}
	public static void armStrongNumberInrange(int num1, int num2)
	{
		for(int i=num1; i<=num2; i++)
		{
			int sum=0;
			int rem=0;
			int count=0;
			int copyI=i;
			int copyI2=i;
			
			while(copyI2!=0)
			{
				count++;
				copyI2=copyI2/10;
			}
			while(copyI!=0)
			{
				int mult=1;
				rem=copyI%10;
				for(int j=1; j<=count; j++)
				{
					mult*=rem;//3*3*3 5*5*5 1*1*1
				}
				sum+=mult;//+27 +125 +1
				copyI=copyI/10;//15  1
			}
			if(sum==i) //153==153
			   System.out.print(i+" ");
		}
	}
	public static void main(String[]args)
	{
		Scanner sc1= new Scanner(System.in);
		System.out.println("enter num1: ");
		int num1=sc1.nextInt();
		System.out.println("enter num2: ");
		int num2=sc1.nextInt();
		sortInputs(num1,num2);
	}
	
}