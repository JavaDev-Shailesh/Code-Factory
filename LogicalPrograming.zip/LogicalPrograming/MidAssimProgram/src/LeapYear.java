import java.util.Scanner;
class LeapYear
{
	 static void leapYear(int year)
	 {
		 if(year%4==0)
			 System.out.println(year+" :is a leap year");
		 else
			  System.out.println(year+" :is a Not-leap year");
	 }
	public static void main(String[]args)
	{
	  Scanner sc1=new Scanner(System.in);
	  System.out.print("enter year: ");
	  int year=sc1.nextInt();
	  leapYear(year);
	}
}