class P1
{
	public static void main(String[]args)
	{
		int sum=0;
	   for(int i=0; i<args.length; i++)
	   {
		   int num1=Integer.parseInt(args[i]);
		   sum+=num1;
	   }
	   System.out.println("sum: "+sum);
	}
}