import java.util.Scanner;
class FactorialOfNumber
{
	public static void factorialOfNumber(int num)
	{
		int mult=1;
		for(int i=1; i<=num; i++)
		{
			mult*=i;
		}
		System.out.println("factorial of "+num+": "+mult);
	}
	public static void main(String[]args)
	{
		Scanner sc1=new Scanner(System.in);
		System.out.println("enter number: ");
		int num=sc1.nextInt();
		factorialOfNumber(num);
	}
	
}