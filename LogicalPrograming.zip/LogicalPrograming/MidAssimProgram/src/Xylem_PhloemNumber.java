
import java.util.Scanner;
class Xylem_PhloemNumber
{
	
	public static int addFirt_and_LastDigit(int num)
	{
		int copyNum=num;
		int rem1=num%10;//last no.
		int rem2=0;//1st no.
		while(copyNum!=0)
		{
			rem2=copyNum%10;
			copyNum=copyNum/10;
		}
		int sum1=rem1+rem2;
		return sum1;
	}
	
	public static void xylem_PhloemNumber(int num)
	{
		int sum1=addFirt_and_LastDigit(num);
		int sum2=0;
		int rem=0;
		while(num!=0)
		{
		  rem=num%10;
		  sum2+=rem;
		  num=num/10;
		}
		sum2-=sum1;
		if(sum2==sum1)
			System.out.println("given number is Xylem..");
		else
			System.out.println("given number is Phloem..");
	}
	public static void main(String[]args)
	{
		Scanner sc1= new Scanner(System.in);
		System.out.println("enter num: ");
		int num=sc1.nextInt();
		xylem_PhloemNumber(num);
		
	}
}
