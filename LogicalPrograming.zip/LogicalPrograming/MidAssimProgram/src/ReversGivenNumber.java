
import java.util.Scanner;
class ReversGivenNumber
{
	public static void reversNumber(int num)
	{
		int copyNum=num;
	  int rem=0;
	  int sum=0;
	  while(num!=0)
	  {
        rem=num%10;
		sum=(sum*10)+rem;
		num=num/10;
	  }
	  System.out.println(copyNum+": revers of given number: "+sum);
	}
	public static void main(String[]args)
	{
	  Scanner sc1=new Scanner(System.in);
	  System.out.print("enter number: ");
	  int num=sc1.nextInt();
	  reversNumber(num);
	}
	
	
}