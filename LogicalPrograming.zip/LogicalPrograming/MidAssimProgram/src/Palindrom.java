package com.alpha.programmingSession2;

import java.util.Scanner;

public class Palindrom {
     public static void main(String[] args) {
    	 Scanner sc1=new Scanner(System.in);
		System.out.println("plz enter the start range: ");
		int start=sc1.nextInt();
		System.out.println("plz enter the end range: ");
		int end=sc1.nextInt();
		int count=0;
		
		for(int i=start; i<=end; i++)
		{
			int x=i;
			int b=0;
			int sum=0;
			while(x!=0)
			{
				b=x%10;
				sum=(sum*10)+b;
				x=x/10;
			}
			 if(sum==i)
			 {
				 count++;
			  System.out.print(i+" ");
			 }
	
		}
		System.out.println("\nTotal palindrom in between:\n"+start +" To "+end+": "+count);
		
	}
}
