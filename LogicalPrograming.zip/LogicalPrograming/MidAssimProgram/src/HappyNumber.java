
import java.util.Scanner;
class HappyNumber
{
	
	public static int happyNumber1(int num)
	{
		int ret1=0;
		int copyNum=num;
		int sum=0;
		int rem=0;
		while(copyNum!=0)
		{
			rem=copyNum%10;
			sum+=(rem*rem);
			copyNum=copyNum/10;
		}
		if(sum!=1)
		{
			if(sum>9)
				ret1=happyNumber1(sum);
		}
		else
			ret1=sum;
			return ret1;
	}
	
	public static void main(String[]args)
	{
		Scanner sc1= new Scanner(System.in);
		System.out.println("enter num: ");
		int num=sc1.nextInt();
		int x=happyNumber1(num);
		  if(x==1)
		 {
			System.out.println(num+" :is happy   no");
		 }
		else
		{
		 System.out.println(num+" :is not happy no"); 
		}
		
	}
	
}