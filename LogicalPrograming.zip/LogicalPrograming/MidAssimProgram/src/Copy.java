import java.io.*;
class Copy
{
	public static void main(String[]args)throws IOException
	{
	  String orgFilePath=args[0];
	  String CopyFIlePath=args[1];
	  
	  FileReader fr=new FileReader(orgFilePath);//orignal path
	  BufferedReader bf=new BufferedReader(fr);//pass path to read
	  String str=bf.readLine();
	  
	  
	  FileOutputStream fos=new FileOutputStream(CopyFIlePath);
	  PrintWriter prw=new PrintWriter(fos);//writer use to write data
	  while(str!=null)
	  {
		
	    prw.println(str);
		prw.flush();//use to flush the privious pased line and ready to accept new line data
		str=bf.readLine();
		
	  }
	  
	}
}

