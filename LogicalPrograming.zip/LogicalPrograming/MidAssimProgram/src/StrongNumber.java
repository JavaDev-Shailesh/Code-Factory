import java.util.Scanner;
class StrongNumber
{
   public static void inputSort(int num1,int num2)
	{
		int a,b;
		if(num1<=num2)
		{
			a=num1; b=num2;
		}
     	else
		{
			a=num2; b=num1;
		}
      strongNumber(a,b);
	}
	public static void strongNumber(int num1,int num2)
	{
		for(int i=num1; i<=num2; i++)
		{
	   
			int copyI=i;
			int sum=0;
			int rem=0;
			while(copyI!=0)
			{
				int mult=1;
				rem=copyI%10;
				for(int j=1; j<=rem; j++)
				{
					mult*=j;
				}
				sum+=mult;
				copyI=copyI/10;//11
			}
			if(sum==i)
				System.out.print(i+" ");
		}
	}
	
	public static void main(String[]args)
	{
		Scanner sc1= new Scanner(System.in);
		System.out.println("enter range1: ");
		int num1=sc1.nextInt();
		System.out.println("enter range2: ");
		int num2=sc1.nextInt();
		inputSort(num1,num2);
	}
}