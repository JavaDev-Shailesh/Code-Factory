import java.util.Scanner;
class SmallestDigitInGivenNO
{
	public static void smallestDigitInGivenNO(int num)
	{
		 int rem=0;
		 int x=num%10;
		 while(num!=0)
		 {   
			rem= num%10;
			if(x>rem)
				x=rem;
			num=num/10;
		 }
		 System.out.println("Small Dig: "+x);
	}
	public static void main(String[]args)
	{
	  Scanner sc1=new Scanner(System.in);
	  System.out.print("enter number: ");
	  int num=sc1.nextInt();
	  smallestDigitInGivenNO(num);
	}
	
	
	
}