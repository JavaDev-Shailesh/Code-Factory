import java.util.Scanner;
class FactorOfNumber
{
	public void factorOfNumber(int num)
	{
		System.out.print("Factor of "+num+": ");
	  	for(int i=1; i<=num;i++)
		{
			if(num%i==0)
				System.out.print(i+" ");
		}
		
	}
	public static void main(String[]args)
	{
		Scanner sc1=new Scanner(System.in);
		System.out.println("enter number: ");
		int num=sc1.nextInt();
		new FactorOfNumber().factorOfNumber(num);
		
	}
	
}
