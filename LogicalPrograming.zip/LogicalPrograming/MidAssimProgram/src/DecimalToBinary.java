package com.alpha.programmingSession2;

import java.util.Scanner;

public class DecimalToBinary {
   public static void main(String[] args) {
	   Scanner sc1=new Scanner(System.in);
	   System.out.println("plz enter decimal number: ");
	   
	int num=sc1.nextInt();
	int copyNum=num;
	int rem=1;
	String str="";
	while(num>=1)
	{
	 rem=num%2;//0 0 1 0 1
	 str+=rem;
	 num=num/2;//10 5 2 1
	}
	char []ch=str.toCharArray();
	System.out.print(copyNum+ " :binary value is: ");
	for(int i=ch.length-1; i>=0; i--)
	{
		System.out.print(ch[i]);
	}
}
}
