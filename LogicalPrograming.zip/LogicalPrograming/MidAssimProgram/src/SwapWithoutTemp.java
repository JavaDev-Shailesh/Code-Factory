import java.util.Scanner;
class SwapWithoutTemp
{
	public static void swapWithoutTemp(int num1, int num2)
	{
		num1=num1^num2;
		num2=num1^num2;
		num1=num1^num2;
		System.out.println("num1= "+num1+"\nnum2= "+num2);
	}
	public static void main(String[]args)
	{
		Scanner sc1= new Scanner(System.in);
		System.out.println("enter num1: ");
		int num1=sc1.nextInt();
		System.out.println("enter num2: ");
		int num2=sc1.nextInt();
		swapWithoutTemp(num1,num2);
	}
	
}