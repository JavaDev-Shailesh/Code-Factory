import java.util.Scanner;
class NeonNumber
{
  public static void neonNumber(int num)
  {
	 int sum=0;
	 int rem=0;
	 int copyNum=num*num;
	 while(copyNum!=0)
	 {
       rem=copyNum%10;
	   sum+=rem;
	   copyNum=copyNum/10;
	 }	
     if(sum==num)
		 System.out.println(num+" :given number is NEON NUMBER");
	 else
		 System.out.println(num+" :given number is Not-NEON NUMBER"); 		 
  }
  public static void main(String[]args)
	{
	  Scanner sc1=new Scanner(System.in);
	  System.out.print("enter number: ");
	  int num=sc1.nextInt();
	  neonNumber(num);
	}

}