import java.util.Scanner;
class PrimeNumber
{
    public void primeNumber(int num1, int num2)
    {
		for(int i=num1; i<=num2; i++)
		{
			int count=0;
			for(int j=1; j<=i; j++)
			{
				if(i%j==0)
					count++;
			}
			if(count==2)
			System.out.print(i+" ");
		}
    }		
    public void sortInpute(int num1,int num2)
	{
		int a,b;
		if(num1<num2)
		{
			a=num1;
		    b=num2;
		}
		else
		{
			b=num1;
			a=num2;
		}
		 primeNumber(a,b);   
	}
	
	public static void main(String[]args)
	{
		Scanner sc1= new Scanner(System.in);
		System.out.println("enter range1: ");
		int num1=sc1.nextInt();
		System.out.println("enter range2: ");
		int num2=sc1.nextInt();
		new PrimeNumber().sortInpute(num1,num2);
		
	}

}