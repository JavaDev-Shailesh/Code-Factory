
import java.util.Scanner;
class SumOfFirstAndLastDigit
{
  public static void sumOfFirstAndLastDigit(int num)	
  {   
       int copyNum=num;//123
	  int rem1=0;
	  int sum=0;
	  
	  while(num!=0)
	  {
		rem1=num%10;
        num=num/10;	//rem1=1
	  }
	  int rem2=copyNum%10;//rem2=3
	  sum=rem1+rem2;
	  System.out.println(copyNum+" :sum of 1st and last digit: "+sum);
  }
	public static void main(String[]args)
	{
	  Scanner sc1=new Scanner(System.in);
	  System.out.print("enter number: ");
	  int num=sc1.nextInt();
	  sumOfFirstAndLastDigit(num);
	}
	
}