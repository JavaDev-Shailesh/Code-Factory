/*Rohan Barve11:44 AM
Given two non-negative integers, num1 and num2 represented as string,
 return the sum of num1 and num2 as a string.
Result String should not have leading zeros.

You must solve the problem without using any built-in library for handling large integers (such as BigInteger). You must also not convert the inputs to integers directly.

num1 and num2 consist of only digits.
num1 and num2 don't have any leading zeros except for the zero itself.
"10"
"40"
"50"
*/

public class MainClass{
	
	public static void main(String [] args){
		String num1= "10";
		String num2="20";
		String arr[] = num1.split("");
	
		int a = Integer.parseInt(m1(arr));
		String arr1[] = num2.split("");
		int b = Integer.parseInt(m1(arr1));
		String outPut = String.valueOf((a+b));
		System.out.println(outPut);
	}

}