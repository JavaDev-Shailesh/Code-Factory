import java.util.Scanner;
class DigitsOfGiveNumber
{
	public static void digitsOfGiveNumber(int num)
	{
		int count=0;
		while(num!=0)
		{
			count++;
			num=num/10;
		}
		System.out.println("count of Digits in given number: "+count);	
	}
	public static void main(String[]args)
	{
	  Scanner sc1=new Scanner(System.in);
	  System.out.print("enter number: ");
	  int num=sc1.nextInt();
	  digitsOfGiveNumber(num);
	}
	
	
}