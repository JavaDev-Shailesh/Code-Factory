import java.util.Scanner;
class PalindromNumber
{
	public static void inputSort(int num1,int num2)
	{
		int a,b;
		if(num1<=num2)
		{
			a=num1; b=num2;
		}
     	else
		{
			a=num2; b=num1;
		}
        palindromNumber(a,b);
	}
	public static void palindromNumber(int num1, int num2)
	{
		for(int i=num1; i<=num2; i++)
		{
			int copyI=i;
			int sum=0;
			int rem=0;
			while(copyI!=0)
			{
				rem=copyI%10;
				sum=(sum*10)+rem;
				copyI=copyI/10;
			}
			if(sum==i)
				System.out.println(i+" :palindrom no");
		}
	}
	public static void main(String[]args)
	{
		Scanner sc1= new Scanner(System.in);
		System.out.println("enter range1: ");
		int num1=sc1.nextInt();
		System.out.println("enter range2: ");
		int num2=sc1.nextInt();
		inputSort(num1,num2);
	}
	
}