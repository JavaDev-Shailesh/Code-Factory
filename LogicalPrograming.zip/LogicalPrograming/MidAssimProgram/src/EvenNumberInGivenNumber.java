import java.util.Scanner;
class EvenNumberInGivenNumber
{
	public static void evenNumberInGivenNumber(int num)
	{   String str="";
		int rem=0;
		while(num!=0)
		{
			rem=num%10;
			if(rem%2==0)
			{
				str+=rem;
			}
			num=num/10;
		}
		
		for(int i=str.length()-1; i>=0; i--)
		{
			System.out.print(str.charAt(i)+" ");
		}
	}
	public static void main(String[]args)
	{
	  Scanner sc1=new Scanner(System.in);
	  System.out.print("enter number: ");
	  int num=sc1.nextInt();
	  evenNumberInGivenNumber(num);
	}
	
	
}
	