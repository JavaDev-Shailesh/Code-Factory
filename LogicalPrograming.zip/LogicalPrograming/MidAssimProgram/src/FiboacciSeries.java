import java.util.Scanner;
class FiboacciSeries
{
	public static void fabonacciSeries(int reng)
	{
		int a=0;
		int b=1;
		int c=0;
		for(int i=1; i<=reng; i++)
		{
			System.out.print(a+" ");
			c=a+b;
			a=b;
			b=c;
		}
	}
	public static void main(String[]args)
	{
	  Scanner sc1=new Scanner(System.in);
	  System.out.print("enter number: ");
	  int num=sc1.nextInt();
	  fabonacciSeries(num);
	}
	
}