package com.alpha.programmingSession2;

public class Pattern3 {
	public static void main(String[] args) {
		  int countLine=5;
		   int countStar=5;
		   int num=1;
		   for(int i=1; i<=countLine; i++)
		   {
			  for(int j=1; j<=countStar; j++)
			  {
			   System.out.print(num+" ");
			   num++;
			  }
			  System.out.println();
			  num=1;
		   }	  
 }
}