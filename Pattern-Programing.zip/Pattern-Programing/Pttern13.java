package com.alpha.programmingSession2;

public class Pttern13 {
	public static void main(String[] args) {

		int countLine=5;
		int countStar=5;
		int countSpace=0;
		String str="*";
		for(int i=1; i<=countLine; i++)
		{
			for(int k=1; k<=countSpace; k++)
			{
				System.out.print("  ");
			}
			for(int j=1; j<=countStar; j++)
			{
				System.out.print(str+" ");
			}
			System.out.println();
			countStar-=2;
			countSpace++;
		}                            /* * * * * *
		                                 * * * 
		                                   *   */
}
}
