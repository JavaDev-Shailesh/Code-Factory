package com.alpha.programmingSession2;

public class Pattern16 {
	public static void main(String[] args) {

		int countLine=5;
		int countStar=1;
		int countSpace=2;
        int mid=(countLine+1)/2;
		String str="*";
		for(int i=1; i<=countLine; i++)
		{
			for(int k=1; k<=countSpace; k++)
			{
				System.out.print("  ");
			}
			for(int j=1; j<=countStar; j++)
			{
				System.out.print(str+" ");
			}
			System.out.println();
			if(i<mid)
			{
			countStar+=2;
			countSpace--;
			}
			else
			{
				countStar-=2;
				countSpace++;
			}
		}                           
}

}
