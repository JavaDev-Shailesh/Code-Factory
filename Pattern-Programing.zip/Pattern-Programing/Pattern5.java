package com.alpha.programmingSession2;

public class Pattern5 {

	public static void main(String[] args) {
		  int countLine=5;
		   int countStar=5;
		   int num=1;
		   char ch='a';
		   for(int i=1; i<=countLine; i++)
		   {
			  for(int j=1; j<=countStar; j++)
			  {
			    if(j%2!=0)
			    {
			    	System.out.print(num+ " ");
			    	num++;
			    }
			    else
			    {
			    	System.out.print(ch+" ");
			    	ch++;
			    }
			  }
			  System.out.println();
			  num=1;
			  ch='a';
			  
		   }
		  
}
}
