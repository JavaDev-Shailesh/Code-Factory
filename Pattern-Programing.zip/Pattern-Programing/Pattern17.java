package com.alpha.programmingSession2;

public class Pattern17 {
     public static void main(String[] args) {
		int countLine=5;
		int countChar=1;
		char ch='A';
		int countSpace=4;
		int mid=(countLine+1)/2;
		
		for(int i=1; i<=countLine; i++)
		{
			for(int j=1; j<=countChar; j++)
			{
				if(j==1|| j==countChar)
				System.out.print(ch+" ");
				else
					System.out.print("  ");
				ch++;	
			}
			for(int k=1; k<=countSpace; k++)
			{
				System.out.print("  ");
			}
			
				ch--;
			
	        for(int l=1; l<=countChar; l++)
	        {
	        	if(l==1|| l==countChar)
					System.out.print(ch+" ");
					else
						System.out.print("  ");
					ch--;
	        }
	        System.out.println();
	        ch='A';
	        if(i<mid)
	        {
	        	countChar++;
	        	countSpace-=2;
	        }
	        else
	        {
	        	countChar--;
	        	countSpace+=2;
	        }
			
		}
	}
}
