package com.alpha.programmingSession2;

public class pattern12 {
	public static void main(String[] args) {

		int countLine=4;
		int countStar=1;
		int countSpace=3;
		String str="*";
		for(int i=1; i<=countLine; i++)
		{
			for(int k=1; k<=countSpace; k++)
			{
				System.out.print("  ");
			}
			for(int j=1; j<=countStar; j++)
			{
				if(j==1||j==countStar|| i==1 )
				System.out.print(str+" ");
				else
					System.out.print("  ");
			}
			System.out.println();
			countStar+=2;
			countSpace--;
		}
}
}
