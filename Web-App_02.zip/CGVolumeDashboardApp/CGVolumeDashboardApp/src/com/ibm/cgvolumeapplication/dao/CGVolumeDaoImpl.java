package com.ibm.cgvolumeapplication.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ibm.cgvolumeapplication.bean.InputFormBean;
import com.ibm.cgvolumeapplication.util.DBConnectionUtil;


@Repository
public class CGVolumeDaoImpl extends DBConnectionUtil implements CGVolumeDao {

	private static final Logger LOGGER = LogManager.getLogger(CGVolumeDaoImpl.class);
	
	@Override
	public List<Map<String, Object>> selectData(InputFormBean formBean) throws SQLException {

		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		ResultSetMetaData metaData = null;
		Map<String, Object> row = null;
		List<Map<String, Object>> resultList = null;
		StringBuilder builder = null;
		String columnName;
		Object columnValue;
		int columnCount = 0;
		String dates = null;
		String summHours = null;
		String venderName = null;
		String cricles = null;
		String hourpart = null;
		String brand = null;
		String hourParts = "'1','2','3','4'";
	
		    dates= formBean.getCallDateDropdownId().stream().map(item -> "'" + item.trim() + "'").collect(Collectors.joining(", "));
			summHours = formBean.getSummhourDropdownId()!=null ? formBean.getSummhourDropdownId().stream().map(item ->  "'"+item.trim()+"'" ).collect(Collectors.joining(", ")) : null;
			venderName = formBean.getVenderNameDropdownId()!=null ? formBean.getVenderNameDropdownId().stream().map(item -> "'"+item.trim()+"'" ).collect(Collectors.joining(", ")) : null;
			cricles = formBean.getCircleDropdownId().stream().map(item -> "'"+item.replace("BR", "BH").replace("KOL", "KO").replace("MUM", "MB").replace("UPE", "UE").replace("UPW", "UW").trim()+"'" ).collect(Collectors.joining(", "));			
			hourpart = formBean.getHourpartDropdownId()!=null ? formBean.getHourpartDropdownId().stream().map(item -> "'"+item.trim()+"'" ).collect(Collectors.joining(", ")) : hourParts;
			brand = formBean.getBrandDropdownId().stream().map(item -> "'"+item.trim()+"'" ).collect(Collectors.joining(", "));
			
			
			builder = new StringBuilder();
			builder.append(" SELECT  ");
			builder.append(" TO_CHAR(startdatetime,'DD-Mon-YYYY')  AS RESERVE3, ");  
			builder.append(" SUMMHOUR, HOURPART, ");
			builder.append(" COUNT(1) AS CGOFFERED, ");
			builder.append(" SUM(CASE WHEN CALL_STATUS='SUCCESS' THEN 1 ELSE 0 END) AS CGSUCCESS, ");
			builder.append(" SUM(CASE WHEN CALL_STATUS<>'SUCCESS' THEN 1 ELSE 0 END) AS CGFAIL, ");
			builder.append(" ROUND((NULLIF(SUM(CASE WHEN CATCODE IN ('CAT021','CAT051','VCAT021','VCAT051') AND CALL_STATUS = 'SUCCESS' THEN 1 ELSE 0 END),0) ");
			builder.append(" / SUM(CASE WHEN CATCODE IN ('CAT021','CAT051','VCAT021','VCAT051') THEN 1 ELSE 0 END)) * 100, 2) CGSU_PER, ");
			builder.append(" ROUND((NULLIF(SUM(CASE WHEN CATCODE IN ('CAT021','CAT051','VCAT021','VCAT051') AND CALL_STATUS='FAILURE' THEN 1 ELSE 0 END),0) ");
			builder.append(" / SUM(CASE WHEN CATCODE IN ('CAT021','CAT051', 'VCAT021','VCAT051') THEN 1 ELSE 0 END)) * 100, 2) CGFAIL_PER ");
			builder.append(" FROM cgglob.tbl_ivrcallactivity_obd ");//tbl_ivrcallactivity_obd
			//builder.append(" FROM tbl_ivrcallactivity_obd ");//tbl_ivrcallactivity_obd
			builder.append(" WHERE ");	
			builder.append(" SUMMHOUR IN (").append(summHours).append(") ");
			builder.append(" AND HOURPART IN (").append(hourpart).append(")");
			builder.append(" AND VENDOR_NAME IN (").append(venderName).append(") ");
			builder.append(" AND CIRCLEMNEMONIC IN ( ").append(cricles).append(") ");
	        builder.append(" AND (TO_CHAR(startdatetime, 'DD-Mon-YYYY') IN (").append(dates).append("))");	   
	        builder.append(" AND ((CASE WHEN CATCODE NOT LIKE '%V%' THEN 'IDEA' ELSE 'VODAFONE' END) IN (").append(brand).append("))");
	        builder.append(" GROUP BY "); 
	        builder.append(" TO_CHAR(startdatetime,'DD-Mon-YYYY'), ");
	        builder.append(" SUMMHOUR, HOURPART");
			builder.append(" ORDER BY SUMMHOUR ");

			String selectQuery = builder.toString();
			LOGGER.info("selectQuery: "+selectQuery);
			
			connection = getJDBCConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(selectQuery);
			metaData = resultSet.getMetaData();
			resultList = new ArrayList<>();
			columnCount = metaData.getColumnCount();
        
			while (resultSet.next()) {
	
				row = new LinkedHashMap<>();
				for (int i = 1; i <= columnCount; i++) {
					columnName = metaData.getColumnName(i);
					columnValue = resultSet.getObject(i);
					row.put(columnName, columnValue);
				}
				// System.out.println(row); 
				
				resultList.add(row);
			}
           
			resultSet.close();
			statement.close();
			connection.close();
	
		/* System.out.println(resultList); */
			LOGGER.info("is data fetched : "+(resultList.size()>0));
		return resultList;
	}
}
