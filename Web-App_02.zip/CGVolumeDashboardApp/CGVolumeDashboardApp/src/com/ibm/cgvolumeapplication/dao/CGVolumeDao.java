package com.ibm.cgvolumeapplication.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.ibm.cgvolumeapplication.bean.InputFormBean;

public interface CGVolumeDao {

	public List<Map<String, Object>> selectData(InputFormBean formBean) throws SQLException ;
}
