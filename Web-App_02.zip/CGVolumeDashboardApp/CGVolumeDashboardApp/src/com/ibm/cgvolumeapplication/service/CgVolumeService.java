package com.ibm.cgvolumeapplication.service;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;

import com.ibm.cgvolumeapplication.bean.InputFormBean;


public interface CgVolumeService {

	public Map<String, Object> loadDropdownData();
	
	public ModelAndView getTableRowData(ModelAndView model, InputFormBean inputFormBean, HttpSession session) throws SQLException;

	public void genarateExcel(OutputStream outputStream, String title, Map<String, Object> tableData, int excelRowSpan) throws IOException;
}
