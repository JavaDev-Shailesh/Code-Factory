package com.ibm.cgvolumeapplication.service;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.cgvolumeapplication.bean.InputFormBean;
import com.ibm.cgvolumeapplication.dao.CGVolumeDaoImpl;
import com.ibm.cgvolumeapplication.util.CommonLogic;
import com.ibm.cgvolumeapplication.util.DropdownValuesUtil;
import com.ibm.cgvolumeapplication.util.GenerateExcelUtil;

@Service
public class CgVolumeServiceImpl implements CgVolumeService {

	private static final Logger LOGGER = LogManager.getLogger(CgVolumeServiceImpl.class);
	
	@Override
	public Map<String, Object> loadDropdownData() {

		return DropdownValuesUtil.getDropdownData();
	}

	@SuppressWarnings("unchecked")
	@Override
	public ModelAndView getTableRowData(ModelAndView model, InputFormBean inputFormBean, HttpSession session) throws SQLException {
		// get sql data
		boolean isHourpartSelected = inputFormBean.getHourpartDropdownId() != null;
		session.setAttribute("isHourpartSelected", isHourpartSelected);
		session.setAttribute("noOfDates", inputFormBean.getCallDateDropdownId().size());
		Map<String, Object> formatedData = this
				.generateTableData(new CGVolumeDaoImpl().selectData(inputFormBean), inputFormBean, session);
		session.setAttribute("tableData", formatedData);
		session.setAttribute("excelRowSpan",
				inputFormBean.getHourpartDropdownId() != null ? inputFormBean.getHourpartDropdownId().size() : 0);
		int totalSummHours = 0;
		LOGGER.info("formatedData: "+formatedData);
		// set rows
		for (Map.Entry<String, List<List<Object>>> groupOfSummhourData : ((Map<String, List<List<Object>>>) formatedData
				.get("SUMMHOURS_DATA")).entrySet()) {
			model.addObject(groupOfSummhourData.getKey(), groupOfSummhourData.getValue());
			totalSummHours++;
		}
		if (isHourpartSelected) {
			// set rows calculations
			for (Map.Entry<String, List<Object>> calculationRows : ((Map<String, List<Object>>) formatedData
					.get("SUMMHOURS_CALCULATION_DATA")).entrySet()) {
				model.addObject(calculationRows.getKey(), calculationRows.getValue());
			}
		}
		// set date headers
		model.addObject("DATE_HEADER", formatedData.get("DATE_HEADER"));
		model.addObject("totalSummHours", totalSummHours);

		return model;
	}

	public Map<String, Object> generateTableData(List<Map<String, Object>> sqlData, InputFormBean inputFormBean,
			HttpSession session) {

		CommonLogic commonLogic = new CommonLogic();
		Map<String, List<Map<String, Object>>> sortedDataOnDate = commonLogic.sortDataOnDate(sqlData, "RESERVE3",
				"dd-MMM-yyyy", "SortedOnDateGrops");
		/* System.out.println("sortedDataOnDate: "+sortedDataOnDate); */
		Map<String, List<Map<String, Object>>> groupOfData = new LinkedHashMap<String, List<Map<String, Object>>>();
		Map<String, List<Map<String, Object>>> sortedDataOnSummHour = null;
		Map<String, List<Map<String, Object>>> sortedDataOnHourPartSummHour = null;
		Map<String, Map<String, List<Map<String, Object>>>> similarSumhourData = null;
		Map<String, List<List<Map<String, Object>>>> outputData = null;

		int keyCount = 0;
		for (Map.Entry<String, List<Map<String, Object>>> entry1 : sortedDataOnDate.entrySet()) {

			sortedDataOnSummHour = commonLogic.sortedDataOn(entry1.getValue(), true, "SortedOnSummhourGroup",
					"SUMMHOUR");
			/* System.out.println("sortedDataOnSummHour: "+sortedDataOnSummHour); */
			sortedDataOnHourPartSummHour = commonLogic.sortDataOnHourpart(sortedDataOnSummHour, "HOURPART",
					"SortedOnHourpartGroup");
			LOGGER.info("sortedDataOnHourPartSummHour: "+sortedDataOnHourPartSummHour);
			sortedDataOnHourPartSummHour = commonLogic.mergedSimilarHourPartData(sortedDataOnHourPartSummHour);
			LOGGER.info("mergedSimilarHourPartData: "+sortedDataOnHourPartSummHour);
			// System.out.println("sortedDataOnHourPartSummHour:
			// "+sortedDataOnHourPartSummHour);

			for (Map.Entry<String, List<Map<String, Object>>> storeDataInFinalDataMap : sortedDataOnHourPartSummHour
					.entrySet()) {
				groupOfData.put("key_" + (++keyCount), storeDataInFinalDataMap.getValue());
			}
		}
		/* System.out.println("groupOfData: "+groupOfData); */
		similarSumhourData = commonLogic.groupOfSimilarSumhourData(groupOfData, "SUMMHOUR");
		/* System.out.println("similarSumhourData: "+similarSumhourData); */
		outputData = commonLogic.mergeDataInSingleRow(similarSumhourData, inputFormBean, session);
		if (inputFormBean.getHourpartDropdownId() == null) {

			outputData = commonLogic.mergeAllHourpartsIfInputHourpartNotGiven(outputData,session);
		}
		/* System.out.println("outputData: " + outputData); */

		return commonLogic.setFinalDataForDisplay(outputData, session);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void genarateExcel(OutputStream outputStream, String title, Map<String, Object> tableData, int excelRowSpan)
			throws IOException {

		Map<String, Object> formatedData = tableData;
		List<Map<String, Object>> tableRows = new ArrayList<Map<String, Object>>();
		List<String> dates = (List<String>) formatedData.get("DATE_HEADER");
		int noOfDates = dates != null ? dates.size() : 0;

		String date1 = noOfDates > 0 ? dates.get(0).replace("'", "") : "-";
		String date2 = noOfDates > 1 ? dates.get(1).replace("'", "") : "-";
		String date3 = noOfDates > 2 ? dates.get(2).replace("'", "") : "-";

		List<String> listColNames2 = new ArrayList<String>();
		List<String> listcolAlignments2 = new ArrayList<String>();
		List<String> listColBgColors2 = new ArrayList<String>();
		List<Integer> listColColspan2 = new ArrayList<Integer>();

		List<String> listColNames3 = new ArrayList<String>();
		List<String> listcolAlignments3 = new ArrayList<String>();
		List<String> listColBgColors3 = new ArrayList<String>();
		List<Integer> listColSizes3 = new ArrayList<Integer>();

		if (noOfDates >= 1) {

			listColNames2.addAll(Collections.nCopies(2, " "));
			listColNames2.add(date1);
			listColNames2.addAll(Collections.nCopies(4, ""));
			listcolAlignments2.addAll(Collections.nCopies(7, "center"));
			listColBgColors2.addAll(Collections.nCopies(7, "LIGHT_CORNFLOWER_BLUE"));
			listColColspan2.addAll(Collections.nCopies(2, 0));
			listColColspan2.add(5);
			listColColspan2.addAll(Collections.nCopies(4, 0));

			listColNames3
					.addAll(Arrays.asList("SUMMHOUR", "HOURPART", "Offer", "CG SU", "CG FAIL", "CG SU%", "CG Fail%"));
			listcolAlignments3.addAll(Collections.nCopies(7, "center"));
			listColBgColors3.addAll(Collections.nCopies(7, "LIGHT_CORNFLOWER_BLUE"));
			listColSizes3.add(4000);

		}

		if (noOfDates >= 2) {
			listColNames2.add(date2);
			listColNames2.addAll(Collections.nCopies(4, ""));
			listcolAlignments2.addAll(Collections.nCopies(5, "center"));
			listColBgColors2.addAll(Collections.nCopies(5, "LIGHT_CORNFLOWER_BLUE"));
			listColColspan2.add(5);
			listColColspan2.addAll(Collections.nCopies(4, 0));

			listColNames3.addAll(Arrays.asList("Offer", "CG SU", "CG FAIL", "CG SU%", "CG Fail%"));
			listcolAlignments3.addAll(Collections.nCopies(5, "center"));
			listColBgColors3.addAll(Collections.nCopies(5, "LIGHT_CORNFLOWER_BLUE"));
		}

		if (noOfDates >= 3) {
			listColNames2.add(date3);
			listColNames2.addAll(Collections.nCopies(4, ""));
			listcolAlignments2.addAll(Collections.nCopies(5, "center"));
			listColBgColors2.addAll(Collections.nCopies(5, "LIGHT_CORNFLOWER_BLUE"));
			listColColspan2.add(5);
			listColColspan2.addAll(Collections.nCopies(4, 0));

			listColNames3.addAll(Arrays.asList("Offer", "CG SU", "CG FAIL", "CG SU%", "CG Fail%"));
			listcolAlignments3.addAll(Collections.nCopies(5, "center"));
			listColBgColors3.addAll(Collections.nCopies(5, "LIGHT_CORNFLOWER_BLUE"));
		}

		List<Map<String, Object>> tableHeaders = new ArrayList<Map<String, Object>>();

		String[] colNames = { title };
		String[] colAlignments = { "center" };
		String[] colBgColors = { "yellow" };
		int[] colSizes = { 4000 };
		int[] colColspan = { noOfDates == 1 ? 7 : noOfDates == 2 ? 12 : noOfDates == 3 ? 17 : 17 };

		String[] colNames2 = listColNames2.toArray(new String[0]);
		String[] colAlignments2 = listcolAlignments2.toArray(new String[0]);
		String[] colBgColors2 = listColBgColors2.toArray(new String[0]);
		int[] colColspan2 = listColColspan2.stream().mapToInt(Integer::intValue).toArray();

		String[] colNames3 = listColNames3.toArray(new String[0]);
		String[] colAlignments3 = listcolAlignments3.toArray(new String[0]);
		String[] colBgColors3 = listColBgColors3.toArray(new String[0]);
		int[] colSizes3 = listColSizes3.stream().mapToInt(Integer::intValue).toArray();

		Map<String, Object> header1 = new HashedMap<String, Object>();
		header1.put("colNames", colNames);
		header1.put("colAlignments", colAlignments);
		header1.put("colBgColors", colBgColors);
		header1.put("colSizes", colSizes);
		header1.put("colColspan", colColspan);
		tableHeaders.add(header1);

		Map<String, Object> header2 = new HashedMap<String, Object>();
		header2.put("colNames", colNames2);
		header2.put("colAlignments", colAlignments2);
		header2.put("colBgColors", colBgColors2);
		header2.put("colSizes", null);
		header2.put("colColspan", colColspan2);
		tableHeaders.add(header2);

		Map<String, Object> header3 = new HashedMap<String, Object>();
		header3.put("colNames", colNames3);
		header3.put("colAlignments", colAlignments3);
		header3.put("colBgColors", colBgColors3);
		header3.put("colSizes", colSizes3);
		header3.put("colColspan", null);
		tableHeaders.add(header3);

		Map<String, Object> row = null;
		int count;

		int noOfGroups = 0;
		for (Map.Entry<String, List<List<Object>>> groupOfSummhourData : ((Map<String, List<List<Object>>>) formatedData
				.get("SUMMHOURS_DATA")).entrySet()) {

			noOfGroups++;
			for (List<Object> innerList : groupOfSummhourData.getValue()) {
				row = new LinkedHashMap<String, Object>();
				count = 0;
				for (Object item : innerList) {
					item = item.toString().replace("'", "");
					row.put("key" + count, item);
					count++;
				}
				tableRows.add(row);
			}
			if (formatedData.containsKey("SUMMHOURS_CALCULATION_DATA")) {
				int noOfCalcRows = 0;
				for (Map.Entry<String, List<Object>> calculationRows : ((Map<String, List<Object>>) formatedData
						.get("SUMMHOURS_CALCULATION_DATA")).entrySet()) {
					noOfCalcRows++;
					if (noOfCalcRows == noOfGroups) {
						row = new LinkedHashMap<String, Object>();
						count = 0;
						for (Object item : calculationRows.getValue()) {
							item = item.toString().replace("'", "");
							row.put("key" + count, item);
							if (count == 0) {
								row.put("key", "");
							}
							count++;
						}
						tableRows.add(row);
					}

				}
			}
		}

		new GenerateExcelUtil().generateExcel(outputStream, tableHeaders, tableRows, excelRowSpan);

	}
}
