package com.ibm.cgvolumeapplication.controller;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.cgvolumeapplication.bean.InputFormBean;
import com.ibm.cgvolumeapplication.service.CgVolumeService;
import com.ibm.cgvolumeapplication.service.CgVolumeServiceImpl;
import com.ibm.cgvolumeapplication.util.PropertiesUtil;

//http://localhost:8082/CGVolumeDashboardApp/
@Controller
public class CgVolumeController {

	private static final Logger LOGGER = LogManager.getLogger(CgVolumeController.class);
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView loadCgVolumeService() {
		
		ModelAndView modelAndView = null;
		CgVolumeService service = null;
		Map<String, Object> dropdaownData = null;
		
		try {
			modelAndView = new ModelAndView();
			service = new CgVolumeServiceImpl();
			dropdaownData = service.loadDropdownData();
			
			modelAndView.addObject("displyReport", false);
			modelAndView.addObject("summhours", dropdaownData.get("summhours"));
			modelAndView.addObject("hourparts", dropdaownData.get("hourparts"));
			modelAndView.addObject("venderNames", dropdaownData.get("venderNames"));
			modelAndView.addObject("brands", dropdaownData.get("brands"));
			modelAndView.addObject("circles", dropdaownData.get("circles"));

		} catch (Exception e) {
			LOGGER.error("Exception Occoured In CgVolumeController > loadCgVolumeService : ", e);
		}
		modelAndView.setViewName("cgvolume");

		return modelAndView;
	}
	
	@RequestMapping(value = "/loadReport", method = RequestMethod.POST)
	public ModelAndView loadReport(@ModelAttribute InputFormBean inputFormBean, HttpSession session) {
		ModelAndView modelAndView = null;
		CgVolumeService service = null;
		Map<String, Object> dropdaownData = null;
		//System.out.println("inputFormBean: "+inputFormBean);
		LOGGER.info("inputFormBean",inputFormBean);
		try {
			modelAndView = new ModelAndView();
			service = new CgVolumeServiceImpl();
			dropdaownData = service.loadDropdownData();
			
			modelAndView.addObject("summhours", dropdaownData.get("summhours"));
			modelAndView.addObject("hourparts", dropdaownData.get("hourparts"));
			modelAndView.addObject("venderNames", dropdaownData.get("venderNames"));
			modelAndView.addObject("brands", dropdaownData.get("brands"));
			modelAndView.addObject("circles", dropdaownData.get("circles"));
			
			modelAndView.addObject("displyReport", true);
			modelAndView.addObject("selectedSummhour", inputFormBean.getSummhourDropdownId());
			modelAndView.addObject("selectedHourparts", inputFormBean.getHourpartDropdownId());
			modelAndView.addObject("selectedVenderNames", inputFormBean.getVenderNameDropdownId());
			modelAndView.addObject("selectedBrands", inputFormBean.getBrandDropdownId());
			modelAndView.addObject("selectedCircles", inputFormBean.getCircleDropdownId());
		
			modelAndView = service.getTableRowData(modelAndView, inputFormBean, session);
		} catch (Exception e) {
			modelAndView.addObject("error","Internal Server Error..!");
			LOGGER.error("Exception Occoured In CgVolumeController > loadReport : ", e);
		}
		modelAndView.setViewName("cgvolume");
		
		return modelAndView;
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/genarateExcel", method = RequestMethod.GET)
	public ResponseEntity<byte[]> genarateExcel(HttpServletRequest httpServletRequest,HttpSession session) {

		CgVolumeService service = null;
		ByteArrayOutputStream outputStream = null;
		HttpHeaders headers = null;
		Map<String, Object> tableData = null;
		byte[] excelBytes = null;
		int excelRowSpan = 0;
		try {
			tableData =  (Map<String, Object>) session.getAttribute("tableData");
			excelRowSpan = (int) session.getAttribute("excelRowSpan");
			service = new CgVolumeServiceImpl();
			outputStream = new ByteArrayOutputStream();
			service.genarateExcel(outputStream,httpServletRequest.getParameter("reportTitle"), tableData, excelRowSpan);

			headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH_mm_ss");
			
			String timestamp = dateFormat.format(new Date());
			String fileName = "CGVolume_" + timestamp + ".xlsx";
       
			headers.setContentDispositionFormData("attachment", fileName);
			excelBytes = outputStream.toByteArray();
						
			return ResponseEntity.ok().headers(headers).body(excelBytes);
		} catch (Exception e) {

			LOGGER.error("Exception Occoured In CgVolumeController > genarateExcel : ", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new byte[0]);
		}
	}
}
