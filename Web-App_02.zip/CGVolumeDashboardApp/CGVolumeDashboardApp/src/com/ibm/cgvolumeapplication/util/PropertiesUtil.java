package com.ibm.cgvolumeapplication.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PropertiesUtil {

	public static Properties GLOBALPROPERTIES = new Properties();
	private static final Logger LOGGER = LogManager.getLogger(PropertiesUtil.class);

	static {
		InputStream inputStream = null;
		try {
			// Use FileInputStream for an absolute file path
			inputStream = new FileInputStream("C:/CGVolumeDashboardProps/global.properties");
			GLOBALPROPERTIES.load(inputStream);
		} catch (IOException e) {
			LOGGER.error("Exception Occurred in PropertiesUtil > static block: ", e);
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					LOGGER.error("Error closing input stream: ", e);
				}
			}
		}
	}

	public static Map<String, String> getUrl() {
		String url = GLOBALPROPERTIES.getProperty("URL");
		String password = GLOBALPROPERTIES.getProperty("PASS");
		String schema = GLOBALPROPERTIES.getProperty("SCHEMA");

		Map<String, String> connectionDetails = new LinkedHashMap<>();
		connectionDetails.put("URL", url);
		connectionDetails.put("PASSWORD", password);
		connectionDetails.put("SCHEMA", schema);

		LOGGER.info(" connectionDetails : " + connectionDetails);
		//System.out.println(connectionDetails);

		return connectionDetails;
	}
}
