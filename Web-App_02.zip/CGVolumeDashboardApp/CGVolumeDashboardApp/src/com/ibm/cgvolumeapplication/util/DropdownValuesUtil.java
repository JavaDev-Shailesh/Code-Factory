package com.ibm.cgvolumeapplication.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ibm.cgvolumeapplication.dao.CGVolumeDaoImpl;

public class DropdownValuesUtil {

	private static final Logger LOGGER = LogManager.getLogger(DropdownValuesUtil.class);
	private static List<String> venderName = null;
	private static final List<String> BRAND = Arrays.asList("IDEA", "VODAFONE");
	private static final List<String> HOURPART = Arrays.asList("1", "2", "3", "4");
	private static final List<String> SUMMHOUR = Arrays.asList("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10","11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23");
	private static final List<String> CIRCLE = Arrays.asList("AP", "ASM", "BR", "CHN", "DL", "GJ", "HP", "HR", "JK","KN", "KOL", "KR", "MH", "MP", "MUM", "NESA", "OR", "PB", "RJ", "TN", "UPE", "UPW", "WB");

	private static final Map<String, Object> getDropdownData = new HashedMap<String, Object>();

	static {
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			connection = DBConnectionUtil.getJDBCConnection();
			LOGGER.info("is connection done : "+(connection!=null));
			statement = connection.createStatement();
			resultSet = statement.executeQuery("SELECT vendor_name FROM cgglob.tbl_ivrcallactivity_obd WHERE startdatetime >= TRUNC(SYSDATE - 10) GROUP BY vendor_name");
			//resultSet = statement.executeQuery("SELECT vendor_name FROM tbl_ivrcallactivity_obd WHERE startdatetime >= TRUNC(SYSDATE - 10) GROUP BY vendor_name");
			venderName = new ArrayList<>();
			while (resultSet.next()) {
				String vendorName = resultSet.getString("vendor_name");
				venderName.add(vendorName);
			}
			LOGGER.info("venderName: "+venderName);
		} catch (Exception e) {
			LOGGER.error("DropdownValuesUtil > static block : ",e);
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				LOGGER.error("DropdownValuesUtil > static block > while close connection: ",e);
			}
		}
	}

	public static Map<String, Object> getDropdownData() {
		getDropdownData.put("summhours", SUMMHOUR);
		getDropdownData.put("hourparts", HOURPART);
		getDropdownData.put("venderNames", venderName);
		getDropdownData.put("brands", BRAND);
		getDropdownData.put("circles", CIRCLE);

		return getDropdownData;
	}
}
