package com.ibm.cgvolumeapplication.bean;

import java.util.List;

public class InputFormBean {

	private List<String> callDateDropdownId;
	private List<String> summhourDropdownId;
	private List<String> venderNameDropdownId;
	private List<String> cricleDropdownId;
	private List<String> hourpartDropdownId;
	private List<String> brandDropdownId;
	
	public List<String> getCallDateDropdownId() {
		return callDateDropdownId;
	}
	public void setCallDateDropdownId(List<String> callDateDropdownId) {
		this.callDateDropdownId = callDateDropdownId;
	}
	public List<String> getSummhourDropdownId() {
		return summhourDropdownId;
	}
	public void setSummhourDropdownId(List<String> summhourDropdownId) {
		this.summhourDropdownId = summhourDropdownId;
	}
	public List<String> getVenderNameDropdownId() {
		return venderNameDropdownId;
	}
	public void setVenderNameDropdownId(List<String> venderNameDropdownId) {
		this.venderNameDropdownId = venderNameDropdownId;
	}
	public List<String> getCircleDropdownId() {
		return cricleDropdownId;
	}
	public void setCricleDropdownId(List<String> cricleDropdownId) {
		this.cricleDropdownId = cricleDropdownId;
	}
	public List<String> getHourpartDropdownId() {
		return hourpartDropdownId;
	}
	public void setHourpartDropdownId(List<String> hourpartDropdownId) {
		this.hourpartDropdownId = hourpartDropdownId;
	}
	public List<String> getBrandDropdownId() {
		return brandDropdownId;
	}
	public void setBrandDropdownId(List<String> brandDropdownId) {
		this.brandDropdownId = brandDropdownId;
	}
	
	@Override
	public String toString() {
		return "InputFormBean [callDateDropdownId=" + callDateDropdownId + ", summhourDropdownId=" + summhourDropdownId
				+ ", venderNameDropdownId=" + venderNameDropdownId + ", circleDropdownId=" + cricleDropdownId
				+ ", hourpartDropdownId=" + hourpartDropdownId + ", brandDropdownId=" + brandDropdownId + "]";
	}
	
}
