package com.te.UtilizationLayer;

import java.util.Scanner;

import com.te.FactoryLayer.SwitchFactory;
import com.te.InterfaceLayer.Switch;

public class MainClass {
	public static void main(String[] args) {
		SwitchFactory factory = new SwitchFactory();
		Scanner scanner = new Scanner(System.in);

		System.out.println("select option: ");
		System.out.println("1)LED\n2)Tube\n3)Bulb");
		int value = scanner.nextInt();

		Switch switch1 = factory.getInstance(value);

		System.out.println("1)ON\n2)OFF");
        int i=scanner.nextInt();
        if(i==1)
        	switch1.on();
        else if(i==2)
        	switch1.off();
        else 
			System.out.println("enter correct opption..");
		
	}
}
