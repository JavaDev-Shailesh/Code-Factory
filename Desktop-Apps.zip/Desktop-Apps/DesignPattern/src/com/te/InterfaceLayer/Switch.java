package com.te.InterfaceLayer;

public interface Switch {

	
	void on();
	void off();
	
}
