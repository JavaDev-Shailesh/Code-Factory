package com.te.ImplementsLayer;

import com.te.InterfaceLayer.Switch;

public class Bulb implements Switch{

	@Override
	public void on() {
		System.out.println("Bulb..ON");
	}

	@Override
	public void off() {
		System.out.println("Bulb..OFF");
	}

}
