package com.te.ImplementsLayer;

import com.te.InterfaceLayer.Switch;

public class LED  implements Switch{

	@Override
	public void on() {
		System.out.println("LED..ON");	
	}

	@Override
	public void off() {
		System.out.println("LED..OFF");	
	}

}
