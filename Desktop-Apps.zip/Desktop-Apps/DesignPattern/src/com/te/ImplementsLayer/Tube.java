package com.te.ImplementsLayer;

import com.te.InterfaceLayer.Switch;

public class Tube  implements Switch {

	@Override
	public void on() {
		System.out.println("Tube..ON");
	}

	@Override
	public void off() {
		System.out.println("Tube..OFF");
	}

}
