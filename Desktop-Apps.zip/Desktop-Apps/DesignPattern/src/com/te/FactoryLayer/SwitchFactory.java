package com.te.FactoryLayer;

import com.te.ImplementsLayer.Bulb;
import com.te.ImplementsLayer.LED;
import com.te.ImplementsLayer.Tube;
import com.te.InterfaceLayer.Switch;

public class SwitchFactory {

	public Switch getInstance(int value) {
	Switch switch1=null;
	if(value==1) 
		switch1=new Tube();
	else if(value==1) 
		switch1=new Bulb();
	else
		switch1=new LED();
	
	return switch1;
	
	
	}	
}
