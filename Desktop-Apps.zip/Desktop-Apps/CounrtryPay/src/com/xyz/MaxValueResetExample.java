package com.xyz;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class MaxValueResetExample {
   
    
    public static void main(String[] args) {
        Map<String, Integer> map = new HashMap<>();
        map.put("A", 10);
        map.put("B", 20);
        map.put("C", 0);
        map.put("D", 15);

        // Find the minimum value and its key using Java streams
        Entry<String, Integer> minEntry = Collections.min(map.entrySet(), Map.Entry.comparingByValue());

        String minKey = minEntry.getKey();
        int minValue = minEntry.getValue();

        // Reset the value of the key with the minimum value
        int newValue = 0; // Set the new value as needed
        map.put(minKey, newValue);

        System.out.println("Minimum Value Key: " + minKey);
        System.out.println("Minimum Value: " + minValue);

        // Print the updated map
        System.out.println("Updated Map: " + map);
    }
}
