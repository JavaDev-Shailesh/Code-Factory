package com.xyz;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class TripExpensesCalculator {

	public static void main(String[] args) {
		Map<String, Double> expenses = new LinkedHashMap<>();
		
		expenses.put("Kumar", 0.00);
		expenses.put("Dhiraj", 180.00);
		expenses.put("Abhishek", 280.00);
		expenses.put("Deepankar", 480.00);
		expenses.put("omkar", 0.00);
		expenses.put("Shudhanshu", 70.0);


		double totalExpenses = expenses.values().stream().mapToDouble(Double::doubleValue).sum();
		System.out.println("Total Expences: " + totalExpenses);
		double averageExpense = totalExpenses / expenses.size();
		System.out.println("Per Head Expences: " + onlyTwoDecimalVal(averageExpense));

		// Create a map to store how much each person should pay or receive
		Map<String, Double> settlement = new HashMap<>();
		Map<String, Double> finalSettlement = new LinkedHashMap<>();
		Map<String, Double> whoPaid = new HashMap<>();
		Map<String, Double> whomRecived = new HashMap<>();

		// Calculate how much each person should pay or receive
		for (Map.Entry<String, Double> entry : expenses.entrySet()) {
			String person = entry.getKey();
			double amountPaid = entry.getValue();
			double amountToPayOrReceive = amountPaid - averageExpense;

			if (amountToPayOrReceive > 0) {
				whomRecived.put(person, Math.abs(amountToPayOrReceive));
			} else {
				whoPaid.put(person, Math.abs(amountToPayOrReceive));
			}
			settlement.put(person, amountToPayOrReceive);
		}
		List<Object> resetWhoPaid = getMaxValue(whoPaid);
		double maxWhoPaidVal = (Double) resetWhoPaid.get(1);
		String maxWhoPaidKey = (String) resetWhoPaid.get(0);

		while (maxWhoPaidVal != 0.0) {
			
			double tempMaxWhoPaidVal = maxWhoPaidVal;
            
			while (tempMaxWhoPaidVal != 0.0) {
				Iterator<Map.Entry<String, Double>> iterator = whomRecived.entrySet().iterator();
				
				while (iterator.hasNext()) {
					Map.Entry<String, Double> entry = iterator.next();
					String key = entry.getKey();
					double value = entry.getValue();
                  
					double remainingVal = 0.0;
					if (value == 0.0) {
						continue;
					}

					if (tempMaxWhoPaidVal <= value) {
						remainingVal = onlyTwoDecimalVal(value) - onlyTwoDecimalVal(tempMaxWhoPaidVal);
						whomRecived.put(key, remainingVal);
						finalSettlement.put(maxWhoPaidKey + "_paidTo_" + key, tempMaxWhoPaidVal);
						tempMaxWhoPaidVal = 0.0;
						break;
					} else {
						remainingVal = onlyTwoDecimalVal(tempMaxWhoPaidVal) - onlyTwoDecimalVal(value);
						whomRecived.put(key, 0.0);
						finalSettlement.put(maxWhoPaidKey + "_paidTo_" + key, value);
						tempMaxWhoPaidVal = remainingVal;
						
					}
                   
				}
			}
			
			whoPaid.put(maxWhoPaidKey, 0.0);
			resetWhoPaid = getMaxValue(whoPaid);
			maxWhoPaidVal = (Double) resetWhoPaid.get(1);
			maxWhoPaidKey = (String) resetWhoPaid.get(0);

		}

		System.out.println();
		for (Map.Entry<String, Double> entry : finalSettlement.entrySet()) {
			String person = entry.getKey();
			double amount = entry.getValue();
			System.out.println(person + " should " + onlyTwoDecimalVal(Math.abs(amount)) + " rupees.");
		}
		System.out.println();
		for (Map.Entry<String, Double> entry : settlement.entrySet()) {
			String person = entry.getKey();
			double amount = entry.getValue();
			System.out.println(person+" contribute amount is : "+expenses.get(person)+" Rupees, you have to "
					+ (amount > 0 ? "'receive' " : "'pay' ") + onlyTwoDecimalVal(Math.abs(amount)) + " rupees ");
		
		}
		System.out.println();
	}

	public static List<Object> getMaxValue(Map<String, Double> map) {

		List<Object> list = new ArrayList<>();
		Entry<String, Double> maxEntry = Collections.max(map.entrySet(), Map.Entry.comparingByValue());

		String maxKey = maxEntry.getKey();
		Double maxValue = maxEntry.getValue();

		list.add(maxKey);
		list.add(maxValue);

		return list;
	}
	
	public static Double onlyTwoDecimalVal(Double val) {
		
		return Double.parseDouble( new DecimalFormat("#.##").format(val));
	}
}
