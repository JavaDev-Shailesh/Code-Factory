package te.com.car.basepkg.service;

import java.util.List;

import te.com.car.basepkg.dto.Car;

public interface CarService {
	boolean addCar(Car car);
	Car modify(int id);
	boolean replace(int id, int option, String data);
	boolean delete(int carID);
	Car searCar(int carID);
	List<Car> searCar(String name);
	List<Car> searchByCompanyName(String name);
	
	
}
