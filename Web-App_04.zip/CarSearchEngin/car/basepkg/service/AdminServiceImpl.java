package te.com.car.basepkg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import te.com.car.basepkg.dao.AdminDaoImpl;
import te.com.car.basepkg.dto.Admin;

@Service
public class AdminServiceImpl implements AdminSer{
	@Autowired
	private AdminDaoImpl adminImpl;
	
	@Override
	public Admin validate(int userID, String password) {
		if(userID<0) {
			return null;
		}else {
			return adminImpl.validate(userID, password);
		}		
	}

	@Override
	public boolean createAccount(int userID, String password) {
		boolean flag= false;
		if(userID<0) {
			flag = false;
		}else {
				flag =  adminImpl.createAccount(userID, password);
		}
		return flag;
	}
	
}
