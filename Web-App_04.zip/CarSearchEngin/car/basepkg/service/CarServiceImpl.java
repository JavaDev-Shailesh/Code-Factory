package te.com.car.basepkg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import te.com.car.basepkg.dao.CarDaoImpl;
import te.com.car.basepkg.dto.Car;
@Service
public class CarServiceImpl implements CarService {
	@Autowired
	private CarDaoImpl daoImpl;
	
	@Override
	public boolean addCar(Car car) {
		if(car.getId()<0) {
			return false;
		}else {
			return daoImpl.addCar(car);
		}
		
	}

	@Override
	public Car modify(int id) {
		if(id<0) {
			return null;
		}else {
			return daoImpl.modify(id);
		}
	}

	@Override
	public boolean replace(int id, int option, String data) {
		System.out.println("bhava service madhe pohochlo aahe aata");
		boolean flag = false;
		if(option<0 && option>13) {
			flag=false;
		}else {
			flag = daoImpl.replace(id, option, data);
			}
		return flag;
	}

	@Override
	public boolean delete(int carID) {
		System.out.println("bhava service madhe pohochlo aahe aata");
		boolean flag = false;
		if(carID<0) {
			flag=false;
		}else {
			flag = daoImpl.delete(carID);
			}
		return flag;
	}

	@Override
	public Car searCar(int carID) {
		if(carID<0) {
			return null;
		}else {
			return daoImpl.searCar(carID);
		}
	}

	@Override
	public List<Car> searCar(String name) {
		return daoImpl.searCar(name);
	}

	@Override
	public List<Car> searchByCompanyName(String name) {
		
		return daoImpl.searchByCompanyName(name);
	}

}
