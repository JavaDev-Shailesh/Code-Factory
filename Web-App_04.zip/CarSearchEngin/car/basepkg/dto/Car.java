package te.com.car.basepkg.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "car")
public class Car {
	@Id
	private int id;
	private String name;
	private String company;
	private String fueltype;
	private String power_steering;
	private String break_system;
	private double showRoom_price;
	private double onroad_price;
	private String image_url;
	private double mileage;
	private int seating_cap;
	private int engine_cap;
	private String gear_type;
	
}
