package te.com.car.basepkg.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import te.com.car.basepkg.dto.Admin;
import te.com.car.basepkg.dto.Car;
import te.com.car.basepkg.service.AdminServiceImpl;
import te.com.car.basepkg.service.CarServiceImpl;

@Controller
public class ControllerCar {

	@Autowired
	private AdminServiceImpl adservice;
	@Autowired
	private CarServiceImpl carservice;

	@GetMapping("homepage")
	public String carhome() {
		return "HomeCarSearchEngine";
	}

	@GetMapping("/login")
	public String getLoginPage() {
		return "login";
	}

	@PostMapping("/insertcardetails")
	public String getLogin(ModelMap map, String userID, String password) {
		int user = Integer.parseInt(userID);
		Admin admin = adservice.validate(user, password);
		if (admin != null) {
			map.addAttribute("msg", "Loggin in successfully");
			return "insertcardetails";
		} else {
			map.addAttribute("errmsg", "Incorrect Credentials");
			return "login";
		}
	}

	@GetMapping("/signup")
	public String getSignup() {
		return "signup";
	}

	@PostMapping("/createAccount")
	public String createAccount(ModelMap map, String userID, String password) {
		int user = Integer.parseInt(userID);
		boolean flag = adservice.createAccount(user, password);
		System.out.println(flag);
		if (flag)

		{
			System.out.println("Calling service method");
			map.addAttribute("msg", "Account created Successfully");

		} else {
			map.addAttribute("errmsg", "Account is already Exist, Please Login !!");
		}
		return "login";

	}

	@GetMapping("/insertCarInfo")
	public String getaddData() {
		return "addcardetails";
	}

	@PostMapping("/addcardetails")
	public String addCar(ModelMap map, int id, String name, String company, String fueltype, String power_steering,
			String break_system, double showRoom_price, String image_url, double mileage,
			int seating_cap, int engine_cap, String gear_type) {
		Car car = new Car();
		car.setId(id);
		car.setName(name.toLowerCase());
		car.setCompany(company.toLowerCase());
		car.setFueltype(fueltype.toLowerCase());
		car.setPower_steering(power_steering.toLowerCase());
		car.setBreak_system(break_system);
		car.setEngine_cap(engine_cap);
		car.setGear_type(gear_type);
		car.setMileage(mileage);
		car.setSeating_cap(seating_cap);
		car.setShowRoom_price(showRoom_price);
		if(showRoom_price<500000) {
			car.setOnroad_price((showRoom_price*0.13)+showRoom_price);
		}else if(showRoom_price>=500000 &&showRoom_price<1000000) {
			car.setOnroad_price((showRoom_price*0.14)+showRoom_price);
		}else if(showRoom_price>=1000000 && showRoom_price<2000000) {
			car.setOnroad_price((showRoom_price*0.17)+showRoom_price);
		}else if (showRoom_price>2000000){
			car.setOnroad_price((showRoom_price*0.18)+showRoom_price);
		}else if(fueltype.equalsIgnoreCase("electric")) {
			car.setOnroad_price((showRoom_price*0.04)+showRoom_price);
		}
		car.setImage_url(image_url);
		if(carservice.addCar(car)) {
			map.addAttribute("msg", "Car has been added successfully");
		}else {
			map.addAttribute("msg", "Car already exist in the system");
		}
		return "addcardetails";
	}
	@GetMapping("/modifyCarInfo")
	public String carModify(ModelMap map) {
		return "modify";
	}
	
	@GetMapping("/datamodify")
	public String name(ModelMap map, String id) {
		int carId = Integer.parseInt(id);
		Car car = carservice.modify(carId);
		if (car!=null) {
			map.addAttribute("car", car);
			map.addAttribute("msg", "Car found !!");
			return "ModifyBy";
		}else {
			map.addAttribute("msg", "No car found to update");
			return "modify";
		}	
	}
	@GetMapping("/replaceBy")
	public String replaceBy(ModelMap map,String option1, String replace, String id) {
		int carID = Integer.parseInt(id);
		int opt=Integer.parseInt(option1);
		if(carservice.replace(carID, opt, replace)){
			
			System.out.println("controller: "+carID);
			System.out.println("controller: "+opt);
			System.out.println("controller: "+replace);
			map.addAttribute("msg", "Data has been replaced successfully");
			return "modify";
		}else {
			map.addAttribute("msg", "Something went wrong");
			return "modify";
		}	
	}
	@GetMapping("/deleteCarInfo")
	public String deleteCar() {
		return "delete";
	}
	
	@PostMapping("/deleteCarInfo")
	public String carDelete(ModelMap map, String id) {
		int carID = Integer.parseInt(id);
		if(carservice.delete(carID))
		{
			map.addAttribute("msg", "Car has been deleted successfully");
		}else {
			map.addAttribute("msg", "No car found!! Please  check carID again");
		}
		return "delete";
	}
	@GetMapping("/searchCarInfo")
	public String searchCar() {
		return "searchAdminCar";
	}
	
	@PostMapping("/searchCarInfo")
	
	public String searchCarData(ModelMap map, String id) {
		int carID = Integer.parseInt(id);
		Car car = carservice.searCar(carID);
		if(car!=null) {
			map.addAttribute("car", car);
		}
		else {
			map.addAttribute("msg","car not found!!");
		}
		return "searchAdminCar";
	}
	@GetMapping("/searchcar")
	public String searchCarUser() {
		return "SearchBytype";
	}
	
	@GetMapping("/searchById")
	public String searchbyIDd() {
		return "SearchByID";
	}
	
	@PostMapping("/searchById")
	public String searchByID(ModelMap map, int carID) {
		Car car = carservice.searCar(carID);
		if (car!=null) {
			map.addAttribute("car", car);
			
		}else {
			map.addAttribute("msg", "Car not found");
		}
		return "SearchByID";
	}
	@GetMapping("/searchByName")
	public String sbyName() {
		return "searchByName";
	}
	@PostMapping("/searchByName")
	public String searchByName(ModelMap map, String name) {
		List<Car> car = carservice.searCar(name);
		if(car!=null) {
			map.addAttribute("car", car);
		}else {
			map.addAttribute("msg", "hehe Car not found!! ");
		}
		return "searchByName";
	}
	
	@GetMapping("/searchByCompany")
	public String searchByCom() {
		return "searchByCompany";
	}
	@PostMapping("/searchByCompany")
	public String searchByCompany(ModelMap map, String name) {
		List<Car> car = carservice.searchByCompanyName(name);
		if(car!=null) {
			System.out.println(car);
			map.addAttribute("car1", car);
		}else {
			map.addAttribute("msg", "hehe Car not found!! ");
		}
		return "searchByCompany";
	}
	
}
