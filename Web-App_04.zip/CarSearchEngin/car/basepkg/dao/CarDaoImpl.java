package te.com.car.basepkg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.hibernate.service.spi.Manageable;
import org.springframework.stereotype.Repository;

import te.com.car.basepkg.dto.Car;
@Repository
public class CarDaoImpl implements CarDao {
	boolean flag = false;
	@Override
	public boolean addCar(Car car) {
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;
		
		try {
			factory= Persistence.createEntityManagerFactory("admin");
			manager =factory.createEntityManager();
			transaction = manager.getTransaction();
			Car cardata= manager.find(Car.class, car.getId());
			if(cardata==null) {
				transaction.begin();
					manager.persist(car);
				transaction.commit();
				flag  = true;
			}
		return flag;
		} catch (Exception e) {
			if(transaction!=null) {
				transaction.rollback();
			}
		}
		return flag;		
	}
	
	@Override
	public Car modify(int id) {
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;
		Car cardata=null;
		try {
			factory= Persistence.createEntityManagerFactory("admin");
			manager =factory.createEntityManager();
			transaction = manager.getTransaction();
			cardata= manager.find(Car.class, id);
		}catch(Exception e) {
			if(transaction!=null) {
				transaction.rollback();
			}
		}
		return cardata;
	}
	@Override
	public boolean replace(int id, int option, String data) {
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;
		Car cardata=null;
		try {
			factory= Persistence.createEntityManagerFactory("admin");
			manager =factory.createEntityManager();
			transaction = manager.getTransaction();
			
			cardata= manager.find(Car.class, id);
			if(cardata!=null) {
				if(option==1) {
                     cardata.setName(data);
				}else if(option==2) {
					cardata.setCompany(data);
				}else if(option==3) {
					cardata.setFueltype(data);
				}else if(option==4) {
					cardata.setPower_steering(data);
				}else if(option==5) {
					cardata.setBreak_system(data);	
				}else if(option==6) {
					double showRoom_price = Double.parseDouble(data);
					cardata.setShowRoom_price(showRoom_price);
					if(showRoom_price<500000) {
						cardata.setOnroad_price((showRoom_price*0.13)+showRoom_price);
					}else if(showRoom_price>=500000 &&showRoom_price<1000000) {
						cardata.setOnroad_price((showRoom_price*0.14)+showRoom_price);
					}else if(showRoom_price>=1000000 && showRoom_price<2000000) {
						cardata.setOnroad_price((showRoom_price*0.17)+showRoom_price);
					}else if (showRoom_price>2000000){
						cardata.setOnroad_price((showRoom_price*0.18)+showRoom_price);
					}else if(cardata.getFueltype().equalsIgnoreCase("electric")) {
						cardata.setOnroad_price((showRoom_price*0.04)+showRoom_price);
					}
				}else if(option==7) {
					cardata.setImage_url(data);
				}else if(option==8) {
					System.out.println("bhau query shodhat aahe");
					double mileage = Double.parseDouble(data);
					cardata.setMileage(mileage);
				}else if(option==9) {
					int seating_Cap=Integer.parseInt(data);
					cardata.setSeating_cap(seating_Cap);
				}else if(option==10) {
					int engin_Cap=Integer.parseInt(data);
					cardata.setEngine_cap(engin_Cap);
				}else if(option==11) {
					cardata.setGear_type(data);
				}
				
				transaction.begin();
				System.out.println("begin");
						manager.persist(cardata);
						System.out.println("update");
				transaction.commit();
				flag = true;
			}
		
	
		}catch(Exception e) {
			if(transaction!=null) {
				transaction.rollback();
			}
		}
		return flag;
	}

	@Override
	public boolean delete(int carID) {
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;
		Car cardata=null;
		try {
			factory= Persistence.createEntityManagerFactory("admin");
			manager =factory.createEntityManager();
			transaction = manager.getTransaction();
			
			cardata= manager.find(Car.class, carID);
			if(cardata!=null) {
				transaction.begin();
			manager.remove(cardata);
				transaction.commit();
				flag = true;
			}
		}catch(Exception e) {
			if(transaction!=null) {
				transaction.rollback();
			}
		}
		return flag;
	}

	@Override
	public Car searCar(int carID) {
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		Car car = null;
		try {
			factory= Persistence.createEntityManagerFactory("admin");
			manager =factory.createEntityManager();
			
			car= manager.find(Car.class, carID);
		}catch(Exception e) {
			
		}
		return car;
		
	}

	@Override
	public List<Car> searCar(String name) {
		
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		String query = "from Car where name like '%"+name.toLowerCase()+"%'";
		System.out.println(query);
		List<Car> car = null;
		try {
			factory= Persistence.createEntityManagerFactory("admin");
			manager =factory.createEntityManager();
			Query data = manager.createQuery(query);
			car=data.getResultList();
			
		}catch(Exception e) {
			
		}
		return car;
	}

	@Override
	public List<Car> searchByCompanyName(String name) {

		EntityManagerFactory factory = null;
		EntityManager manager = null;
		String query = "from Car where company like '%"+name.toLowerCase()+"%'";
		System.out.println(query);
		List<Car> car = null;
		try {
			factory= Persistence.createEntityManagerFactory("admin");
			manager =factory.createEntityManager();
			Query data = manager.createQuery(query);
			car=data.getResultList();
			
		}catch(Exception e) {
			
		}
		return car;
	}
}
/*
	
	*/