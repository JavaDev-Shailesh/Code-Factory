package te.com.car.basepkg.dao;

import te.com.car.basepkg.dto.Admin;

public interface AdminDao {
	Admin validate(int userID, String password);
	boolean createAccount(int userID, String password);
}
