package te.com.car.basepkg.dao;

import java.util.List;

import te.com.car.basepkg.dto.Car;

public interface CarDao {
	boolean addCar(Car car);
	Car modify(int id);
	boolean replace(int id, int option, String data);
	boolean delete(int carID);
	Car searCar(int carID);
	List<Car> searCar(String name);
	List<Car> searchByCompanyName(String name);
	
}
