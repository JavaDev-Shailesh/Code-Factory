package te.com.car.basepkg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.stereotype.Repository;

import te.com.car.basepkg.dto.Admin;
@Repository
public class AdminDaoImpl implements AdminDao {

	@Override
	public Admin validate(int userID, String password) {
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		Admin user1 = null;
		try {
			factory =Persistence.createEntityManagerFactory("admin");
			manager = factory.createEntityManager();
			user1 = manager.find(Admin.class, userID);
			if(user1!=null) {
				if(user1.getPassword().equals(password)) {
					return user1;
				}else {
					return user1=null;
				}
			}else {
				return null;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user1;
	}

	@Override
	public boolean createAccount(int userID, String password) {
		boolean flag = false;
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;
		
		Admin admin = new Admin();
		admin.setUserID(userID);
		admin.setPassword(password);
		try {
			factory = Persistence.createEntityManagerFactory("admin");
			manager = factory.createEntityManager();
			transaction= manager.getTransaction();
			Admin data = manager.find(Admin.class, userID);
			System.out.println(data);
			
			if(data==null) {
				transaction.begin();
				manager.persist(admin);
				transaction.commit();
				flag = true;
			}else {
				flag = false;
			}
		} catch (Exception e) {
			if(transaction!=null) {
				transaction.rollback();
			}
		}
		return flag;
	}

}
