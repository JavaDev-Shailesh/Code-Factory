package com.ibm.demandmngtracker.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ibm.demandmngtracker.bean.LoginFormBean;
import com.ibm.demandmngtracker.util.DBConnectionUtil;

@Repository
public class DMTServiceDaoImpl extends DBConnectionUtil implements DMTServiceDao {

	private static final Logger LOGGER = LogManager.getLogger(DMTServiceDaoImpl.class);

	@Override
	public String isUserValid(LoginFormBean formBean, HttpSession session) throws Exception {
		
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		ResultSet resultSet2= null;
		String result = null;
		boolean flag = false;
		try {
			connection = getJDBCConnection();
			connection.setAutoCommit(false);
			LOGGER.info("Is connection created: " + (connection != null));

			statement = connection.createStatement();
			StringBuilder builder = new StringBuilder();
			builder.append(" SELECT (CASE  ");
			builder.append(" 	WHEN COUNT(*) = 0 THEN 'INVALID_USER_DETAILS_ENTERED' ");
			//builder.append(" 	WHEN MAX(LOGGEDIN_STATUS) = 'LOGIN' THEN 'USER_IS_ALREADY_LOGGED_IN' ");
			builder.append(" 	ELSE 'VALID'");
			builder.append(" END) AS RESULT ");
			builder.append(" FROM TBL_DM_USERDETAILS ");
			builder.append(" WHERE USERID ='").append(formBean.getUserName()).append("'");
			builder.append(" AND   PASSWORD='").append(formBean.getPassword()).append("'");
			

			String selectQuery = builder.toString();
			LOGGER.info("selectQuery: " + selectQuery);

			resultSet = statement.executeQuery(selectQuery);
			
			if (resultSet.next()) {
				result = resultSet.getString("RESULT").trim();
			}

			LOGGER.info("User who tried to login is: " + result);

			if ("VALID".equals(result)) {
				builder.setLength(0);
				builder.append("SELECT user_access FROM TBL_DM_USERDETAILS   ");
				builder.append(" WHERE USERID ='").append(formBean.getUserName()).append("'");
				builder.append(" AND   PASSWORD='").append(formBean.getPassword()).append("'");
				resultSet2 = statement.executeQuery(builder.toString());
				
				if (resultSet2.next()) {
					session.setAttribute("ACCESS",  resultSet2.getString("user_access").trim());
					
				}
			
				builder.setLength(0);
				builder.append(" UPDATE TBL_DM_USERDETAILS SET LOGGEDIN_STATUS = 'LOGIN' ");
				builder.append(" WHERE USERID = '").append(formBean.getUserName()).append("'");

				String updateQuery = builder.toString();
				LOGGER.info("updateQuery: " + updateQuery);

				int rowsAffected = statement.executeUpdate(updateQuery);
				if (rowsAffected > 0) {
					flag = true;
					builder.setLength(0);
					builder.append(" INSERT INTO TBL_DM_USER_LOGINSTATUS(USERID , LOGIN_TIME) ");
					builder.append(" VALUES('").append(formBean.getUserName()).append("',");
					builder.append(" SYSTIMESTAMP )");

					String insertQuery = builder.toString();
					LOGGER.info("insertQuery: " + insertQuery);

					int rowsInserted = statement.executeUpdate(insertQuery);

					if (rowsInserted > 0) {
						LOGGER.info("LOGGEDIN_STATUS updated to 'LOGIN' for user: " + formBean.getUserName());
						LOGGER.info("LOGIN_TIME inserted Successfully.");
					} else {
						flag = false;
						LOGGER.info("Failed to insert Login time data.");
					}

				} else {
					LOGGER.warn("Failed to update LOGGEDIN_STATUS to 'LOGIN' for user: " + formBean.getUserName());
				}
			}

			if (flag) {
				connection.commit();
			} else {
				if (connection != null) {
					connection.rollback();
				}
			}
		} catch (Exception e) {
			if (connection != null) {
				connection.rollback();
			}
			LOGGER.error("An error occurred: " + e.getMessage(), e);
			throw new Exception("An error occurred while processing the user validation.", e);
		} finally {
			// Close resources in the finally block
			if (resultSet != null) {
				resultSet.close();
			}
			if (resultSet2 != null) {
				resultSet2.close();
			}
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
			}
			System.gc();
		}

		return result;
	}

	@Override
	public boolean logoutUser(String userId) throws Exception {

		Connection connection = null;
		Statement statement = null;
		boolean flag = false;

		try {
			connection = getJDBCConnection();
			connection.setAutoCommit(false);
			LOGGER.info("Is connection created: " + (connection != null));

			statement = connection.createStatement();
			StringBuilder builder = new StringBuilder();

			builder.setLength(0);
			builder.append(" UPDATE TBL_DM_USERDETAILS SET LOGGEDIN_STATUS = 'LOGOUT' ");
			builder.append(" WHERE USERID = '").append(userId).append("'");

			String updateQuery = builder.toString();
			LOGGER.info("updateQuery: " + updateQuery);

			int rowsAffected = statement.executeUpdate(updateQuery);

			if (rowsAffected > 0) {
				flag = true;

				builder.setLength(0);
				builder.append(" UPDATE TBL_DM_USER_LOGINSTATUS SET ");
				builder.append(
						" LOGOUT_TIME  = SYSTIMESTAMP WHERE LOGIN_TIME IS NOT NULL AND LOGOUT_TIME IS NULL AND USERID = '")
						.append(userId).append("'");

				String updateQuery1 = builder.toString();
				LOGGER.info("updateQuery1: " + updateQuery1);

				int rowsAffected1 = statement.executeUpdate(updateQuery1);

				if (rowsAffected1 > 0) {
					LOGGER.info("LOGGEDIN_STATUS  updated to 'LOGOUT' for user: " + userId);
					LOGGER.info("LOGOUT_TIME updated Successfully.");
				} else {
					flag = false;
					LOGGER.info("Failed to update log out time data.");
				}

			} else {
				LOGGER.warn("Failed to update LOGGEDIN_STATUS to 'LOGOUT' for user: " + userId);
			}

			if (flag) {
				connection.commit();
			} else {
				if (connection != null) {
					connection.rollback();
				}
			}
		} catch (Exception e) {
			if (connection != null) {
				connection.rollback();
			}
			LOGGER.error("An error occurred: " + e.getMessage(), e);
			throw new Exception("An error occurred while logging out the user.", e);
		} finally {
			// Close resources in the finally block
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
			}
			System.gc();
		}

		return flag;
	}

	@Override
	public boolean unlockUser() throws Exception {
		Connection connection = null;
		Statement statement = null;
		boolean flag = false;

		try {
			connection = getJDBCConnection();
			LOGGER.info("Is connection created: " + (connection != null));

			statement = connection.createStatement();
			StringBuilder builder = new StringBuilder();

			builder.setLength(0);
			builder.append(" UPDATE TBL_DM_USERDETAILS SET LOGGEDIN_STATUS = 'LOGOUT' ");

			String updateQuery = builder.toString();
			LOGGER.info("updateQuery: " + updateQuery);

			int rowsAffected = statement.executeUpdate(updateQuery);

			if (rowsAffected > 0) {
				flag = true;
				LOGGER.info("LOGGEDIN_STATUS updated to 'LOGOUT'");
			} else {
				LOGGER.warn("Failed to update LOGGEDIN_STATUS to 'LOGOUT'");
			}
		} catch (Exception e) {
			// Log the exception or handle it as needed
			LOGGER.error("An error occurred: " + e.getMessage(), e);
			throw new Exception("An error occurred while unlocking the user.", e);
		} finally {
			// Close resources in the finally block
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
			}
			System.gc();
		}

		return flag;
	}

	@Override
	public List<List<Object>> loadAllDemands(boolean isFilterApplied, Map<String, String> formData) throws Exception {
	
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;

		try {
			StringBuilder builder = new StringBuilder();
			builder.append(" SELECT ");
			builder.append(" DM_ID, APPLICATION_NAME, PROJECT_DESCRIPTION, PROJECT_STATUS ");
			builder.append(" FROM TBL_PROJECT_TRACKER_CLONE ");
			if(isFilterApplied && formData !=null && formData.size() > 0) {

				String appName = formData.get("applicationName");
				String projectPhase = formData.get("projectPhase");
				String projectStatus = formData.get("projectStatus");
				
				builder.append(" WHERE ");
				if(appName!=null && appName.length() > 0 && !appName.equals("INVALID")) {
					builder.append(" APPLICATION_NAME LIKE '%").append(appName).append("%' ");
				}
				if(projectPhase!=null && projectPhase.length() > 0 && !projectPhase.equals("INVALID")) {
					if(appName!=null && appName.length() > 0 && !appName.equals("INVALID")) {
						builder.append(" AND ");
					}
					builder.append(" PROJECT_PHASE = '").append(projectPhase).append("' ");
				}
				if(projectStatus!=null && projectStatus.length() > 0 && !projectStatus.equals("INVALID")) {
					if((appName!=null && appName.length() > 0 && !appName.equals("INVALID")) || (projectPhase!=null && projectPhase.length() > 0 && !projectPhase.equals("INVALID")) ) {
						builder.append(" AND ");
					}
					builder.append(" PROJECT_STATUS = '").append(projectStatus).append("' ");
				}
			}
			builder.append(" ORDER BY DM_ID desc");

			String selectQuery = builder.toString();
			connection = getJDBCConnection();

			LOGGER.info("Is connection created: " + (connection != null));
			LOGGER.info("selectQuery: " + selectQuery);

			statement = connection.createStatement();
			resultSet = statement.executeQuery(selectQuery);
			ResultSetMetaData metaData = resultSet.getMetaData();
			List<List<Object>> resultList = new ArrayList<>();

			List<Object> row = null;
			int columnCount = metaData.getColumnCount();
			int rowNo = 0;
			while (resultSet.next()) {
				rowNo++;
				row = new ArrayList<>();
				row.add(rowNo);
				for (int i = 1; i <= columnCount; i++) {
					if(isFilterApplied) {
						row.add( resultSet.getObject(i) );
					}else {
						row.add("'" + resultSet.getObject(i) + "'");
					}
				}
				resultList.add(row);
			}

			LOGGER.info("Is data fetched: " + (resultList.size() > 0));
			return resultList;
		} catch (Exception e) {
			// Log the exception or handle it as needed
			LOGGER.error("An error occurred: " + e.getMessage(), e);
			throw new Exception("An error occurred while loading demands.", e);
		} finally {
			// Close resources in the finally block
			if (resultSet != null) {
				resultSet.close();
			}
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
			}
			System.gc();
		}
	}

	@Override
	public Map<String, Object> viewAndEdit(String dmId) throws Exception {

		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		ResultSetMetaData metaData = null;

		try {
			StringBuilder queryBuilder = new StringBuilder();
			queryBuilder.setLength(0);
			queryBuilder.append(" SELECT ");
			queryBuilder.append(" DM_ID AS \"dmId\", ");
			queryBuilder.append(" PROJECT_DESCRIPTION AS \"projectDescription\", ");
			queryBuilder.append(" APPLICATION_NAME AS \"applicationName\", ");
			queryBuilder.append(" MODE_OF_DELIVERY AS \"modeOfDelivery\", ");
			queryBuilder.append(" G3_RECEIVED_DATE AS \"g3ReceivedDate\",  ");
			queryBuilder.append(" MONTH_AND_YEAR AS \"monthAndYear\", ");
			queryBuilder.append(" MONTH_AND_YEAR_FOR_CLOSURE AS \"monthAndYearForClosure\", ");
			queryBuilder.append(" PROJECT_PHASE AS \"projectPhase\", ");
			queryBuilder.append(" PROJECT_STATUS AS \"projectStatus\", ");
			queryBuilder.append(" PROJECT_PLAN_SHARED_DATE AS \"projectPlanSharedDate\", ");
			queryBuilder.append(" DEV_START_DATE AS \"devStartDate\", ");
			queryBuilder.append(" DEV_END_DATE AS \"devEndDate\", ");
			queryBuilder.append(" SIT_PLANNED_START_DATE AS \"sitPlannedStartDate\", ");
			queryBuilder.append(" SIT_PLANNED_END_DATE AS \"sitPlannedEndDate\", ");
			queryBuilder.append(" SIT_ACTUAL_START AS \"sitActualStart\", ");
			queryBuilder.append(" SIT_ACTUAL_END AS \"sitActualEnd\", ");
			queryBuilder.append(" VIL_PM_ARTIFACTS_REVIEW_PLANNED_START AS \"vilPmArtifactsReviewPlannedStart\", ");
			queryBuilder.append(" VIL_PM_ARTIFACTS_REVIEW_PLANNED_END AS \"vilPmArtifactsReviewPlannedEnd\", ");
			queryBuilder.append(" VIL_PM_ARTIFACTS_REVIEW_RELEASE_DATE AS \"vilPmArtifactsReviewReleaseDate\", ");
			queryBuilder.append(" VIL_PM_ARTIFACTS_REVIEW_SIGN_OFF_DATE AS \"vilPmArtifactsReviewSignOffDate\", ");
			queryBuilder.append(" UAT_PLANNED_START_DATE AS \"uatPlannedStartDate\", ");
			queryBuilder.append(" UAT_PLANNED_END_DATE AS \"uatPlannedEndDate\", ");
			queryBuilder.append(" UAT_RELEASE_DATE AS \"uatReleaseDate\", ");
			queryBuilder.append(" UAT_SIGN_OFF_RECEIVED AS \"uatSignOffReceived\", ");
			queryBuilder.append(" PROD_NOT_OK_Y_OR_N AS \"prodNotOkYN\", ");
			queryBuilder.append(" PROD_SIGN_OFF AS \"prodSignOff\", ");
			queryBuilder.append(" APPLICATION_GO_LIVE AS \"applicationGoLive\", ");
			queryBuilder.append(" OVERALL_GO_LIVE AS \"overallGoLive\", ");
			queryBuilder.append(" CLOSURE_DATE AS \"closureDate\", ");
			queryBuilder.append(" REMARKS AS \"remarks\", ");
			queryBuilder.append(" RAG AS \"rag\", ");
			queryBuilder.append(" PP_REVISION_COUNT AS \"ppRevisionCount\", ");
			queryBuilder.append(" PROJECT_PLAN_REVISION_DATES_AND_REASON AS \"projectPlanRevisionDatesAndReason\", ");
			queryBuilder.append(" DEMAND_SEND_BACK_TO_G2_REASON AS \"demandSendBackToG2Reason\", ");
			queryBuilder.append(" SUMMARY AS \"summary\", ");
			queryBuilder.append(" E2E_PM AS \"e2ePm\", ");
			queryBuilder.append(" SKILL AS \"skill\",   ");
			queryBuilder.append(" PROJECT_CR AS \"projectCr\", ");
			queryBuilder.append(" PROJECT_SIZE AS \"projectSize\", ");
			queryBuilder.append(" VIL_PM AS \"vilPm\", ");
			queryBuilder.append(" IBM_PM AS \"ibmPm\", ");
			queryBuilder.append(" BRAND AS \"brand\", ");
			queryBuilder.append(" AMS AS \"ams\",  ");
			queryBuilder.append(" EFFORTS AS \"efforts\", ");
			queryBuilder.append(" UAT_ACTUAL_START AS \"uatActualStart\", ");
			queryBuilder.append(" UAT_ACTUAL_END  AS  \"uatActualEnd\" ");
			queryBuilder.append(" FROM TBL_PROJECT_TRACKER_CLONE ");
			queryBuilder.append(" WHERE DM_ID = '").append(dmId).append("'");

			String selectQuery = queryBuilder.toString();
			connection = getJDBCConnection();

			LOGGER.info(" is connection created  : " + (connection != null));
			LOGGER.info("selectQuery : " + selectQuery);

			statement = connection.createStatement();
			resultSet = statement.executeQuery(selectQuery);
			metaData = resultSet.getMetaData();
			Map<String, Object> row = null;

			int columnCount = metaData.getColumnCount();
			String columName = null;
			Object columValue = null;

			while (resultSet.next()) {
				row = new LinkedHashMap<String, Object>();

				for (int i = 1; i <= columnCount; i++) {
					columName = metaData.getColumnName(i);
					columValue = resultSet.getObject(i);
					 if (columValue instanceof String) {
				            columValue = ((String) columValue).replace("\n", "").replace("\r", "");
				        }
					row.put(columName, columValue);

				}
			}
			LOGGER.info("Is data fetched: " + (row != null && row.size() > 0));

			if (!(row != null && row.size() > 0)) {
				row = new LinkedHashMap<String, Object>();
				row.put("RESPONCE", "INVALID_DMID");
			}

			return row;

		} catch (Exception e) {
			// Log the exception or handle it as needed
			LOGGER.error("An error occurred: " + e.getMessage(), e);
			throw new Exception("An error occurred while loading demand with DM_ID: " + dmId, e);
		} finally {
			// Close resources in the finally block
			if (resultSet != null) {
				resultSet.close();
			}
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
			}
			System.gc();
		}
	}

	@Override
	public String updateDemand(Map<String, String> formData, String userId) throws Exception {

		formData = formData.entrySet().stream()
				.collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().trim()));
		String dmId = formData.get("dmId");
		Connection connection = null;
		Statement statement = null;
		boolean flag = false;
		String message = "INVALID";
		try {
			connection = getJDBCConnection();
			connection.setAutoCommit(false);
			LOGGER.info("Is connection created: " + (connection != null));

			statement = connection.createStatement();
			StringBuilder builder = new StringBuilder();

			builder.setLength(0);
			builder.append(" UPDATE TBL_PROJECT_TRACKER_CLONE SET ");
			builder.append(" PROJECT_DESCRIPTION = '").append(formData.get("projectDescription")).append("', ");
			builder.append(" APPLICATION_NAME = '").append(formData.get("applicationName")).append("', ");
			builder.append(" MODE_OF_DELIVERY = '").append(formData.get("modeOfDelivery")).append("', ");
			builder.append(" G3_RECEIVED_DATE = '").append(formData.get("g3ReceivedDate")).append("', ");
			builder.append(" MONTH_AND_YEAR = '").append(formData.get("monthAndYear")).append("', ");
			builder.append(" MONTH_AND_YEAR_FOR_CLOSURE = '").append(formData.get("monthAndYearForClosure"))
					.append("', ");
			builder.append(" PROJECT_PHASE = '").append(formData.get("projectPhase")).append("', ");
			builder.append(" PROJECT_STATUS = '").append(formData.get("projectStatus")).append("', ");
			builder.append(" PROJECT_PLAN_SHARED_DATE = '").append(formData.get("projectPlanSharedDate")).append("', ");
			builder.append(" DEV_START_DATE = '").append(formData.get("devStartDate")).append("', ");
			builder.append(" DEV_END_DATE = '").append(formData.get("devEndDate")).append("', ");
			builder.append(" SIT_PLANNED_START_DATE = '").append(formData.get("sitPlannedStartDate")).append("', ");
			builder.append(" SIT_PLANNED_END_DATE = '").append(formData.get("sitPlannedEndDate")).append("', ");
			builder.append(" SIT_ACTUAL_START = '").append(formData.get("sitActualStart")).append("', ");
			builder.append(" SIT_ACTUAL_END = '").append(formData.get("sitActualEnd")).append("', ");
			builder.append(" VIL_PM_ARTIFACTS_REVIEW_PLANNED_START = '")
					.append(formData.get("vilPmArtifactsReviewPlannedStart")).append("', ");
			builder.append(" VIL_PM_ARTIFACTS_REVIEW_PLANNED_END = '")
					.append(formData.get("vilPmArtifactsReviewPlannedEnd")).append("', ");
			builder.append(" VIL_PM_ARTIFACTS_REVIEW_RELEASE_DATE = '")
					.append(formData.get("vilPmArtifactsReviewReleaseDate")).append("', ");
			builder.append(" VIL_PM_ARTIFACTS_REVIEW_SIGN_OFF_DATE = '")
					.append(formData.get("vilPmArtifactsReviewSignOffDate")).append("', ");
			builder.append(" UAT_PLANNED_START_DATE = '").append(formData.get("uatPlannedStartDate")).append("', ");
			builder.append(" UAT_PLANNED_END_DATE = '").append(formData.get("uatPlannedEndDate")).append("', ");
			builder.append(" UAT_RELEASE_DATE = '").append(formData.get("uatReleaseDate")).append("', ");
			builder.append(" UAT_SIGN_OFF_RECEIVED = '").append(formData.get("uatSignOffReceived")).append("', ");
			builder.append(" PROD_NOT_OK_Y_OR_N = '").append(formData.get("prodNotOkYN")).append("', ");
			builder.append(" PROD_SIGN_OFF = '").append(formData.get("prodSignOff")).append("', ");
			builder.append(" APPLICATION_GO_LIVE = '").append(formData.get("applicationGoLive")).append("', ");
			builder.append(" OVERALL_GO_LIVE = '").append(formData.get("overallGoLive")).append("', ");
			builder.append(" CLOSURE_DATE = '").append(formData.get("closureDate")).append("', ");
			builder.append(" REMARKS = '").append(formData.get("remarks")).append("', ");
			builder.append(" RAG = '").append(formData.get("rag")).append("', ");
			builder.append(" PP_REVISION_COUNT = '").append(formData.get("ppRevisionCount")).append("', ");
			builder.append(" PROJECT_PLAN_REVISION_DATES_AND_REASON = '")
					.append(formData.get("projectPlanRevisionDatesAndReason")).append("', ");
			builder.append(" DEMAND_SEND_BACK_TO_G2_REASON = '").append(formData.get("demandSendBackToG2Reason"))
					.append("', ");
			builder.append(" SUMMARY = '").append(formData.get("summary")).append("', ");
			builder.append(" E2E_PM = '").append(formData.get("e2ePm")).append("', ");
			builder.append(" SKILL = '").append(formData.get("skill")).append("', ");
			builder.append(" PROJECT_CR = '").append(formData.get("projectCr")).append("', ");
			builder.append(" PROJECT_SIZE = '").append(formData.get("projectSize")).append("', ");
			builder.append(" VIL_PM = '").append(formData.get("vilPm")).append("', ");
			builder.append(" IBM_PM = '").append(formData.get("ibmPm")).append("', ");
			builder.append(" BRAND = '").append(formData.get("brand")).append("', ");
			builder.append(" AMS = '").append(formData.get("ams")).append("', ");
			builder.append(" EFFORTS = '").append(formData.get("efforts")).append("', ");
			builder.append(" UAT_ACTUAL_START = '").append(formData.get("uatActualStart")).append("', ");
			builder.append(" UAT_ACTUAL_END = '").append(formData.get("uatActualEnd")).append("' ");
			builder.append(" WHERE DM_ID = '").append(dmId).append("'");

			String updateQuery = builder.toString();

			LOGGER.info("updateQuery: " + updateQuery);

			int rowsAffected = statement.executeUpdate(updateQuery);

			if (rowsAffected > 0) {
				connection.commit();
				message = "VALID";
				LOGGER.info("TBL_PROJECT_TRACKER_CLONE updated Successfully for Demand Id: " + dmId);
				builder.setLength(0);
				builder.append(" UPDATE TBL_DM_PROJECT_TRACKER_HISTORY SET ");
				builder.append(" USERID = '").append(userId).append("'");
				builder.append(" WHERE ENTRY_DATETIME = (");
				builder.append(" SELECT MAX(ENTRY_DATETIME) FROM TBL_DM_PROJECT_TRACKER_HISTORY )");
				builder.append(" AND USERID IS NULL ");

				String userIdQuery = builder.toString();
				LOGGER.info("userIdUpdateQuery: " + userIdQuery);

				int uerIdUpdatedAffected = statement.executeUpdate(userIdQuery);

				if (uerIdUpdatedAffected > 0) {
					builder.setLength(0);
					builder.append(" INSERT INTO TBL_DM_ACTION_HISTORY(USERID , ACTION_PERFORMED)   ");
					builder.append(" VALUES('").append(userId).append("','UPDATE')");

					String insertActionHistoryQuery = builder.toString();
					LOGGER.info("insertActionHistoryQuery: " + insertActionHistoryQuery);

					int actionHistoryRowAffected = statement.executeUpdate(insertActionHistoryQuery);

					if (actionHistoryRowAffected > 0) {
						flag = true;
						LOGGER.info("TBL_DM_PROJECT_TRACKER_HISTORY user id : " + userId + " updated for Demand Id : "
								+ dmId);
						LOGGER.info("TBL_DM_ACTION_HISTORY inserted Successfully for userId: " + userId);
					} else {
						message = "PARTIAL_VALID";
					}
				} else {
					message = "PARTIAL_VALID";
				}

			} else {
				LOGGER.info("TBL_PROJECT_TRACKER_CLONE table data 'NOT' updated for Demand Id: " + dmId);
			}

			if (flag) {
				connection.commit();
			} else {
				if (connection != null) {
					connection.rollback();
				}
			}
		} catch (Exception e) {
			if (connection != null) {
				connection.rollback();
			}
			LOGGER.error("An error occurred: " + e.getMessage(), e);
			throw new Exception("An error occurred while update Demand Id: " + dmId, e);
		} finally {
			// Close resources in the finally block
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
			}
			System.gc();
		}

		return message;
	}

	@Override
	public String addNewDemand(Map<String, String> formData, String userId) throws Exception {

		formData = formData.entrySet().stream()
				.collect(Collectors.toMap(Map.Entry::getKey, entry -> "'" + entry.getValue().trim() + "'"));
		String dmId = formData.get("dmId");
		Connection connection = null;
		Statement statement = null;
		boolean flag = false;
		String message = "INVALID";
		try {
			connection = getJDBCConnection();
			connection.setAutoCommit(false);
			LOGGER.info("Is connection created: " + (connection != null));

			statement = connection.createStatement();
			StringBuilder builder = new StringBuilder();

			builder.setLength(0);
			builder.append(" SELECT COUNT(*) FROM TBL_PROJECT_TRACKER_CLONE WHER  ");
			builder.append(" WHERE DM_ID = ").append(dmId);
			ResultSet resultSet = statement.executeQuery(builder.toString());

			int isDemandIdExist = 0;
			if (resultSet.next()) {
				isDemandIdExist = resultSet.getInt(1);
			}

			if (isDemandIdExist == 0) {
				builder.setLength(0);
				builder.append(" INSERT INTO TBL_PROJECT_TRACKER_CLONE (");
				builder.append(
						" DM_ID, PROJECT_DESCRIPTION, APPLICATION_NAME, MODE_OF_DELIVERY, G3_RECEIVED_DATE, MONTH_AND_YEAR, ");
				builder.append(
						" MONTH_AND_YEAR_FOR_CLOSURE, PROJECT_PHASE, PROJECT_STATUS, PROJECT_PLAN_SHARED_DATE, DEV_START_DATE, ");
				builder.append(
						" DEV_END_DATE, SIT_PLANNED_START_DATE, SIT_PLANNED_END_DATE, SIT_ACTUAL_START, SIT_ACTUAL_END, ");
				builder.append(" VIL_PM_ARTIFACTS_REVIEW_PLANNED_START, VIL_PM_ARTIFACTS_REVIEW_PLANNED_END, ");
				builder.append(" VIL_PM_ARTIFACTS_REVIEW_RELEASE_DATE, VIL_PM_ARTIFACTS_REVIEW_SIGN_OFF_DATE, ");
				builder.append(
						" UAT_PLANNED_START_DATE, UAT_PLANNED_END_DATE, UAT_RELEASE_DATE, UAT_SIGN_OFF_RECEIVED, ");
				builder.append(
						" PROD_NOT_OK_Y_OR_N, PROD_SIGN_OFF, APPLICATION_GO_LIVE, OVERALL_GO_LIVE, CLOSURE_DATE, ");
				builder.append(" REMARKS, RAG, PP_REVISION_COUNT, PROJECT_PLAN_REVISION_DATES_AND_REASON, ");
				builder.append(
						" DEMAND_SEND_BACK_TO_G2_REASON, SUMMARY, E2E_PM, SKILL, PROJECT_CR, PROJECT_SIZE, VIL_PM, ");
				builder.append(" IBM_PM, BRAND, AMS, EFFORTS, UAT_ACTUAL_START, UAT_ACTUAL_END) VALUES (");
				builder.append(dmId).append(", ");
				builder.append(formData.get("projectDescription")).append(", ");
				builder.append(formData.get("applicationName")).append(", ");
				builder.append(formData.get("modeOfDelivery")).append(", ");
				builder.append(formData.get("g3ReceivedDate")).append(", ");
				builder.append(formData.get("monthAndYear")).append(", ");
				builder.append(formData.get("monthAndYearForClosure")).append(", ");
				builder.append(formData.get("projectPhase")).append(", ");
				builder.append(formData.get("projectStatus")).append(", ");
				builder.append(formData.get("projectPlanSharedDate")).append(", ");
				builder.append(formData.get("devStartDate")).append(", ");
				builder.append(formData.get("devEndDate")).append(", ");
				builder.append(formData.get("sitPlannedStartDate")).append(", ");
				builder.append(formData.get("sitPlannedEndDate")).append(", ");
				builder.append(formData.get("sitActualStart")).append(", ");
				builder.append(formData.get("sitActualEnd")).append(", ");
				builder.append(formData.get("vilPmArtifactsReviewPlannedStart")).append(", ");
				builder.append(formData.get("vilPmArtifactsReviewPlannedEnd")).append(", ");
				builder.append(formData.get("vilPmArtifactsReviewReleaseDate")).append(", ");
				builder.append(formData.get("vilPmArtifactsReviewSignOffDate")).append(", ");
				builder.append(formData.get("uatPlannedStartDate")).append(", ");
				builder.append(formData.get("uatPlannedEndDate")).append(", ");
				builder.append(formData.get("uatReleaseDate")).append(", ");
				builder.append(formData.get("uatSignOffReceived")).append(", ");
				builder.append(formData.get("prodNotOkYN")).append(", ");
				builder.append(formData.get("prodSignOff")).append(", ");
				builder.append(formData.get("applicationGoLive")).append(", ");
				builder.append(formData.get("overallGoLive")).append(", ");
				builder.append(formData.get("closureDate")).append(", ");
				builder.append(formData.get("remarks")).append(", ");
				builder.append(formData.get("rag")).append(", ");
				builder.append(formData.get("ppRevisionCount")).append(", ");
				builder.append(formData.get("projectPlanRevisionDatesAndReason")).append(", ");
				builder.append(formData.get("demandSendBackToG2Reason")).append(", ");
				builder.append(formData.get("summary")).append(", ");
				builder.append(formData.get("e2ePm")).append(", ");
				builder.append(formData.get("skill")).append(", ");
				builder.append(formData.get("projectCr")).append(", ");
				builder.append(formData.get("projectSize")).append(", ");
				builder.append(formData.get("vilPm")).append(", ");
				builder.append(formData.get("ibmPm")).append(", ");
				builder.append(formData.get("brand")).append(", ");
				builder.append(formData.get("ams")).append(", ");
				builder.append(formData.get("efforts")).append(", ");
				builder.append(formData.get("uatActualStart")).append(", ");
				builder.append(formData.get("uatActualEnd")).append(")");

				String insertQuery = builder.toString();

				LOGGER.info("insertQuery: " + insertQuery);

				int rowsAffected = statement.executeUpdate(insertQuery);

				if (rowsAffected > 0) {
					connection.commit();
					message = "VALID";
					LOGGER.info("TBL_PROJECT_TRACKER_CLONE added new demand Successfully for Demand Id: " + dmId);
					builder.setLength(0);
					builder.append(" UPDATE TBL_DM_PROJECT_TRACKER_HISTORY SET ");
					builder.append(" USERID = '").append(userId).append("'");
					builder.append(" WHERE ENTRY_DATETIME = (");
					builder.append(" SELECT MAX(ENTRY_DATETIME) FROM TBL_DM_PROJECT_TRACKER_HISTORY )");
					builder.append(" AND USERID IS NULL ");

					String userIdQuery = builder.toString();
					LOGGER.info("userIdUpdateQuery: " + userIdQuery);

					int uerIdUpdatedAffected = statement.executeUpdate(userIdQuery);

					if (uerIdUpdatedAffected > 0) {
						builder.setLength(0);
						builder.append(" INSERT INTO TBL_DM_ACTION_HISTORY(USERID , ACTION_PERFORMED)   ");
						builder.append(" VALUES('").append(userId).append("','INSERT')");

						String insertActionHistoryQuery = builder.toString();
						LOGGER.info("insertActionHistoryQuery: " + insertActionHistoryQuery);

						int actionHistoryRowAffected = statement.executeUpdate(insertActionHistoryQuery);

						if (actionHistoryRowAffected > 0) {
							flag = true;
							LOGGER.info("TBL_DM_PROJECT_TRACKER_HISTORY user id : " + userId
									+ " updated for Demand Id : " + dmId);
							LOGGER.info("TBL_DM_ACTION_HISTORY inserted Successfully for userId: " + userId);
						} else {
							message = "PARTIAL_VALID";
						}
					} else {
						message = "PARTIAL_VALID";
					}

				} else {
					LOGGER.info("TBL_PROJECT_TRACKER_CLONE table data 'NOT' Inserted for Demand Id: " + dmId);
				}
			} else {
				message = "DEMAND_EXIST";
				LOGGER.info("New Demand 'NOT' added, Demand Id is Already Exist. Demand Id: " + dmId);
			}

			if (flag) {
				connection.commit();
			} else {
				if (connection != null) {
					connection.rollback();
				}
			}
		} catch (Exception e) {
			if (connection != null) {
				connection.rollback();
			}
			LOGGER.error("An error occurred: " + e.getMessage(), e);
			throw new Exception("An error occurred while add new Demand, Demand Id: " + dmId, e);
		} finally {
			// Close resources in the finally block
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
			}
			System.gc();
		}

		return message;
	}

	/*public static Map<String, List<String>> getDropDownData() {
		
		Map<String, List<String>> dropdownVal = new HashedMap<String, List<String>>();
		
		List<String> applicationNames = new ArrayList<>();
		List<String> projectPhases = new ArrayList<>();
		List<String> projectStatus = new ArrayList<>();

		String applicationNameSqlQuery = "SELECT DISTINCT APPLICATION_NAME FROM TBL_PROJECT_TRACKER_CLONE";
		String projectPhaseSqlQuery = "SELECT DISTINCT PROJECT_PHASE FROM TBL_PROJECT_TRACKER_CLONE";
		String projectStatusSqlQuery = "SELECT DISTINCT PROJECT_STATUS FROM TBL_PROJECT_TRACKER_CLONE";

		try {
			Connection connection = getJDBCConnection();
			LOGGER.info("Is connection created: " + (connection != null));
			Statement preparedStatement = connection.createStatement();
			ResultSet resultSet = preparedStatement.executeQuery(applicationNameSqlQuery);
			while (resultSet.next()) {
				applicationNames.add(resultSet.getString("APPLICATION_NAME"));
			}
			dropdownVal.put("applicationNames",applicationNames);
			
			resultSet = preparedStatement.executeQuery(projectPhaseSqlQuery);
			while (resultSet.next()) {
				projectPhases.add(resultSet.getString("PROJECT_PHASE"));
			}
			dropdownVal.put("projectPhases",projectPhases);
			
			resultSet = preparedStatement.executeQuery(projectStatusSqlQuery);
			while (resultSet.next()) {
				projectStatus.add(resultSet.getString("PROJECT_STATUS"));
			}
			dropdownVal.put("projectStatus",projectStatus);
			
		} catch (SQLException e) {
			LOGGER.error("An error occurred: ", e);
		}
		
		return dropdownVal;
	}*/

	@Override
	public List<List<String>> getDataByFilter(Map<String, String> formData) throws Exception {
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		ResultSetMetaData metaData = null;
		List<List<String>> tableData = new ArrayList<List<String>>();

		try {
			StringBuilder queryBuilder = new StringBuilder();
			queryBuilder.setLength(0);
			queryBuilder.append(" SELECT ");
			queryBuilder.append(" DM_ID, ");
			queryBuilder.append(" PROJECT_DESCRIPTION, ");
			queryBuilder.append(" APPLICATION_NAME, ");
			queryBuilder.append(" MODE_OF_DELIVERY, ");
			queryBuilder.append(" G3_RECEIVED_DATE, ");
			queryBuilder.append(" MONTH_AND_YEAR, ");
			queryBuilder.append(" MONTH_AND_YEAR_FOR_CLOSURE, ");
			queryBuilder.append(" PROJECT_PHASE, ");
			queryBuilder.append(" PROJECT_STATUS, ");
			queryBuilder.append(" PROJECT_PLAN_SHARED_DATE, ");
			queryBuilder.append(" DEV_START_DATE, ");
			queryBuilder.append(" DEV_END_DATE, ");
			queryBuilder.append(" SIT_PLANNED_START_DATE, ");
			queryBuilder.append(" SIT_PLANNED_END_DATE, ");
			queryBuilder.append(" SIT_ACTUAL_START, ");
			queryBuilder.append(" SIT_ACTUAL_END, ");
			queryBuilder.append(" VIL_PM_ARTIFACTS_REVIEW_PLANNED_START, ");
			queryBuilder.append(" VIL_PM_ARTIFACTS_REVIEW_PLANNED_END, ");
			queryBuilder.append(" VIL_PM_ARTIFACTS_REVIEW_RELEASE_DATE, ");
			queryBuilder.append(" VIL_PM_ARTIFACTS_REVIEW_SIGN_OFF_DATE, ");
			queryBuilder.append(" UAT_PLANNED_START_DATE, ");
			queryBuilder.append(" UAT_PLANNED_END_DATE, ");
			queryBuilder.append(" UAT_RELEASE_DATE, ");
			queryBuilder.append(" UAT_SIGN_OFF_RECEIVED, ");
			queryBuilder.append(" PROD_NOT_OK_Y_OR_N, ");
			queryBuilder.append(" PROD_SIGN_OFF, ");
			queryBuilder.append(" APPLICATION_GO_LIVE, ");
			queryBuilder.append(" OVERALL_GO_LIVE, ");
			queryBuilder.append(" CLOSURE_DATE, ");
			queryBuilder.append(" REMARKS, ");
			queryBuilder.append(" RAG, ");
			queryBuilder.append(" PP_REVISION_COUNT, ");
			queryBuilder.append(" PROJECT_PLAN_REVISION_DATES_AND_REASON, ");
			queryBuilder.append(" DEMAND_SEND_BACK_TO_G2_REASON, ");
			queryBuilder.append(" SUMMARY, ");
			queryBuilder.append(" E2E_PM, ");
			queryBuilder.append(" SKILL, ");
			queryBuilder.append(" PROJECT_CR, ");
			queryBuilder.append(" PROJECT_SIZE, ");
			queryBuilder.append(" VIL_PM, ");
			queryBuilder.append(" IBM_PM, ");
			queryBuilder.append(" BRAND, ");
			queryBuilder.append(" AMS, ");
			queryBuilder.append(" EFFORTS, ");
			queryBuilder.append(" UAT_ACTUAL_START, ");
			queryBuilder.append(" UAT_ACTUAL_END ");
			queryBuilder.append(" FROM TBL_PROJECT_TRACKER_CLONE ");
			
			if(formData !=null && formData.size() > 0) {

				String appName = formData.get("applicationName");
				String projectPhase = formData.get("projectPhase");
				String projectStatus = formData.get("projectStatus");
				
				queryBuilder.append(" WHERE ");
				if(appName!=null && appName.length() > 0 && !appName.equals("INVALID")) {
					//queryBuilder.append(" APPLICATION_NAME = '").append(appName).append("' ");
					queryBuilder.append(" APPLICATION_NAME LIKE '%").append(appName).append("%' ");
				}
				if(projectPhase!=null && projectPhase.length() > 0 && !projectPhase.equals("INVALID")) {
					if(appName!=null && appName.length() > 0 && !appName.equals("INVALID")) {
						queryBuilder.append(" AND ");
					}
					queryBuilder.append(" PROJECT_PHASE = '").append(projectPhase).append("' ");
				}
				if(projectStatus!=null && projectStatus.length() > 0 && !projectStatus.equals("INVALID")) {
					if((appName!=null && appName.length() > 0 && !appName.equals("INVALID")) || (projectPhase!=null && projectPhase.length() > 0 && !projectPhase.equals("INVALID")) ) {
						queryBuilder.append(" AND ");
					}
					queryBuilder.append(" PROJECT_STATUS = '").append(projectStatus).append("' ");
				}
			}
			
			String selectQuery = queryBuilder.toString();
			connection = getJDBCConnection();

			LOGGER.info(" is connection created  : " + (connection != null));
			LOGGER.info("selectQuery : " + selectQuery);

			statement = connection.createStatement();
			resultSet = statement.executeQuery(selectQuery);
			metaData = resultSet.getMetaData();
			List<String> tableRow = null;
			
			int columnCount = metaData.getColumnCount();
			String columName = null;
			Object columValue = null;
            boolean flag = true;
			while (resultSet.next()) {
				
				if (flag) {
					tableRow = new ArrayList<String>();
					for (int i = 1; i <= columnCount; i++) {
						columName = metaData.getColumnName(i);
						tableRow.add(columName);

					}
					flag = false;
					tableData.add(tableRow);
				}
				tableRow = new ArrayList<String>();
				for (int i = 1; i <= columnCount; i++) {
					columValue = resultSet.getObject(i);
					tableRow.add(columValue!=null ? columValue.toString() : "");

				}
				tableData.add(tableRow);
			}
			LOGGER.info("Is data fetched: " + (tableData != null && tableData.size() > 0));


		} catch (Exception e) {
			LOGGER.error("An error occurred: " + e.getMessage(), e);
			throw new Exception("An error occurred while loading demand by filter: ", e);
		} finally {
			if (resultSet != null) {
				resultSet.close();
			}
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
			}
			System.gc();
		}
		
		return tableData;
	}

}
