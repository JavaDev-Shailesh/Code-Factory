package com.ibm.demandmngtracker.dao;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.ibm.demandmngtracker.bean.LoginFormBean;

public interface DMTServiceDao {

	public String isUserValid(LoginFormBean formBean, HttpSession session) throws Exception;

	public boolean logoutUser(String userId) throws Exception;

	public boolean unlockUser() throws Exception;

	public List<List<Object>> loadAllDemands(boolean isFilterApplied, Map<String, String> formData) throws Exception;
		
	public Map<String,Object> viewAndEdit(String dmId) throws Exception;
	
	public String updateDemand(Map<String, String> formData, String userId) throws Exception;
	
	public String addNewDemand(Map<String, String> formData, String userId) throws Exception;
	
	public List<List<String>> getDataByFilter(Map<String, String> formData) throws Exception;
}
