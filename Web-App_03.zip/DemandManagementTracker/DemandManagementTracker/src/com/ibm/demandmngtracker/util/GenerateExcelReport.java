package com.ibm.demandmngtracker.util;

import java.io.OutputStream;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class GenerateExcelReport {

	private static final Logger LOGGER = LogManager.getLogger(GenerateExcelReport.class);

	public static boolean generateExcel(OutputStream outputStream, List<List<String>> sqlData) throws Exception {

		boolean isDataFound = false;
		if (sqlData!=null && sqlData.size() >0) {
			try (Workbook workbook = new XSSFWorkbook()) {

				Sheet sheet = workbook.createSheet("DMGM-REPORT");

				CellStyle headerStyle = workbook.createCellStyle();
				headerStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
				headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
				headerStyle.setAlignment(HorizontalAlignment.CENTER);

				Font font = workbook.createFont();
				font.setBold(true);

				headerStyle.setFont(font);

				int rowNum = 0;

				for (List<String> rowList : sqlData) {

					Row row = sheet.createRow(rowNum++);

					int colNum = 0;

					for (String field : rowList) {

						Cell cell = row.createCell(colNum++);
						cell.setCellValue(field);

						CellStyle cellStyle = workbook.createCellStyle();
						cellStyle.setBorderBottom(BorderStyle.THIN);
						cellStyle.setBorderTop(BorderStyle.THIN);
						cellStyle.setBorderRight(BorderStyle.THIN);
						cellStyle.setBorderLeft(BorderStyle.THIN);
						cellStyle.setAlignment(HorizontalAlignment.CENTER);
						cell.setCellStyle(cellStyle);

						if (rowNum == 1) {
							cell.setCellStyle(headerStyle);
						}
					}

				}
				for (int i = 0; i < sqlData.get(0).size(); i++) {
					sheet.autoSizeColumn(i);
					sheet.setColumnWidth(i, 6000);
				}

				workbook.write(outputStream);
				isDataFound = true;
			}

			LOGGER.info("Excel file has been generated successfully!");
		}else {
			LOGGER.info("Excel file NOT generated.. due to data not found..!");
		}
		return isDataFound;
	}
}
