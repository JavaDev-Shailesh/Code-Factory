package com.ibm.demandmngtracker.util;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;

public class LoadDropdownValues {
	
	private static final Map<String, List<String>> DROPDOWNVALS = new HashedMap<String, List<String>>();
	private static final List<String> APPLICATION_NAMES = Arrays
			.asList("IVR", "CTI", "EMC", "OBD","IVR/CTI","IVR/EMC","IVR/OBD","CTI/EMC","CTI/OBD","EMC/OBD",
					"IVR/CTI/EMC","IVR/CTI/OBD","IVR/EMC/OBD","CTI/EMC/OBD","IVR/CTI/EMC/OBD");
			//.asList("IVR", "CISCO CTI/Exony", "CTI", "IVR/EMC", "IVR/EMC/OBD", "IVR/OBD", "IVR/OBD/EMC", "EMC", "EMC/OBD", "OBD");
	private static final List<String> PROJECT_PHASES = Arrays
			//.asList("Deployment", "UAT", "Developement", "Efforts", "Development", "Design", "SIT", "DEVELOPEMENT", "Support Only", "Feasibility");
			.asList("Deployment","Design","Development","Feasibility","SIT","Solutioning","Support Only","UAT");
	private static final List<String> PROJECT_STATUS = Arrays
			//.asList("Completed", "Cancelled", "Sent back to G2", "Sent back to G1", "To be Started", "In-Project", "In-Progress", "To be started", "Send back to G0", "On Hold");
			.asList("Cancelled","Completed","In-Progress","On Hold","Sent back to G1","Sent back to G2","To be started");

	public static Map<String, List<String>> dropDownData() {

		DROPDOWNVALS.put("applicationNames", APPLICATION_NAMES);
		DROPDOWNVALS.put("projectPhases", PROJECT_PHASES);
		DROPDOWNVALS.put("projectStatus", PROJECT_STATUS);

		return DROPDOWNVALS;
	}
}
