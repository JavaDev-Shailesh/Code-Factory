package com.ibm.demandmngtracker.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.demandmngtracker.bean.LoginFormBean;
import com.ibm.demandmngtracker.service.DMTService;
import com.ibm.demandmngtracker.util.LoadDropdownValues;

@Controller // http://localhost:8082/DemandManagmentTracker/
public class DMTController {

	@Autowired
	private DMTService service;
	private static final Logger LOGGER = LogManager.getLogger(DMTController.class);
	private static final String UPLOAD_DIR = "C:/DemandManagment/UploadFile/";

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String loadHomePage() {
		LOGGER.info("loadHomePage");
		return "loginpage";
	}

	@RequestMapping(value = "/dashboard", method = RequestMethod.POST)
	public ModelAndView loadDashboard(@ModelAttribute LoginFormBean loingFormBean, HttpServletRequest request) {
		ModelAndView modelAndView = null;
		HttpSession session = null;
		try {
			LOGGER.info("loingFormBean: " + loingFormBean);
			session = request.getSession(true);
			String userLoginStatus = (loingFormBean != null && loingFormBean.getUserName() != null)
					? service.isUserValid(loingFormBean, session)
					: "VALID";
			modelAndView = new ModelAndView();

			if (userLoginStatus.equals("INVALID_USER_DETAILS_ENTERED")
			/* || userLoginStatus.equals("USER_IS_ALREADY_LOGGED_IN") */) {

				session.setAttribute("message", userLoginStatus);
				modelAndView.setViewName("redirect:/");

			} else {

				session.setAttribute("UserName", loingFormBean.getUserName());
				modelAndView.setViewName("redirect:/home");
			}
			System.out.println("------------------------"+session.getAttribute("ACCESS"));
		} catch (Exception e) {
			LOGGER.error("Exception Occoured In DMTController > loadDashboard : ", e);
		}

		return modelAndView;
	}

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public ModelAndView loadDashboardOnHomeClick(HttpServletRequest request) {
		HttpSession session = null;
		ModelAndView modelAndView = null;
		try {
			session = request.getSession();
			modelAndView = new ModelAndView();
			if (session.getAttribute("UserName") != null) {
				modelAndView.setViewName("dashboard");
			} else {
				modelAndView.setViewName("redirect:/");
			}
		} catch (Exception e) {
			LOGGER.error("Exception Occoured In DMTController > loadDashboard : ", e);
		}

		return modelAndView;
	}

	@ResponseBody
	@RequestMapping(value = "/", method = RequestMethod.POST)
	public void removeSessionAttribute(HttpServletRequest request) {
		HttpSession session = null;
		try {
			session = request.getSession(true);
			session.removeAttribute("message");
		} catch (Exception e) {
			LOGGER.error("Exception Occoured In DMTController > removeSessionAttribute : ", e);
		}
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpServletRequest request) {
		HttpSession session = null;
		try {
			session = request.getSession();
			if (session != null) {
				if (session.getAttribute("UserName") != null) {
					boolean flag = service.logoutUser(session.getAttribute("UserName").toString());
					if (flag) {
						LOGGER.info("Logout Successfully..!");
						session.invalidate();
					} else {
						LOGGER.info("Unable to Logout..!");
					}
				}
			}

		} catch (Exception e) {
			LOGGER.error("Exception Occoured In DMTController > logout : ", e);
		}

		return "redirect:/";
	}

	@RequestMapping(value = "/loadAllDemands", method = RequestMethod.GET)
	public ModelAndView loadAllDemands(HttpServletRequest request) {

		ModelAndView modelAndView = null;
		HttpSession session = null;
		try {
			session = request.getSession(true);
			modelAndView = new ModelAndView();
			if (session != null) {
				if (session.getAttribute("UserName") != null) {
					List<List<Object>> sqlData = service.loadAllDemands(false, null);
					modelAndView.addObject("getAllDemandsData", sqlData);
					// System.out.println(sqlData);
				} else {
					modelAndView.addObject("SESSIONOVER", "YES");
					LOGGER.info("Session is over...!");
				}
			} else {
				modelAndView.addObject("SESSIONOVER", "YES");
				LOGGER.info("Session is over...!");
			}

		} catch (Exception e) {
			LOGGER.error("Exception Occoured In DMTController > loadAllDemands : ", e);
		}
		modelAndView.setViewName("dashboard");

		return modelAndView;
	}

	@ResponseBody
	@RequestMapping(value = "/view", method = RequestMethod.GET, produces = "application/json")
	public String viewAndEdit(@RequestParam(name = "dmId", required = false) String dmId, HttpServletRequest request) {

		HttpSession session = null;
		Map<String, Object> sqlData = null;
		try {
			session = request.getSession(true);

			if (session != null && session.getAttribute("UserName") != null) {

				session.setAttribute("dmId", dmId);
				sqlData = service.viewAndEdit(dmId);
			
			} else {
				sqlData = new LinkedHashMap<String, Object>();
				sqlData.put("SESSIONOVER", "YES");
				LOGGER.info("Session is over...!");
			}
		} catch (Exception e) {
			LOGGER.error("Exception Occoured In DMTController > loadAllDemands : ", e);
		}
		if (sqlData == null) {
			sqlData = new LinkedHashMap<String, Object>();
			sqlData.put("INVALID", "INVALID");
		}

		return service.convertMapToJson(sqlData);
	}

	@ResponseBody
	@RequestMapping(value = "/updateDemand", method = RequestMethod.POST)
	public String updateDemand(@RequestParam Map<String, String> formData, HttpServletRequest request) {

		String message = null;
		HttpSession session = null;
		Map<String, Object> jsonResponce = null;
		try {
			session = request.getSession(true);
			jsonResponce = new LinkedHashMap<String, Object>();

			if (session != null && session.getAttribute("UserName") != null) {

				message = service.updateDemand(formData, session.getAttribute("UserName").toString());
				jsonResponce.put("RESPONCE", message);
				return service.convertMapToJson(jsonResponce);

			} else {
				jsonResponce.put("RESPONCE", "SESSIONOVER");
				LOGGER.info("Session is over...!");
			}
			
		} catch (Exception e) {
			jsonResponce.put("RESPONCE", "ERROR");
			LOGGER.error("Exception Occoured In DMTController > updateDemand : ", e);
		}

		return service.convertMapToJson(jsonResponce);
	}

	@ResponseBody
	@RequestMapping(value = "/uploadzip", method = RequestMethod.POST)
	public String handleFileUpload(@RequestBody byte[] fileData, HttpServletRequest request) {
		String message = null;
		HttpSession session = null;
		Map<String, Object> jsonResponce = null;
		try {
			session = request.getSession(true);
			jsonResponce = new LinkedHashMap<String, Object>();
			String dmId = session.getAttribute("dmId") != null ? session.getAttribute("dmId").toString() : null;
			
				if ( session != null && session.getAttribute("UserName") != null && dmId != null) {

					if (fileData.length == 0) {
						message = "FILE_NOT_UPLOADED";
						LOGGER.info("File Not uploaded fro dmId...! " + dmId);
					} else {

						String fileName = dmId.toString().concat(".zip");
						Path filePath = Paths.get(UPLOAD_DIR, fileName);

						if (Files.exists(filePath)) {
							Files.delete(filePath);
						}

						Files.write(filePath, fileData);
						message = "FILE_UPLOADED";
						LOGGER.info("File uploaded successfully fro dmId...! " + dmId);
					}
					jsonResponce.put("RESPONCE", message);
					return service.convertMapToJson(jsonResponce);
				} else {
					jsonResponce.put("RESPONCE", "SESSIONOVER");
					LOGGER.info("Session is over...!");
				}
			
		} catch (Exception e) {
			jsonResponce.put("RESPONCE", "ERROR");
			LOGGER.info("File Not uploaded  ...! ");
			LOGGER.error("Exception Occoured In DMTController > handleFileUpload : ", e);
		}
		return service.convertMapToJson(jsonResponce);
	}

	@ResponseBody
	@RequestMapping(value = "/downloadZip", method = RequestMethod.POST)
	public ResponseEntity<byte[]> downloadZip(@RequestParam String dmId, HttpServletRequest request) {
		try {
			HttpSession session = request.getSession(false);

			if (session != null && session.getAttribute("UserName") != null) {
				String fileName = dmId + ".zip";
				Path filePath = Paths.get(UPLOAD_DIR, fileName);

				if (Files.exists(filePath)) {
					byte[] fileContent = Files.readAllBytes(filePath);

					HttpHeaders headers = new HttpHeaders();
					headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
					headers.setContentDispositionFormData("attachment", fileName);

					return new ResponseEntity<>(fileContent, headers, HttpStatus.OK);
				} else {
					LOGGER.info("File Not found for this DMID!");
					return new ResponseEntity<>(HttpStatus.NOT_FOUND);
				}
			} else {
				LOGGER.info("Session is over!");
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
		} catch (IOException e) {
			LOGGER.error("Exception Occurred In YourController > downloadZip : ", e);
		}

		return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
	}

	@ResponseBody
	@RequestMapping(value = "/addNewDemand", method = RequestMethod.POST)
	public String addNewDemand(@RequestParam Map<String, String> formData, HttpServletRequest request) {

		String message = null;
		HttpSession session = null;
		Map<String, Object> jsonResponce = null;
		try {
			session = request.getSession(true);
			jsonResponce = new LinkedHashMap<String, Object>();

			if (session != null && session.getAttribute("UserName") != null) {
				

					message = service.addNewDemand(formData, session.getAttribute("UserName").toString());
					jsonResponce.put("RESPONCE", message);
					return service.convertMapToJson(jsonResponce);
				
			} else {
				jsonResponce.put("RESPONCE", "SESSIONOVER");
				LOGGER.info("Session is over...!");
			}
		
		} catch (Exception e) {
			jsonResponce.put("RESPONCE", "ERROR");
			LOGGER.error("Exception Occoured In DMTController > addNewDemand : ", e);
		}

		return service.convertMapToJson(jsonResponce);
	}

	@ResponseBody
	@RequestMapping(value = "/loadDropdown", method = RequestMethod.GET)
	public String loadDropdown(HttpServletRequest request) {
		HttpSession session = null;
		Map<String, Object> jsonResponce = null;
		try {
			session = request.getSession(true);
			jsonResponce = new HashMap<String, Object>();
			if (session != null && session.getAttribute("UserName") != null) {
				

					return service.convertMapOfListToJson(LoadDropdownValues.dropDownData());
				
			} else {
				jsonResponce.put("RESPONCE", "SESSIONOVER");
				LOGGER.info("Session is over...!");
			}
			
		} catch (Exception e) {

			LOGGER.error("Exception Occoured In DMTController > loadDropDown : ", e);
			jsonResponce.put("RESPONCE", "ERROR");
		}
		return service.convertMapToJson(jsonResponce);
	}

	@ResponseBody
	@RequestMapping(value = "/loadDemandByFilter", method = RequestMethod.POST)
	public String loadDemandByFilter(@RequestParam Map<String, String> formData, HttpServletRequest request) {

		HttpSession session = null;
		Map<String, Object> jsonResponce = null;
		try {
			session = request.getSession(true);
			jsonResponce = new HashMap<String, Object>();
			if (session != null && session.getAttribute("UserName") != null) {
				
					List<List<Object>> sqlData = service.loadAllDemands(true, formData);
					return service.convertListToJson(sqlData);
				
			} else {
				jsonResponce.put("RESPONCE", "SESSIONOVER");
				LOGGER.info("Session is over...!");
			}
			
		} catch (Exception e) {

			LOGGER.error("Exception Occoured In DMTController > loadDemandByFilter : ", e);
			jsonResponce.put("RESPONCE", "ERROR");
		}
		return service.convertMapToJson(jsonResponce);
	}

	@ResponseBody
	@RequestMapping(value = "/downloadExcel", method = RequestMethod.POST)
	public ResponseEntity<byte[]> downloadExcel(@RequestParam Map<String, String> formData,
			HttpServletRequest request) {

		HttpSession session = null;
		byte[] excelBytes = null;
		HttpHeaders headers = null;
		ByteArrayOutputStream outputStream = null;
		try {
			session = request.getSession(true);
			outputStream = new ByteArrayOutputStream();
			if (session != null && session.getAttribute("UserName") != null) {

				boolean falg = service.downloadExcel(formData, outputStream);
				if (falg) {
					headers = new HttpHeaders();
					headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

					String fileName = "DMGM-Report.xlsx";

					headers.setContentDispositionFormData("attachment", fileName);
					excelBytes = outputStream.toByteArray();

					return ResponseEntity.ok().headers(headers).body(excelBytes);
				} else {
					return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new byte[0]);
				}

			} else {
				LOGGER.info("Session is over...!");
				return ResponseEntity.status(HttpStatus.NO_CONTENT).body(new byte[0]);
			}

		} catch (Exception e) {

			LOGGER.error("Exception Occoured In DMTController > loadDemandByFilter : ", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new byte[0]);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/UnlockAll", method = RequestMethod.GET)
	public void unlockAll(HttpServletRequest request) {

		try {
			service.unlockUser();
		} catch (Exception e) {
			LOGGER.error("Exception Occoured In DMTController > UnlockAll : ", e);
		}
	}

}
