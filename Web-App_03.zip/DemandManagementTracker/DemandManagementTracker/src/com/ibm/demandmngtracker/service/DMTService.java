package com.ibm.demandmngtracker.service;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.ibm.demandmngtracker.bean.LoginFormBean;

public interface DMTService {

	public String isUserValid(LoginFormBean formBean,HttpSession session ) throws Exception;

	public boolean logoutUser(String userId) throws Exception;

	public boolean unlockUser() throws Exception;
	
	public List<List<Object>> loadAllDemands(boolean isFilterApplied, Map<String, String> formData) throws Exception;
	
	public Map<String,Object> viewAndEdit(String dmId) throws Exception;
	
	public String updateDemand(Map<String, String> formData, String userId) throws Exception;
	
	public String addNewDemand(Map<String, String> formData, String userId) throws Exception;
	
	public boolean downloadExcel(Map<String, String> formData, ByteArrayOutputStream outputStream) throws Exception;
	
	public  String convertMapToJson(Map<String, Object> map) ;
	
	public String convertMapOfListToJson(Map<String, List<String>> map);
	
	public String convertListToJson(List<List<Object>> dataList);

}
