package com.ibm.demandmngtracker.service;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.demandmngtracker.bean.LoginFormBean;
import com.ibm.demandmngtracker.dao.DMTServiceDao;
import com.ibm.demandmngtracker.util.GenerateExcelReport;

@Service
public class DMTServiceImpl implements DMTService {

	@Autowired
	private DMTServiceDao dao;
	
	@Override
	public String isUserValid(LoginFormBean formBean, HttpSession session ) throws Exception {

		return dao.isUserValid(formBean,session);
	}

	@Override
	public boolean logoutUser(String userId) throws Exception {
		
		return dao.logoutUser(userId);
	}

	@Override
	public boolean unlockUser() throws Exception {
	
		return dao.unlockUser();
	}

	@Override
	public List<List<Object>> loadAllDemands(boolean isFilterApplied, Map<String, String> formData) throws Exception {

		return dao.loadAllDemands(isFilterApplied, formData);
	}

	@Override
	public Map<String,Object> viewAndEdit(String dmId) throws Exception {

		return dao.viewAndEdit(dmId);
	}
	
	@Override
	public String updateDemand(Map<String, String> formData, String userId) throws Exception {
		
		return dao.updateDemand(formData, userId);
	}
	
	@Override
	public String addNewDemand(Map<String, String> formData, String userId) throws Exception {
		
		return dao.addNewDemand(formData, userId);
	}
	
	@Override
	public boolean downloadExcel(Map<String, String> formData, ByteArrayOutputStream outputStream) throws Exception {
		
		return GenerateExcelReport.generateExcel(outputStream, dao.getDataByFilter(formData)) ;
	}

	@Override
    public  String convertMapToJson(Map<String, Object> map) {
        StringBuilder jsonBuilder = new StringBuilder("{");

        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (jsonBuilder.length() > 1) {
                jsonBuilder.append(",");
            }

            jsonBuilder.append("\"")
                    .append(entry.getKey())
                    .append("\":");

            Object value = entry.getValue();
            if (value instanceof String) {
                jsonBuilder.append("\"").append(value).append("\"");
            } else {
                jsonBuilder.append(value);
            }
        }

        jsonBuilder.append("}");

        return jsonBuilder.toString();
    }

	@Override
	public String convertMapOfListToJson(Map<String, List<String>> map) {
	    StringBuilder jsonBuilder = new StringBuilder("{");

	    for (Map.Entry<String, List<String>> entry : map.entrySet()) {
	        if (jsonBuilder.length() > 1) {
	            jsonBuilder.append(",");
	        }

	        jsonBuilder.append("\"")
	                .append(entry.getKey())
	                .append("\":");

	        List<String> values = entry.getValue();
	        if (values != null && !values.isEmpty()) {
	            jsonBuilder.append("[");
	            for (int i = 0; i < values.size(); i++) {
	                if (i > 0) {
	                    jsonBuilder.append(",");
	                }
	                jsonBuilder.append("\"").append(values.get(i)).append("\"");
	            }
	            jsonBuilder.append("]");
	        } else {
	            // If the list is empty or null, represent it as an empty array
	            jsonBuilder.append("[]");
	        }
	    }

	    jsonBuilder.append("}");

	    return jsonBuilder.toString();
	}

	@Override
	public String convertListToJson(List<List<Object>> dataList) {
	    StringBuilder jsonBuilder = new StringBuilder("[");

	    for (List<Object> innerList : dataList) {
	        if (jsonBuilder.length() > 1) {
	            jsonBuilder.append(",");
	        }

	        jsonBuilder.append("{");

	        for (int i = 0; i < innerList.size(); i++) {
	            if (i > 0) {
	                jsonBuilder.append(",");
	            }

	            Object value = innerList.get(i);

	            jsonBuilder.append("\"")
	                    .append("item" + i) // You can customize the key or use a meaningful one
	                    .append("\":");

	            if (value instanceof String) {
	                jsonBuilder.append("\"").append(value).append("\"");
	            } else {
	                jsonBuilder.append(value);
	            }
	        }

	        jsonBuilder.append("}");
	    }

	    jsonBuilder.append("]");

	    return jsonBuilder.toString();
	}

}
